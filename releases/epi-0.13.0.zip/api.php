<?php
declare(strict_types=1);
// Point d'entrée unique de l'API : /api/...
// Deux dispositions possibles : dossier « app » à côté de ce fichier (hébergement mutualisé) ou dossier parent (développement).
$appDir = is_dir(__DIR__ . '/app/src') ? __DIR__ . '/app' : dirname(__DIR__);
require $appDir . '/src/bootstrap.php';

use Epi\{App, Db, Api};

date_default_timezone_set('UTC');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$configFile = $appDir . '/config.php';
if (!is_file($configFile)) { http_response_code(503); echo json_encode(['error' => 'not_configured']); exit; }
$config = require $configFile;

try {
    $config['storage_dir'] ??= $appDir . '/stockage';
    $app = App::build(Db::connect($config['db']), $config);
    $app->ensureSchema($appDir . '/sql');
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $path = preg_replace('#^.*?/api(/|$)#', '/', $path);
    $raw = file_get_contents('php://input') ?: '';
    $body = [];
    $isUpload = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && (bool)preg_match('#^/items/[A-Z0-9-]{3,24}/files$#', $path);
    if ($raw !== '' && !$isUpload) {
        if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) { http_response_code(415); echo json_encode(['error' => 'json_required']); exit; }
        $body = json_decode($raw, true);
        if (!is_array($body)) { http_response_code(400); echo json_encode(['error' => 'bad_json']); exit; }
    }
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    [$status, $data, $cookies] = (new Api($app))->handle($_SERVER['REQUEST_METHOD'], $path, $body, $_COOKIE, $headers, $ip, $isUpload ? $raw : null, $_GET);
    foreach ($cookies as $c) setcookie($c['name'], $c['value'], ['expires' => $c['expires'], 'path' => '/', 'secure' => $c['secure'], 'httponly' => true, 'samesite' => 'Strict']);
    if (isset($data['_file'])) {   // envoi d'un document : le contrôle des droits est déjà fait par Api
        $f = $data['_file'];
        header('Content-Type: ' . $f['mime']); header('Content-Length: ' . $f['size']); header('Cache-Control: ' . (str_starts_with($f['mime'], 'image/') ? 'private, max-age=86400' : 'private, max-age=0, must-revalidate'));
        header("Content-Disposition: inline; filename=\"" . preg_replace('/[^A-Za-z0-9._-]+/', '_', $f['name']) . "\"; filename*=UTF-8''" . rawurlencode($f['name']));
        http_response_code(200); readfile($f['path']); exit;
    }
    if (isset($data['_bytes'])) {   // fichier fabriqué à la demande (rapport PDF)
        $f = $data['_bytes'];
        header('Content-Type: ' . $f['mime']); header('Content-Length: ' . strlen($f['content'])); header('Cache-Control: private, no-store');
        header("Content-Disposition: attachment; filename=\"" . preg_replace('/[^A-Za-z0-9._-]+/', '_', $f['name']) . "\"");
        http_response_code(200); echo $f['content']; exit;
    }
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('[epi] ' . $e);
    http_response_code(500);
    echo json_encode(['error' => 'server_error']);
}
