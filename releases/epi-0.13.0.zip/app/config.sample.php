<?php
// Copiez ce fichier en « config.php » sur le serveur et remplissez-le.
// Ce fichier ne doit JAMAIS être envoyé sur GitHub (déjà exclu par .gitignore).
return [
    'db' => [
        'dsn'  => 'mysql:host=HOTE_MYSQL;dbname=NOM_BASE;charset=utf8mb4',
        'user' => 'UTILISATEUR',
        'pass' => 'MOT_DE_PASSE',
    ],
    // 32 octets aléatoires en base64. Générer avec : php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
    // ATTENTION : si cette clé est perdue ou changée, les secrets 2FA ne peuvent plus être lus.
    'app_key' => 'REMPLACER',
    'base_url' => 'https://epi-test.molron.be',
    'issuer' => 'Registre EPI',
    'secure_cookies' => true,
    // Clé à usage unique pour la page d'installation (à supprimer de la config après l'installation).
    'install_key' => 'REMPLACER_PAR_UNE_CLE_LONGUE',
];
