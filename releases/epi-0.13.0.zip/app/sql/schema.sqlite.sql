-- Schéma SQLite (tests locaux uniquement). Équivalent du schéma MySQL.
CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(64) NOT NULL PRIMARY KEY,
  v VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email VARCHAR(190) NOT NULL,
  name VARCHAR(120) NOT NULL,
  last_name VARCHAR(80) NOT NULL DEFAULT '',
  first_name VARCHAR(80) NOT NULL DEFAULT '',
  member_no INTEGER NOT NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'member',
  status VARCHAR(16) NOT NULL DEFAULT 'invited',
  password_hash VARCHAR(255) NULL,
  totp_secret_enc VARCHAR(255) NULL,
  totp_enabled INTEGER NOT NULL DEFAULT 0,
  totp_last_step BIGINT NOT NULL DEFAULT 0,
  failed_count INT NOT NULL DEFAULT 0,
  locked_until VARCHAR(19) NULL,
  created_at VARCHAR(19) NOT NULL,
  last_login_at VARCHAR(19) NULL,
  last_seen_at VARCHAR(19) NULL
);

CREATE TABLE IF NOT EXISTS invitations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token_hash CHAR(64) NOT NULL,
  purpose VARCHAR(16) NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  expires_at VARCHAR(19) NOT NULL,
  used_at VARCHAR(19) NULL,
  data VARCHAR(190) NULL,
  CONSTRAINT fk_inv_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS recovery_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  code_hash CHAR(64) NOT NULL,
  used_at VARCHAR(19) NULL,
  CONSTRAINT fk_rc_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  stage VARCHAR(8) NOT NULL,
  csrf CHAR(64) NOT NULL,
  remember INTEGER NOT NULL DEFAULT 0,
  created_at VARCHAR(19) NOT NULL,
  expires_at VARCHAR(19) NOT NULL,
  CONSTRAINT fk_sess_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS inventories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind VARCHAR(8) NOT NULL,
  owner_user_id INTEGER NULL,
  name VARCHAR(120) NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  CONSTRAINT fk_invent_owner FOREIGN KEY (owner_user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS inventory_shares (
  inventory_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  level VARCHAR(8) NOT NULL,
  granted_by INTEGER NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  PRIMARY KEY (inventory_id, user_id),
  CONSTRAINT fk_sh_inv FOREIGN KEY (inventory_id) REFERENCES inventories(id),
  CONSTRAINT fk_sh_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at VARCHAR(19) NOT NULL,
  user_id INTEGER NULL,
  action VARCHAR(48) NOT NULL,
  inventory_id INTEGER NULL,
  target VARCHAR(190) NULL,
  detail VARCHAR(500) NULL,
  ip_hash CHAR(16) NULL
);

CREATE TABLE IF NOT EXISTS throttle (
  k CHAR(64) NOT NULL PRIMARY KEY,
  n INT NOT NULL,
  first_at VARCHAR(19) NOT NULL,
  locked_until VARCHAR(19) NULL
);


CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email ON users(email);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_member_no ON users(member_no);
CREATE UNIQUE INDEX IF NOT EXISTS uq_inv_token ON invitations(token_hash);
CREATE INDEX IF NOT EXISTS ix_inv_user ON invitations(user_id);
CREATE INDEX IF NOT EXISTS ix_rc_user ON recovery_codes(user_id);
CREATE INDEX IF NOT EXISTS ix_sess_user ON sessions(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_inv_owner ON inventories(owner_user_id);
CREATE INDEX IF NOT EXISTS ix_audit_at ON audit_log(at);
CREATE INDEX IF NOT EXISTS ix_audit_user ON audit_log(user_id);
