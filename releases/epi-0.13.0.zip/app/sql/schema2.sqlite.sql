CREATE TABLE IF NOT EXISTS list_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inventory_id INTEGER NOT NULL REFERENCES inventories(id),
  kind TEXT NOT NULL,
  label TEXT NOT NULL,
  code TEXT NULL,
  limited INTEGER NOT NULL DEFAULT 0,
  sys TEXT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  UNIQUE (inventory_id, kind, label)
);
CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inventory_id INTEGER NOT NULL REFERENCES inventories(id),
  uid TEXT NOT NULL UNIQUE,
  code TEXT NOT NULL,
  seq INTEGER NOT NULL,
  type_id INTEGER NOT NULL REFERENCES list_values(id),
  etat_id INTEGER NOT NULL REFERENCES list_values(id),
  marque_id INTEGER NULL REFERENCES list_values(id),
  activite_id INTEGER NULL REFERENCES list_values(id),
  modele TEXT NOT NULL DEFAULT '',
  fab TEXT NOT NULL DEFAULT '',
  achat TEXT NOT NULL DEFAULT '',
  mes TEXT NOT NULL DEFAULT '',
  ctrl TEXT NOT NULL DEFAULT '',
  fournisseur TEXT NOT NULL DEFAULT '',
  longueur TEXT NOT NULL DEFAULT '',
  lot TEXT NOT NULL DEFAULT '',
  par TEXT NOT NULL DEFAULT '',
  remarque TEXT NOT NULL DEFAULT '',
  prix REAL NOT NULL DEFAULT 0,
  prix_m REAL NOT NULL DEFAULT 0,
  parent_uid TEXT NULL,
  vie_util REAL NULL,
  vie_totale REAL NULL,
  created_at TEXT NOT NULL,
  created_by INTEGER NULL,
  updated_at TEXT NOT NULL,
  updated_by INTEGER NULL
);
CREATE INDEX IF NOT EXISTS ix_item_inv ON items(inventory_id);
CREATE INDEX IF NOT EXISTS ix_item_parent ON items(parent_uid);
CREATE TABLE IF NOT EXISTS item_measures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  d TEXT NOT NULL,
  l REAL NOT NULL,
  par TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_meas_item ON item_measures(item_id);
CREATE TABLE IF NOT EXISTS uid_counters (
  inventory_id INTEGER NOT NULL,
  code TEXT NOT NULL,
  last INTEGER NOT NULL,
  PRIMARY KEY (inventory_id, code)
);

CREATE TABLE IF NOT EXISTS club_config (
  k TEXT NOT NULL PRIMARY KEY,
  v TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inventory_id INTEGER NOT NULL REFERENCES inventories(id),
  sha256 TEXT NOT NULL,
  size INTEGER NOT NULL,
  mime TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (inventory_id, sha256)
);
CREATE TABLE IF NOT EXISTS item_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  file_id INTEGER NOT NULL REFERENCES files(id),
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  is_main INTEGER NOT NULL DEFAULT 0,
  added_by INTEGER NULL,
  created_at TEXT NOT NULL,
  UNIQUE (item_id, file_id, kind)
);
CREATE INDEX IF NOT EXISTS ix_if_item ON item_files(item_id);
CREATE INDEX IF NOT EXISTS ix_if_file ON item_files(file_id)
