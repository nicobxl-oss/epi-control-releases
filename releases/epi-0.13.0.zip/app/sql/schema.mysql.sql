-- Schéma MySQL / MariaDB (utf8mb4). Dates en UTC, format 'YYYY-MM-DD HH:MM:SS'.
CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(64) NOT NULL PRIMARY KEY,
  v VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  name VARCHAR(120) NOT NULL,
  last_name VARCHAR(80) NOT NULL DEFAULT '',
  first_name VARCHAR(80) NOT NULL DEFAULT '',
  member_no INT UNSIGNED NOT NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'member',
  status VARCHAR(16) NOT NULL DEFAULT 'invited',
  password_hash VARCHAR(255) NULL,
  totp_secret_enc VARCHAR(255) NULL,
  totp_enabled TINYINT(1) NOT NULL DEFAULT 0,
  totp_last_step BIGINT NOT NULL DEFAULT 0,
  failed_count INT NOT NULL DEFAULT 0,
  locked_until VARCHAR(19) NULL,
  created_at VARCHAR(19) NOT NULL,
  last_login_at VARCHAR(19) NULL,
  last_seen_at VARCHAR(19) NULL,
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_member_no (member_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invitations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  purpose VARCHAR(16) NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  expires_at VARCHAR(19) NOT NULL,
  used_at VARCHAR(19) NULL,
  data VARCHAR(190) NULL,
  UNIQUE KEY uq_inv_token (token_hash),
  KEY ix_inv_user (user_id),
  CONSTRAINT fk_inv_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS recovery_codes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  code_hash CHAR(64) NOT NULL,
  used_at VARCHAR(19) NULL,
  KEY ix_rc_user (user_id),
  CONSTRAINT fk_rc_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  stage VARCHAR(8) NOT NULL,
  csrf CHAR(64) NOT NULL,
  remember TINYINT(1) NOT NULL DEFAULT 0,
  created_at VARCHAR(19) NOT NULL,
  expires_at VARCHAR(19) NOT NULL,
  KEY ix_sess_user (user_id),
  CONSTRAINT fk_sess_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  kind VARCHAR(8) NOT NULL,
  owner_user_id INT UNSIGNED NULL,
  name VARCHAR(120) NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  UNIQUE KEY uq_inv_owner (owner_user_id),
  CONSTRAINT fk_invent_owner FOREIGN KEY (owner_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_shares (
  inventory_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  level VARCHAR(8) NOT NULL,
  granted_by INT UNSIGNED NOT NULL,
  created_at VARCHAR(19) NOT NULL,
  PRIMARY KEY (inventory_id, user_id),
  CONSTRAINT fk_sh_inv FOREIGN KEY (inventory_id) REFERENCES inventories(id),
  CONSTRAINT fk_sh_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  at VARCHAR(19) NOT NULL,
  user_id INT UNSIGNED NULL,
  action VARCHAR(48) NOT NULL,
  inventory_id INT UNSIGNED NULL,
  target VARCHAR(190) NULL,
  detail VARCHAR(500) NULL,
  ip_hash CHAR(16) NULL,
  KEY ix_audit_at (at),
  KEY ix_audit_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS throttle (
  k CHAR(64) NOT NULL PRIMARY KEY,
  n INT NOT NULL,
  first_at VARCHAR(19) NOT NULL,
  locked_until VARCHAR(19) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
