<?php
declare(strict_types=1);
namespace Epi;

/** Limitation des essais ratés (par compte et par adresse IP). */
final class Throttle
{
    public function __construct(private Db $db) {}

    public static function key(string $kind, string $value): string { return Crypto::hash($kind . ':' . strtolower($value)); }

    /** Secondes restantes avant la fin du blocage, 0 si libre. */
    public function lockedFor(string $key): int
    {
        $r = $this->db->one('SELECT locked_until FROM throttle WHERE k = ?', [$key]);
        $t = $r ? Clock::parse($r['locked_until']) : null;
        return $t !== null && $t > Clock::now() ? $t - Clock::now() : 0;
    }

    public function fail(string $key, int $max, int $windowSec, int $lockSec): void
    {
        $r = $this->db->one('SELECT n, first_at FROM throttle WHERE k = ?', [$key]);
        $now = Clock::now();
        if (!$r || (Clock::parse($r['first_at']) ?? 0) + $windowSec < $now) {
            $n = 1; $first = Clock::ts();
        } else { $n = (int)$r['n'] + 1; $first = $r['first_at']; }
        $lock = $n >= $max ? Clock::ts($now + $lockSec) : null;
        if ($lock) { $n = 0; $first = Clock::ts(); }
        if ($r) $this->db->run('UPDATE throttle SET n = ?, first_at = ?, locked_until = ? WHERE k = ?', [$n, $first, $lock, $key]);
        else $this->db->run('INSERT INTO throttle (k, n, first_at, locked_until) VALUES (?,?,?,?)', [$key, $n, $first, $lock]);
    }

    public function reset(string $key): void { $this->db->run('DELETE FROM throttle WHERE k = ?', [$key]); }
}
