<?php
declare(strict_types=1);
namespace Epi;

/** Envoi d'e-mails (fonction mail() de PHP, que one.com relaie). L'adresse d'expéditeur et l'adresse du site sont dans la table « settings ». */
final class Mailer
{
    /** Messages « envoyés » quand config['mail_transport'] = 'memory' (tests). */
    public static array $sent = [];

    public function __construct(private Db $db, private array $config) {}

    private function setting(string $k): string { return (string)($this->db->val('SELECT v FROM settings WHERE k = ?', [$k]) ?? ''); }
    private function save(string $k, string $v): void
    {
        if ($this->db->val('SELECT 1 FROM settings WHERE k = ?', [$k]) !== null) $this->db->run('UPDATE settings SET v = ? WHERE k = ?', [$v, $k]);
        else $this->db->run('INSERT INTO settings (k, v) VALUES (?,?)', [$k, $v]);
    }
    public static function validAddress(string $a): bool { return strlen($a) <= 120 && !preg_match('/[\r\n,;<>"\s]/', $a) && filter_var($a, FILTER_VALIDATE_EMAIL) !== false; }

    public function from(): string { $f = $this->setting('mail_from'); return self::validAddress($f) ? $f : ''; }
    public function setFrom(string $a): void
    {
        $a = trim($a);
        if ($a !== '' && !self::validAddress($a)) throw new ApiError(422, 'invalid_email');
        $this->save('mail_from', $a);
    }
    /** Adresse du site, mémorisée quand un administrateur connecté ouvre l'application (jamais déduite d'une requête anonyme : sinon un faux en-tête Host détournerait les liens). */
    public function baseUrl(): string { $b = $this->setting('base_url'); return preg_match('#^https?://[A-Za-z0-9.-]+(:\d+)?$#', $b) ? $b : ''; }
    public function rememberBase(string $host, string $proto): void
    {
        $host = strtolower(trim($host)); $proto = $proto === 'http' ? 'http' : 'https';
        if (!preg_match('/^[a-z0-9.-]+(:\d+)?$/', $host)) return;
        $url = $proto . '://' . $host;
        if ($this->setting('base_url') !== $url) $this->save('base_url', $url);
    }
    public function enabled(): bool { return $this->from() !== '' && $this->baseUrl() !== ''; }

    public function send(string $to, string $subject, string $text): bool
    {
        $from = $this->from();
        if ($from === '' || !self::validAddress($to)) return false;
        if (($this->config['mail_transport'] ?? '') === 'memory') { self::$sent[] = ['to' => $to, 'subject' => $subject, 'text' => $text, 'from' => $from]; return true; }
        if (($this->config['mail_transport'] ?? '') === 'file' && !empty($this->config['mail_file'])) { return @file_put_contents((string)$this->config['mail_file'], json_encode(['to' => $to, 'subject' => $subject, 'text' => $text, 'from' => $from], JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND) !== false; }   // essais locaux uniquement
        $hdr = "From: Registre EPI <$from>\r\nReply-To: $from\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\nX-Mailer: Registre-EPI\r\n";
        // one.com refuse le 5e paramètre (-f) : l'expéditeur vient de l'en-tête From
        return (bool)@mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', str_replace("\n", "\r\n", str_replace("\r\n", "\n", $text)), $hdr);
    }
}
