<?php
declare(strict_types=1);
namespace Epi;

/** Journal d'audit : qui a fait quoi, quand. Les adresses IP sont stockées hachées (court). */
final class Audit
{
    public function __construct(private Db $db) {}

    public function log(?int $userId, string $action, ?int $inventoryId = null, ?string $target = null, ?string $detail = null, ?string $ip = null): void
    {
        $this->db->run(
            'INSERT INTO audit_log (at, user_id, action, inventory_id, target, detail, ip_hash) VALUES (?,?,?,?,?,?,?)',
            [Clock::ts(), $userId, $action, $inventoryId, $target === null ? null : mb_substr($target, 0, 190), $detail === null ? null : mb_substr($detail, 0, 500), $ip === null ? null : substr(Crypto::hash($ip), 0, 16)]
        );
        if (random_int(1, 200) === 1) $this->purge();
    }

    /** Journal lisible : avec le nom de la personne. $scope : 'club' (actions sur le matériel du club) ou 'accounts' (comptes et connexions). */
    public function feed(string $scope, int $limit = 300): array
    {
        $where = $scope === 'club' ? 'a.inventory_id IS NOT NULL AND a.action LIKE \'item.%\' OR a.action LIKE \'list.%\'' : 'a.action NOT LIKE \'item.%\' AND a.action NOT LIKE \'list.%\'';
        return $this->db->all('SELECT a.id, a.at, a.user_id, a.action, a.target, a.detail, a.ip_hash, u.name AS user_name, u.member_no FROM audit_log a LEFT JOIN users u ON u.id = a.user_id WHERE ' . $where . ' ORDER BY a.id DESC LIMIT ' . max(1, min(1000, $limit)));
    }

    /** Conservation : 1 an. Appelé de temps en temps lors d'une écriture. */
    public function purge(): int
    {
        return $this->db->run('DELETE FROM audit_log WHERE at < ?', [Clock::ts(Clock::now() - 365 * 86400)]);
    }

    public function recent(int $limit = 200): array
    {
        return $this->db->all('SELECT id, at, user_id, action, inventory_id, target, detail FROM audit_log ORDER BY id DESC LIMIT ' . max(1, min(1000, $limit)));
    }
}
