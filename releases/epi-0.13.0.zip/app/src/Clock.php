<?php
declare(strict_types=1);
namespace Epi;

/** Horloge unique du service (UTC en base). Remplaçable dans les tests. */
final class Clock
{
    public static ?int $fixed = null;

    public static function now(): int { return self::$fixed ?? time(); }
    public static function ts(?int $t = null): string { return gmdate('Y-m-d H:i:s', $t ?? self::now()); }
    public static function parse(?string $s): ?int
    {
        if ($s === null || $s === '') return null;
        $t = strtotime($s . ' UTC');
        return $t === false ? null : $t;
    }
    public static function advance(int $seconds): void { self::$fixed = self::now() + $seconds; }
}
