<?php
declare(strict_types=1);
namespace Epi;

/** Comptes : invitation, activation (mot de passe + 2FA), réinitialisation, désactivation, rôles. */
final class Users
{
    public const ROLES = ['member', 'manager', 'admin'];
    public const INVITE_TTL = 7 * 86400;
    public const FORGOT_TTL = 3600;

    public function __construct(private Db $db, private Crypto $crypto, private Audit $audit, private Auth $auth, private string $issuer = 'Registre EPI', private ?Mailer $mailer = null) {}

    public static function memberLabel(int $n): string { return 'M' . str_pad((string)$n, 2, '0', STR_PAD_LEFT); }

    /** Nom affiché partout : NOM en majuscules, puis le prénom. */
    public static function displayName(string $last, string $first): string
    {
        $last = mb_strtoupper(trim($last)); $first = trim($first);
        return $first !== '' ? $last . ' ' . $first : $last;
    }
    /** Coupe un nom complet « Prénom NOM » : le dernier mot est le NOM, le reste le prénom (migration et anciens appels). */
    public static function splitName(string $full): array
    {
        $w = preg_split('/\s+/u', trim($full), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($w) < 2) return [mb_strtoupper($w[0] ?? ''), ''];
        $last = array_pop($w);
        return [mb_strtoupper($last), implode(' ', $w)];
    }
    private static function greet(array $u): string { return trim((string)($u['first_name'] ?? '')) !== '' ? trim((string)$u['first_name']) : (string)$u['name']; }
    private static function cleanPart(string $v, int $max, string $err): string
    {
        $v = trim(preg_replace('/\s+/u', ' ', $v) ?? '');
        if ($v === '' || mb_strlen($v) > $max) throw new ApiError(422, $err);
        return $v;
    }

    private function requireAdmin(array $actor): void
    {
        if (($actor['role'] ?? '') !== 'admin' || ($actor['status'] ?? 'active') !== 'active') throw new ApiError(403, 'forbidden');
    }

    public static function checkPassword(string $pw, string $email): void
    {
        if (mb_strlen($pw) < 12) throw new ApiError(422, 'password_too_short');
        if (strtolower($pw) === strtolower($email) || preg_match('/^(.)\1+$/u', $pw)) throw new ApiError(422, 'password_too_weak');
    }

    private function nextMemberNo(): int
    {
        return $this->db->tx(function () {
            $this->db->run(($this->db->isSqlite() ? 'INSERT OR IGNORE' : 'INSERT IGNORE') . " INTO settings (k, v) VALUES ('member_seq', '0')");
            $this->db->run("UPDATE settings SET v = CAST(v AS INTEGER) + 1 WHERE k = 'member_seq'");
            return (int)$this->db->val("SELECT v FROM settings WHERE k = 'member_seq'");
        });
    }

    private function newInvitation(int $userId, string $purpose, int $ttl = self::INVITE_TTL): string
    {
        $this->db->run('UPDATE invitations SET used_at = ? WHERE user_id = ? AND used_at IS NULL', [Clock::ts(), $userId]);
        $token = Crypto::token();
        $this->db->run('INSERT INTO invitations (user_id, token_hash, purpose, created_at, expires_at) VALUES (?,?,?,?,?)',
            [$userId, Crypto::hash($token), $purpose, Clock::ts(), Clock::ts(Clock::now() + $ttl)]);
        return $token;
    }

    /** Crée le compte (statut « invited »), son inventaire personnel et un lien d'invitation. */
    public function invite(array $actor, string $email, string $name, string $role, ?string $ip = null, bool $sendMail = false, ?string $first = null): array
    {
        $this->requireAdmin($actor);
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) throw new ApiError(422, 'invalid_email');
        if ($first !== null) { $last = self::cleanPart($name, 80, 'invalid_name'); $first = self::cleanPart($first, 80, 'invalid_first_name'); }   // NOM et prénom saisis séparément
        else { if (trim($name) === '' || mb_strlen(trim($name)) > 120) throw new ApiError(422, 'invalid_name'); [$last, $first] = self::splitName($name); }
        $name = self::displayName($last, $first);
        if (!in_array($role, self::ROLES, true)) throw new ApiError(422, 'invalid_role');
        if ($this->db->one('SELECT id FROM users WHERE email = ?', [$email])) throw new ApiError(409, 'email_taken');
        $r = $this->db->tx(function () use ($actor, $email, $name, $last, $first, $role, $ip) {
            $no = $this->nextMemberNo();
            $id = $this->db->insert('INSERT INTO users (email, name, last_name, first_name, member_no, role, status, created_at) VALUES (?,?,?,?,?,?,?,?)', [$email, $name, mb_strtoupper($last), $first, $no, $role, 'invited', Clock::ts()]);
            $this->db->run('INSERT INTO inventories (kind, owner_user_id, name, created_at) VALUES (?,?,?,?)', ['member', $id, 'Matériel de ' . $name, Clock::ts()]);
            $token = $this->newInvitation($id, 'invite');
            $this->audit->log((int)$actor['id'], 'user.invite', null, $email, $role . ' ' . self::memberLabel($no), $ip);
            return ['user_id' => $id, 'member_no' => $no, 'member' => self::memberLabel($no), 'token' => $token];
        });
        $r['mail'] = $sendMail ? $this->mailInvitation($actor, ['id' => $r['user_id'], 'name' => $name, 'first_name' => $first, 'email' => $email, 'member_no' => $r['member_no']], $r['token'], 'invite', $ip) : 'not_requested';
        return $r;
    }

    /** Envoie le lien d'activation par e-mail. Renvoie sent, failed ou not_configured ; le lien reste de toute façon utilisable à la main. */
    private function mailInvitation(array $actor, array $u, string $token, string $purpose, ?string $ip): string
    {
        if (!$this->mailer || !$this->mailer->enabled()) return 'not_configured';
        $club = trim((string)($this->db->val("SELECT v FROM club_config WHERE k = 'nom'") ?? ''));
        $link = $this->mailer->baseUrl() . '/compte.html#/invitation/' . $token;
        $who = trim((string)($actor['name'] ?? ''));
        $head = $purpose === 'reset'
            ? "Votre accès au Registre EPI" . ($club !== '' ? " de " . $club : '') . " a été réinitialisé" . ($who !== '' ? " par " . $who : '') . ". Pour le remettre en service, ouvrez ce lien (valable 7 jours, utilisable une seule fois) :"
            : ($who !== '' ? $who : "Un administrateur") . " vous invite à utiliser le Registre EPI" . ($club !== '' ? " de " . $club : '') . ", qui sert à suivre le matériel de sécurité (cordes, casques, harnais…). Pour activer votre compte, ouvrez ce lien (valable 7 jours, utilisable une seule fois) :";
        $text = "Bonjour " . self::greet($u) . ",\n\n" . $head . "\n\n" . $link . "\n\n"
            . "L'activation se fait en 3 étapes :\n"
            . "1. choisir votre mot de passe (12 caractères minimum) ;\n"
            . "2. installer une application d'authentification sur votre téléphone (Google Authenticator, Microsoft Authenticator, Aegis, FreeOTP…) et y ajouter votre compte en scannant le QR code affiché ;\n"
            . "3. taper le code à 6 chiffres affiché par l'application, puis noter vos codes de secours.\n\n"
            . "Votre numéro de membre : " . self::memberLabel((int)$u['member_no']) . ".\n\n"
            . "Si vous n'attendiez pas ce message, ignorez-le : sans ce lien, rien ne se passe.\n";
        $ok = $this->mailer->send($u['email'], ($purpose === 'reset' ? 'Accès réinitialisé' : 'Invitation') . ' — Registre EPI' . ($club !== '' ? ' ' . $club : ''), $text);
        $this->audit->log((int)$actor['id'], $ok ? 'user.invite_mail' : 'user.invite_mail_fail', null, $u['email'], null, $ip);
        return $ok ? 'sent' : 'failed';
    }

    /** Nouveau lien pour un compte pas encore activé (l'ancien lien cesse de fonctionner), avec envoi facultatif par e-mail. */
    public function resend(array $actor, int $userId, bool $sendMail, ?string $ip = null): array
    {
        $this->requireAdmin($actor);
        $u = $this->find($userId);
        if ($u['status'] !== 'invited') throw new ApiError(409, 'not_invited');
        $purpose = (string)($this->db->val('SELECT purpose FROM invitations WHERE user_id = ? AND purpose IN (\'invite\',\'reset\') ORDER BY id DESC LIMIT 1', [$u['id']]) ?: 'invite');
        $token = $this->db->tx(fn() => $this->newInvitation((int)$u['id'], $purpose));
        $this->audit->log((int)$actor['id'], 'user.invite_renew', null, $u['email'], null, $ip);
        return ['token' => $token, 'mail' => $sendMail ? $this->mailInvitation($actor, $u, $token, $purpose, $ip) : 'not_requested'];
    }

    /** $forgot : lien « mot de passe oublié » (purpose forgot) ; sinon invitation ou réinitialisation par un administrateur. Les deux ne sont jamais interchangeables. */
    private function openInvitation(string $token, bool $forgot = false): array
    {
        $i = $this->db->one('SELECT * FROM invitations WHERE token_hash = ?', [Crypto::hash($token)]);
        if (!$i || !in_array($i['purpose'], $forgot ? ['forgot'] : ['invite', 'reset'], true) || $i['used_at'] !== null || (Clock::parse($i['expires_at']) ?? 0) <= Clock::now()) throw new ApiError(410, 'invitation_invalid');
        $u = $this->db->one('SELECT * FROM users WHERE id = ?', [$i['user_id']]);
        if (!$u || $u['status'] === 'disabled') throw new ApiError(410, 'invitation_invalid');
        return [$i, $u];
    }

    public function invitationInfo(string $token): array
    {
        [$i, $u] = $this->openInvitation($token);
        return ['name' => $u['name'], 'email' => $u['email'], 'purpose' => $i['purpose'], 'member' => self::memberLabel((int)$u['member_no'])];
    }

    /** Génère (ou régénère) le secret 2FA en attente et renvoie de quoi le saisir dans l'appli. */
    public function activateStart(string $token): array
    {
        [, $u] = $this->openInvitation($token);
        $secret = Totp::newSecret();
        $this->db->run('UPDATE users SET totp_secret_enc = ?, totp_enabled = 0 WHERE id = ?', [$this->crypto->encrypt($secret), $u['id']]);
        return ['secret' => $secret, 'uri' => Totp::uri($secret, $u['email'], $this->issuer)];
    }

    /** Fixe le mot de passe, active la 2FA (code à confirmer) et renvoie les codes de secours, affichés une seule fois. */
    public function activateFinish(string $token, string $password, string $code, ?string $ip = null): array
    {
        [$i, $u] = $this->openInvitation($token);
        self::checkPassword($password, $u['email']);
        $plain = $u['totp_secret_enc'] ? $this->crypto->decrypt($u['totp_secret_enc']) : null;
        if ($plain === null) throw new ApiError(409, 'totp_not_started');
        $step = Totp::verify($plain, $code, 0);
        if ($step === null) throw new ApiError(422, 'invalid_code');
        $codes = Crypto::recoveryCodes();
        $this->db->tx(function () use ($u, $i, $password, $step, $codes, $ip) {
            $this->db->run('UPDATE users SET password_hash = ?, totp_enabled = 1, totp_last_step = ?, status = ?, failed_count = 0 WHERE id = ?',
                [$this->crypto->hashPassword($password), $step, 'active', $u['id']]);
            $this->db->run('DELETE FROM recovery_codes WHERE user_id = ?', [$u['id']]);
            foreach ($codes as $c) $this->db->run('INSERT INTO recovery_codes (user_id, code_hash) VALUES (?,?)', [$u['id'], Crypto::hash(Crypto::normalizeRecovery($c))]);
            $this->db->run('UPDATE invitations SET used_at = ? WHERE id = ?', [Clock::ts(), $i['id']]);
            $this->audit->log((int)$u['id'], $i['purpose'] === 'reset' ? 'user.reset_done' : 'user.activated', null, $u['email'], null, $ip);
        });
        $this->auth->revokeAll((int)$u['id']);
        return ['recovery_codes' => $codes];
    }

    /** Mot de passe oublié : envoie un lien valable 1 heure. Réponse toujours identique, que l'adresse existe ou non. */
    public function forgot(string $email, string $ip): void
    {
        $email = strtolower(trim($email));
        $t = new Throttle($this->db); $ka = Throttle::key('forgot', $email); $ki = Throttle::key('forgotip', $ip);
        foreach ([$ka, $ki] as $k) if ($t->lockedFor($k) > 0) { usleep(random_int(250000, 450000)); return; }
        $t->fail($ka, 3, 3600, 3600); $t->fail($ki, 10, 3600, 3600);
        $u = $email !== '' ? $this->db->one('SELECT * FROM users WHERE email = ?', [$email]) : null;
        $sent = false;
        if ($u && $u['status'] === 'active' && $u['password_hash'] && (int)$u['totp_enabled'] === 1 && $this->mailer && $this->mailer->enabled()) {
            $token = $this->db->tx(fn() => $this->newInvitation((int)$u['id'], 'forgot', self::FORGOT_TTL));
            $link = $this->mailer->baseUrl() . '/compte.html#/reinit/' . $token;
            $sent = $this->mailer->send($u['email'], 'Réinitialisation de votre mot de passe — Registre EPI',
                "Bonjour " . self::greet($u) . ",\n\nVous avez demandé à changer votre mot de passe du Registre EPI. Ouvrez ce lien (valable 1 heure, utilisable une seule fois) :\n\n" . $link . "\n\nVotre application d’authentification reste nécessaire pour vous connecter.\n\nSi vous n’êtes pas à l’origine de cette demande, ignorez ce message : votre mot de passe actuel reste valable.\n");
            $this->audit->log((int)$u['id'], $sent ? 'user.forgot' : 'user.forgot_fail', null, $u['email'], null, $ip);
        } elseif ($u && $u['status'] === 'active') error_log('[epi] mot de passe oublié demandé mais l’envoi d’e-mails n’est pas configuré');
        if (!$sent) usleep(random_int(250000, 450000));   // même durée de réponse qu'un envoi réel
    }

    public function resetInfo(string $token): array
    {
        [, $u] = $this->openInvitation($token, true);
        return ['name' => $u['name'], 'email' => $u['email']];
    }

    /** Change le mot de passe seulement : la double authentification et les codes de secours restent. */
    public function resetFinish(string $token, string $password, ?string $ip = null): void
    {
        [$i, $u] = $this->openInvitation($token, true);
        self::checkPassword($password, $u['email']);
        $this->db->tx(function () use ($u, $i, $password, $ip) {
            $this->db->run('UPDATE users SET password_hash = ?, failed_count = 0, locked_until = NULL WHERE id = ?', [$this->crypto->hashPassword($password), $u['id']]);
            $this->db->run('UPDATE invitations SET used_at = ? WHERE user_id = ? AND used_at IS NULL', [Clock::ts(), $u['id']]);
            $this->audit->log((int)$u['id'], 'user.password_reset', null, $u['email'], null, $ip);
        });
        $this->auth->revokeAll((int)$u['id']);
    }

    /** Mot de passe ou téléphone perdu : remet à zéro mot de passe et 2FA, nouveau lien. */
    public function reset(array $actor, int $userId, ?string $ip = null): array
    {
        $this->requireAdmin($actor);
        $u = $this->find($userId);
        if ($u['status'] === 'disabled') throw new ApiError(409, 'user_disabled');
        $token = $this->db->tx(function () use ($u) {
            $this->db->run('UPDATE users SET password_hash = NULL, totp_secret_enc = NULL, totp_enabled = 0, totp_last_step = 0, status = ? WHERE id = ?', ['invited', $u['id']]);
            $this->db->run('DELETE FROM recovery_codes WHERE user_id = ?', [$u['id']]);
            return $this->newInvitation((int)$u['id'], 'reset');
        });
        $this->auth->revokeAll($userId);
        $this->audit->log((int)$actor['id'], 'user.reset', null, $u['email'], null, $ip);
        return ['token' => $token];
    }

    /** Compte désactivé → de nouveau invité : nouveau mot de passe et nouvelle 2FA à créer, lien valable 7 jours. */
    public function reactivate(array $actor, int $userId, ?string $ip = null): array
    {
        $this->requireAdmin($actor);
        $u = $this->find($userId);
        if ($u['status'] !== 'disabled') throw new ApiError(409, 'not_disabled');
        $token = $this->db->tx(function () use ($u) {
            $this->db->run('UPDATE users SET password_hash = NULL, totp_secret_enc = NULL, totp_enabled = 0, totp_last_step = 0, failed_count = 0, locked_until = NULL, status = ? WHERE id = ?', ['invited', $u['id']]);
            $this->db->run('DELETE FROM recovery_codes WHERE user_id = ?', [$u['id']]);
            return $this->newInvitation((int)$u['id'], 'reset');
        });
        $this->auth->revokeAll($userId);
        $this->audit->log((int)$actor['id'], 'user.reactivate', null, $u['email'], null, $ip);
        return ['token' => $token];
    }

    private function activeAdmins(): int { return (int)$this->db->val("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active'"); }

    public function disable(array $actor, int $userId, ?string $ip = null): void
    {
        $this->requireAdmin($actor);
        $u = $this->find($userId);
        if ($u['role'] === 'admin' && $u['status'] === 'active' && $this->activeAdmins() <= 1) throw new ApiError(409, 'last_admin');
        $this->db->tx(function () use ($u) {
            $this->db->run('UPDATE users SET status = ? WHERE id = ?', ['disabled', $u['id']]);
            // ses partages disparaissent, ainsi que ceux accordés sur son inventaire
            $this->db->run('DELETE FROM inventory_shares WHERE user_id = ? OR granted_by = ? OR inventory_id IN (SELECT id FROM inventories WHERE owner_user_id = ?)', [$u['id'], $u['id'], $u['id']]);
            $this->db->run('UPDATE invitations SET used_at = ? WHERE user_id = ? AND used_at IS NULL', [Clock::ts(), $u['id']]);
        });
        $this->auth->revokeAll($userId);
        $this->audit->log((int)$actor['id'], 'user.disable', null, $u['email'], null, $ip);
    }

    public function setRole(array $actor, int $userId, string $role, ?string $ip = null): void
    {
        $this->requireAdmin($actor);
        if (!in_array($role, self::ROLES, true)) throw new ApiError(422, 'invalid_role');
        $u = $this->find($userId);
        if ($u['role'] === 'admin' && $role !== 'admin' && $u['status'] === 'active' && $this->activeAdmins() <= 1) throw new ApiError(409, 'last_admin');
        $this->db->run('UPDATE users SET role = ? WHERE id = ?', [$role, $u['id']]);
        $this->audit->log((int)$actor['id'], 'user.role', null, $u['email'], $u['role'] . ' -> ' . $role, $ip);
    }

    /** Chacun corrige son NOM et son prénom ; le nom affiché est recomposé. L'historique déjà écrit (« mesuré par ») n'est pas réécrit. */
    public function updateProfile(array $actor, string $last, string $first, ?string $ip = null): array
    {
        $u = $this->find((int)$actor['id']);
        $last = mb_strtoupper(self::cleanPart($last, 80, 'invalid_name')); $first = self::cleanPart($first, 80, 'invalid_first_name');
        $name = self::displayName($last, $first);
        $this->db->run('UPDATE users SET last_name = ?, first_name = ?, name = ? WHERE id = ?', [$last, $first, $name, $u['id']]);
        $this->db->run("UPDATE inventories SET name = ? WHERE kind = 'member' AND owner_user_id = ?", ['Matériel de ' . $name, $u['id']]);
        if ($name !== $u['name']) $this->audit->log((int)$u['id'], 'user.profile', null, $u['email'], $u['name'] . ' → ' . $name, $ip);
        return ['name' => $name, 'last_name' => $last, 'first_name' => $first];
    }

    public const EMAIL_TTL = 86400;

    /** Demande de changement d'adresse : un lien est envoyé à la NOUVELLE adresse ; rien ne change avant qu'il soit ouvert. */
    public function requestEmailChange(array $actor, string $email, ?string $ip = null): array
    {
        $u = $this->find((int)$actor['id']);
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) throw new ApiError(422, 'invalid_email');
        if ($email === $u['email']) throw new ApiError(422, 'same_email');
        if ($this->db->one('SELECT id FROM users WHERE email = ?', [$email])) throw new ApiError(409, 'email_taken');
        if (!$this->mailer || !$this->mailer->enabled()) throw new ApiError(409, 'mail_not_configured');
        $t = new Throttle($this->db); $k = Throttle::key('emailchg', (string)$u['id']);
        if ($t->lockedFor($k) > 0) throw new ApiError(429, 'too_many_attempts');
        $t->fail($k, 5, 3600, 3600);
        $token = Crypto::token();
        $this->db->tx(function () use ($u, $token, $email) {
            $this->db->run("UPDATE invitations SET used_at = ? WHERE user_id = ? AND purpose = 'email' AND used_at IS NULL", [Clock::ts(), $u['id']]);
            $this->db->run('INSERT INTO invitations (user_id, token_hash, purpose, created_at, expires_at, data) VALUES (?,?,?,?,?,?)',
                [$u['id'], Crypto::hash($token), 'email', Clock::ts(), Clock::ts(Clock::now() + self::EMAIL_TTL), $email]);
        });
        $link = $this->mailer->baseUrl() . '/compte.html#/email/' . $token;
        $ok = $this->mailer->send($email, 'Confirmez votre nouvelle adresse — Registre EPI',
            "Bonjour " . self::greet($u) . ",\n\nVous avez demandé à utiliser cette adresse pour vous connecter au Registre EPI. Pour confirmer, ouvrez ce lien (valable 24 heures, utilisable une seule fois) :\n\n" . $link
            . "\n\nTant que vous ne l'ouvrez pas, rien ne change : vous continuez à vous connecter avec " . $u['email'] . ".\nSi vous n'êtes pas à l'origine de cette demande, ignorez ce message.\n");
        $this->audit->log((int)$u['id'], $ok ? 'user.email_request' : 'user.email_request_fail', null, $u['email'], '→ ' . $email, $ip);
        if (!$ok) throw new ApiError(502, 'mail_failed');
        return ['sent_to' => $email];
    }

    /** Ouverture du lien reçu sur la nouvelle adresse : l'adresse de connexion change. Le lien suffit (il prouve l'accès à la boîte) ; l'ancienne adresse est prévenue. */
    public function confirmEmailChange(string $token, ?string $ip = null): array
    {
        $i = $this->db->one("SELECT * FROM invitations WHERE token_hash = ? AND purpose = 'email'", [Crypto::hash($token)]);
        if (!$i || $i['used_at'] !== null || (Clock::parse($i['expires_at']) ?? 0) <= Clock::now() || !$i['data']) throw new ApiError(410, 'invitation_invalid');
        $u = $this->db->one('SELECT * FROM users WHERE id = ?', [$i['user_id']]);
        if (!$u || $u['status'] === 'disabled') throw new ApiError(410, 'invitation_invalid');
        $new = (string)$i['data'];
        if ($this->db->one('SELECT id FROM users WHERE email = ? AND id <> ?', [$new, $u['id']])) throw new ApiError(409, 'email_taken');
        $this->db->tx(function () use ($i, $u, $new) {
            $this->db->run('UPDATE users SET email = ? WHERE id = ?', [$new, $u['id']]);
            $this->db->run('UPDATE invitations SET used_at = ? WHERE id = ?', [Clock::ts(), $i['id']]);
        });
        $this->audit->log((int)$u['id'], 'user.email_change', null, $new, 'ancienne : ' . $u['email'], $ip);
        if ($this->mailer && $this->mailer->enabled())
            $this->mailer->send($u['email'], 'Votre adresse de connexion a changé — Registre EPI', "Bonjour " . self::greet($u) . ",\n\nVotre adresse de connexion au Registre EPI est maintenant " . $new . ". Si ce n'est pas vous, prévenez un administrateur du club.\n");
        return ['email' => $new];
    }

    private function find(int $id): array
    {
        $u = $this->db->one('SELECT * FROM users WHERE id = ?', [$id]);
        if (!$u) throw new ApiError(404, 'not_found');
        return $u;
    }

    public function listAll(array $actor): array
    {
        $this->requireAdmin($actor);
        return array_map(fn($u) => $u + ['member' => self::memberLabel((int)$u['member_no'])],
            array_map(function ($u) {
                $seen = Clock::parse($u['last_seen_at']); unset($u['last_seen_at']);
                return $u + ['seen_secs' => $seen === null ? null : max(0, Clock::now() - $seen), 'online' => $seen !== null && Clock::now() - $seen < 300];
            }, $this->db->all('SELECT id, email, name, last_name, first_name, member_no, role, status, created_at, last_login_at, last_seen_at FROM users ORDER BY member_no')));
    }

    /** Annuaire minimal pour choisir avec qui partager : aucun e-mail. */
    public function directory(array $actor): array
    {
        return array_map(fn($u) => $u + ['member' => self::memberLabel((int)$u['member_no'])],
            $this->db->all("SELECT id, name, member_no FROM users WHERE status = 'active' AND id <> ? ORDER BY name", [$actor['id']]));
    }
}
