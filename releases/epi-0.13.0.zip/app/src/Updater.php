<?php
declare(strict_types=1);
namespace Epi;

/**
 * Mise à jour : lit « latest.json » dans le dépôt public de versions et vérifie sa signature (Ed25519).
 * Seuls la version, l'empreinte SHA-256 et la taille du zip sont signées ; le nom du zip est toujours reconstruit à partir de la version
 * (jamais pris dans le fichier), et les nouveautés ne sont affichées que comme du texte.
 */
final class Updater
{
    /** Clé publique de signature (32 octets, base64) : seule la personne qui détient la clé secrète peut publier une version acceptée. */
    public const PUBLIC_KEY = '5o4tHJz8yhXwsPYmNO9hmjOfi8bcrpGU6Ad22acYH5g=';
    /** Dépôt public des versions (peut être remplacé par 'releases_repo' dans config.php). */
    public const RELEASES_REPO = 'nicobxl-oss/epi-control-releases';
    public const MAX_JSON = 100000;

    /** @param ?callable(string): array{0:int,1:string} $fetch  (url) => [code HTTP, corps] ; remplaçable dans les tests */
    public function __construct(private array $config = [], private $fetch = null, private ?string $publicKey = null) {}

    public function repo(): string
    {
        $r = (string)($this->config['releases_repo'] ?? self::RELEASES_REPO);
        return preg_match('#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $r) ? $r : self::RELEASES_REPO;
    }
    public function baseUrl(): string { return 'https://raw.githubusercontent.com/' . $this->repo() . '/main/'; }

    /** Message signé : identique à celui de tools/signer.html. */
    public static function message(string $version, string $sha256, int $size): string { return "epi-release-v1\n" . $version . "\n" . $sha256 . "\n" . $size; }

    private function get(string $url): array
    {
        if ($this->fetch) return ($this->fetch)($url);
        if (!function_exists('curl_init')) throw new ApiError(502, 'update_unreachable');
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'registre-epi/' . App::VERSION, CURLOPT_MAXFILESIZE => self::MAX_JSON]);
        $body = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); curl_close($c);
        if ($body === false) throw new ApiError(502, 'update_unreachable');
        return [$code, (string)$body];
    }

    /** Dernière version publiée (signature vérifiée) et comparaison avec la version installée. */
    public function check(string $current = App::VERSION): array
    {
        [$code, $body] = $this->get($this->baseUrl() . 'latest.json?cb=' . time());
        if ($code === 404) throw new ApiError(404, 'update_none_published');
        if ($code !== 200) throw new ApiError(502, 'update_unreachable', ['http' => $code]);
        if (strlen($body) > self::MAX_JSON) throw new ApiError(502, 'update_invalid');
        $j = json_decode($body, true);
        if (!is_array($j) || ($j['format'] ?? '') !== 'epi-release-v1') throw new ApiError(502, 'update_invalid');
        $ver = $j['version'] ?? null; $sha = $j['sha256'] ?? null; $size = $j['size'] ?? null; $sig = $j['signature'] ?? null;
        if (!is_string($ver) || !preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}$/', $ver) || !is_string($sha) || !preg_match('/^[0-9a-f]{64}$/', $sha)
            || !is_int($size) || $size < 1000 || $size > 60 * 1048576 || !is_string($sig)) throw new ApiError(502, 'update_invalid');
        $pk = base64_decode($this->publicKey ?? self::PUBLIC_KEY, true); $sg = base64_decode($sig, true);
        if (!function_exists('sodium_crypto_sign_verify_detached') || $pk === false || strlen($pk) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES
            || $sg === false || strlen($sg) !== SODIUM_CRYPTO_SIGN_BYTES || !sodium_crypto_sign_verify_detached($sg, self::message($ver, $sha, $size), $pk)) throw new ApiError(502, 'update_bad_signature');
        $notes = [];
        foreach (is_array($j['notes'] ?? null) ? $j['notes'] : [] as $n) if (is_string($n) && trim($n) !== '' && count($notes) < 30) $notes[] = mb_substr(trim($n), 0, 300);
        $date = is_string($j['published'] ?? null) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $j['published']) ? $j['published'] : '';
        return ['current' => $current, 'latest' => $ver, 'newer' => version_compare($ver, $current, '>'), 'published' => $date, 'size' => $size, 'sha256' => $sha, 'notes' => $notes,
            'file' => 'epi-' . $ver . '.zip', 'url' => $this->baseUrl() . 'releases/epi-' . $ver . '.zip'];
    }
}
