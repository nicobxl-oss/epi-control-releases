<?php
declare(strict_types=1);
namespace Epi;

/**
 * Droits sur les inventaires. Règles :
 *  - inventaire du club : tout membre actif lit ; responsables et admins modifient et suppriment ;
 *  - inventaire personnel : son propriétaire fait tout (y compris partager) ; un partage « read » lit,
 *    un partage « write » lit, ajoute et modifie ; seul le propriétaire supprime et gère les accès ;
 *  - un admin n'a AUCUN droit sur l'inventaire personnel d'un autre.
 */
final class Access
{
    public const ACTIONS = ['view', 'edit', 'delete', 'share'];

    public function __construct(private Db $db, private Audit $audit) {}

    public function inventory(int $id): ?array { return $this->db->one('SELECT * FROM inventories WHERE id = ?', [$id]); }
    public function clubInventory(): ?array { return $this->db->one("SELECT * FROM inventories WHERE kind = 'club'"); }

    /** @return 'none'|'read'|'write'|'owner' */
    public function level(array $user, int $inventoryId): string
    {
        if (($user['status'] ?? 'active') !== 'active') return 'none';
        $inv = $this->inventory($inventoryId);
        if (!$inv) return 'none';
        if ($inv['kind'] === 'club') return in_array($user['role'], ['manager', 'admin'], true) ? 'write' : 'read';
        if ((int)$inv['owner_user_id'] === (int)$user['id']) return 'owner';
        $s = $this->db->one('SELECT level FROM inventory_shares WHERE inventory_id = ? AND user_id = ?', [$inventoryId, $user['id']]);
        return $s ? ($s['level'] === 'write' ? 'write' : 'read') : 'none';
    }

    public function can(array $user, int $inventoryId, string $action): bool
    {
        if (!in_array($action, self::ACTIONS, true)) return false;
        $inv = $this->inventory($inventoryId);
        $lvl = $this->level($user, $inventoryId);
        if (!$inv || $lvl === 'none') return false;
        return match ($action) {
            'view' => true,
            'edit' => in_array($lvl, ['write', 'owner'], true),
            'delete' => in_array($lvl, ['write', 'owner'], true),
            'share' => $inv['kind'] === 'member' && $lvl === 'owner',
        };
    }

    public function require(array $user, int $inventoryId, string $action): void
    {
        // « introuvable » plutôt que « interdit » pour ne pas révéler l'existence d'un inventaire
        if ($this->level($user, $inventoryId) === 'none') throw new ApiError(404, 'not_found');
        if (!$this->can($user, $inventoryId, $action)) throw new ApiError(403, 'forbidden');
    }

    /** Inventaires visibles par l'utilisateur, avec son niveau. */
    public function accessible(array $user): array
    {
        $out = [];
        foreach ($this->db->all('SELECT i.*, u.name AS owner_name, u.member_no FROM inventories i LEFT JOIN users u ON u.id = i.owner_user_id ORDER BY i.kind, i.id') as $inv) {
            $lvl = $this->level($user, (int)$inv['id']);
            if ($lvl === 'none') continue;
            $out[] = ['id' => (int)$inv['id'], 'kind' => $inv['kind'], 'name' => $inv['name'], 'level' => $lvl,
                'member' => $inv['member_no'] ? Users::memberLabel((int)$inv['member_no']) : null,
                'owner' => $inv['kind'] === 'member' ? $inv['owner_name'] : null];
        }
        return $out;
    }

    public function share(array $actor, int $inventoryId, int $targetId, string $level, ?string $ip = null): void
    {
        $this->require($actor, $inventoryId, 'share');
        if (!in_array($level, ['read', 'write'], true)) throw new ApiError(422, 'invalid_level');
        if ($targetId === (int)$actor['id']) throw new ApiError(422, 'cannot_share_with_self');
        $t = $this->db->one("SELECT id, email FROM users WHERE id = ? AND status = 'active'", [$targetId]);
        if (!$t) throw new ApiError(404, 'not_found');
        $this->db->tx(function () use ($level, $actor, $inventoryId, $targetId) {   // un double clic ou deux envois simultanés donnent le même résultat, sans erreur
            $this->db->run(($this->db->isSqlite() ? 'INSERT OR IGNORE' : 'INSERT IGNORE') . ' INTO inventory_shares (inventory_id, user_id, level, granted_by, created_at) VALUES (?,?,?,?,?)', [$inventoryId, $targetId, $level, $actor['id'], Clock::ts()]);
            $this->db->run('UPDATE inventory_shares SET level = ?, granted_by = ? WHERE inventory_id = ? AND user_id = ?', [$level, $actor['id'], $inventoryId, $targetId]);
        });
        $this->audit->log((int)$actor['id'], 'share.set', $inventoryId, $t['email'], $level, $ip);
    }

    /** Le propriétaire retire un accès ; le destinataire peut aussi renoncer au sien. */
    public function revoke(array $actor, int $inventoryId, int $targetId, ?string $ip = null): void
    {
        $inv = $this->inventory($inventoryId);
        if (!$inv || $inv['kind'] !== 'member') throw new ApiError(404, 'not_found');
        $isOwner = (int)$inv['owner_user_id'] === (int)$actor['id'];
        if (!$isOwner && $targetId !== (int)$actor['id']) throw new ApiError(404, 'not_found');
        if (!$this->db->run('DELETE FROM inventory_shares WHERE inventory_id = ? AND user_id = ?', [$inventoryId, $targetId])) throw new ApiError(404, 'not_found');
        $this->audit->log((int)$actor['id'], 'share.revoke', $inventoryId, (string)$targetId, null, $ip);
    }

    public function shares(array $actor, int $inventoryId): array
    {
        $this->require($actor, $inventoryId, 'share');
        return $this->db->all('SELECT s.user_id, s.level, s.created_at, u.name, u.member_no FROM inventory_shares s JOIN users u ON u.id = s.user_id WHERE s.inventory_id = ? ORDER BY u.name', [$inventoryId]);
    }

    /** Membres actifs ayant accès à l'inventaire, quel que soit leur niveau : tout le monde pour le club, propriétaire + personnes avec qui il est partagé pour une liste personnelle. */
    public function people(int $inventoryId): array
    {
        $inv = $this->inventory($inventoryId);
        if (!$inv) return [];
        if ($inv['kind'] === 'club') $rows = $this->db->all("SELECT name, member_no FROM users WHERE status = 'active' ORDER BY name");
        else $rows = $this->db->all("SELECT name, member_no FROM users WHERE status = 'active' AND (id = ? OR id IN (SELECT user_id FROM inventory_shares WHERE inventory_id = ?)) ORDER BY name", [(int)$inv['owner_user_id'], $inventoryId]);
        return array_map(fn($r) => ['name' => (string)$r['name'], 'member' => $r['member_no'] ? Users::memberLabel((int)$r['member_no']) : ''], $rows);
    }
}
