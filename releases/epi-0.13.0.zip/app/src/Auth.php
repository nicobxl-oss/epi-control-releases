<?php
declare(strict_types=1);
namespace Epi;

/** Connexion en deux temps (mot de passe, puis code 2FA ou code de secours) et sessions. */
final class Auth
{
    public const PRE_TTL = 300;               // 5 min pour saisir le code 2FA
    public const SESSION_TTL = 12 * 3600;     // 12 h
    public const REMEMBER_TTL = 30 * 86400;   // 30 j sur appareil de confiance
    private const ACCT_MAX = 5, IP_MAX = 20, WINDOW = 900, LOCK = 900;

    public function __construct(private Db $db, private Crypto $crypto, private Audit $audit, private Throttle $throttle) {}

    /** Étape 1. @return array{ok:bool,error?:string,retry_after?:int,token?:string,csrf?:string} */
    public function login(string $email, string $password, string $ip): array
    {
        $email = strtolower(trim($email));
        $ka = Throttle::key('acct', $email); $ki = Throttle::key('ip', $ip);
        foreach ([$ka, $ki] as $k) if (($w = $this->throttle->lockedFor($k)) > 0) return ['ok' => false, 'error' => 'too_many_attempts', 'retry_after' => $w];
        $u = $this->db->one('SELECT * FROM users WHERE email = ?', [$email]);
        $good = $u && $u['status'] === 'active' && $u['password_hash'] && $this->crypto->verifyPassword($password, $u['password_hash']);
        if (!$u || !$u['password_hash']) $this->crypto->dummyVerify();
        if (!$good) {
            $this->throttle->fail($ka, self::ACCT_MAX, self::WINDOW, self::LOCK);
            $this->throttle->fail($ki, self::IP_MAX, self::WINDOW, self::LOCK);
            $this->audit->log($u ? (int)$u['id'] : null, 'login.fail', null, $email, null, $ip);
            return ['ok' => false, 'error' => 'invalid_credentials'];
        }
        return ['ok' => true] + $this->newSession((int)$u['id'], 'pre', false, self::PRE_TTL);
    }

    /** Étape 2 : code TOTP à 6 chiffres, ou code de secours (usage unique). */
    public function verifySecond(string $preToken, string $code, bool $remember, string $ip): array
    {
        $s = $this->rawSession($preToken, 'pre');
        if (!$s) return ['ok' => false, 'error' => 'session_expired'];
        $u = $this->db->one('SELECT * FROM users WHERE id = ?', [$s['user_id']]);
        if (!$u || $u['status'] !== 'active') return ['ok' => false, 'error' => 'session_expired'];
        $ka = Throttle::key('acct', $u['email']);
        if (($w = $this->throttle->lockedFor($ka)) > 0) return ['ok' => false, 'error' => 'too_many_attempts', 'retry_after' => $w];
        $ok = false; $how = 'totp';
        $plain = $u['totp_secret_enc'] ? $this->crypto->decrypt($u['totp_secret_enc']) : null;
        if (preg_match('/^\s*\d{3}\s?\d{3}\s*$/', $code)) {
            if ($plain !== null && ($step = Totp::verify($plain, $code, (int)$u['totp_last_step'])) !== null) {
                // le pas n'est consommé qu'une fois (anti-rejeu), y compris en cas de requêtes simultanées
                $ok = $this->db->run('UPDATE users SET totp_last_step = ? WHERE id = ? AND totp_last_step < ?', [$step, $u['id'], $step]) === 1;
            }
        } else {
            $h = Crypto::hash(Crypto::normalizeRecovery($code)); $how = 'recovery';
            $ok = strlen(Crypto::normalizeRecovery($code)) === 10
                && $this->db->run('UPDATE recovery_codes SET used_at = ? WHERE user_id = ? AND code_hash = ? AND used_at IS NULL', [Clock::ts(), $u['id'], $h]) === 1;
        }
        if (!$ok) {
            $this->throttle->fail($ka, self::ACCT_MAX, self::WINDOW, self::LOCK);
            $this->audit->log((int)$u['id'], '2fa.fail', null, null, null, $ip);
            return ['ok' => false, 'error' => 'invalid_code'];
        }
        $this->throttle->reset($ka);
        $this->db->run('DELETE FROM sessions WHERE token_hash = ?', [Crypto::hash($preToken)]);
        $this->db->run('UPDATE users SET last_login_at = ? WHERE id = ?', [Clock::ts(), $u['id']]);
        $this->audit->log((int)$u['id'], 'login.ok', null, null, $how . ($remember ? ' remember' : ''), $ip);
        $left = (int)$this->db->val('SELECT COUNT(*) FROM recovery_codes WHERE user_id = ? AND used_at IS NULL', [$u['id']]);
        return ['ok' => true, 'recovery_left' => $left] + $this->newSession((int)$u['id'], 'full', $remember, $remember ? self::REMEMBER_TTL : self::SESSION_TTL);
    }

    private function newSession(int $userId, string $stage, bool $remember, int $ttl): array
    {
        $token = Crypto::token(); $csrf = Crypto::token(16);
        $this->db->run('INSERT INTO sessions (token_hash, user_id, stage, csrf, remember, created_at, expires_at) VALUES (?,?,?,?,?,?,?)',
            [Crypto::hash($token), $userId, $stage, $csrf, $remember ? 1 : 0, Clock::ts(), Clock::ts(Clock::now() + $ttl)]);
        return ['token' => $token, 'csrf' => $csrf, 'ttl' => $ttl];
    }

    private function rawSession(string $token, string $stage): ?array
    {
        if ($token === '') return null;
        $s = $this->db->one('SELECT * FROM sessions WHERE token_hash = ? AND stage = ?', [Crypto::hash($token), $stage]);
        if (!$s) return null;
        if ((Clock::parse($s['expires_at']) ?? 0) <= Clock::now()) { $this->db->run('DELETE FROM sessions WHERE token_hash = ?', [$s['token_hash']]); return null; }
        return $s;
    }

    /** @return array{user:array,session:array}|null  seulement pour une session complète et un compte actif */
    public function current(string $token): ?array
    {
        $s = $this->rawSession($token, 'full');
        if (!$s) return null;
        $u = $this->db->one('SELECT id, email, name, last_name, first_name, member_no, role, status, last_seen_at FROM users WHERE id = ?', [$s['user_id']]);
        if (!$u || $u['status'] !== 'active') return null;
        // dernière activité, au plus une écriture par minute et par personne
        if (($seen = Clock::parse($u['last_seen_at'])) === null || Clock::now() - $seen >= 60) $this->db->run('UPDATE users SET last_seen_at = ? WHERE id = ?', [Clock::ts(), $u['id']]);
        unset($u['last_seen_at']);
        return ['user' => $u, 'session' => $s];
    }

    public function logout(string $token): void { $this->db->run('DELETE FROM sessions WHERE token_hash = ?', [Crypto::hash($token)]); }
    public function revokeAll(int $userId): void { $this->db->run('DELETE FROM sessions WHERE user_id = ?', [$userId]); }
    public function purgeExpired(): void
    {
        $this->db->run('DELETE FROM sessions WHERE expires_at <= ?', [Clock::ts()]);
        $this->db->run('DELETE FROM throttle WHERE locked_until IS NOT NULL AND locked_until <= ? AND n = 0', [Clock::ts()]);
    }
}
