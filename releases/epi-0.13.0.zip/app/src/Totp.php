<?php
declare(strict_types=1);
namespace Epi;

/** TOTP (RFC 6238) : SHA-1, 6 chiffres, pas de 30 s. Compatible Google Authenticator & co. */
final class Totp
{
    private const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function newSecret(): string { return self::b32encode(random_bytes(20)); }

    public static function b32encode(string $bin): string
    {
        $bits = ''; foreach (str_split($bin) as $ch) $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
        $out = ''; foreach (str_split($bits, 5) as $chunk) $out .= self::ALPHA[bindec(str_pad($chunk, 5, '0'))];
        return $out;
    }
    public static function b32decode(string $s): string
    {
        $s = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $s)); $bits = '';
        foreach (str_split($s) as $ch) $bits .= str_pad(decbin(strpos(self::ALPHA, $ch)), 5, '0', STR_PAD_LEFT);
        $out = ''; foreach (str_split($bits, 8) as $byte) if (strlen($byte) === 8) $out .= chr(bindec($byte));
        return $out;
    }

    public static function code(string $secretB32, int $step, int $digits = 6): string
    {
        $h = hash_hmac('sha1', pack('J', $step), self::b32decode($secretB32), true);
        $o = ord($h[19]) & 0x0f;
        $n = ((ord($h[$o]) & 0x7f) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
        return str_pad((string)($n % (10 ** $digits)), $digits, '0', STR_PAD_LEFT);
    }

    public static function step(?int $t = null): int { return intdiv($t ?? Clock::now(), 30); }

    /** @return int|null le pas accepté, ou null. Refuse un pas déjà utilisé (anti-rejeu). */
    public static function verify(string $secretB32, string $code, int $lastStep = 0, int $window = 1): ?int
    {
        $code = preg_replace('/\s+/', '', $code);
        if (!preg_match('/^\d{6}$/', $code)) return null;
        $now = self::step();
        for ($d = -$window; $d <= $window; $d++) {
            $s = $now + $d;
            if ($s > $lastStep && hash_equals(self::code($secretB32, $s), $code)) return $s;
        }
        return null;
    }

    public static function uri(string $secret, string $account, string $issuer): string
    {
        return 'otpauth://totp/' . rawurlencode($issuer . ':' . $account) . '?secret=' . $secret . '&issuer=' . rawurlencode($issuer) . '&algorithm=SHA1&digits=6&period=30';
    }
}
