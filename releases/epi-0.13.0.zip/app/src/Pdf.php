<?php
declare(strict_types=1);

namespace Epi;

/**
 * Petit générateur de PDF, sans dépendance : texte (Helvetica), traits et rectangles, pages A4.
 * Suffisant pour des rapports en tableau. Les textes sont en UTF-8 ; ils sont convertis en Windows-1252
 * (les caractères hors de ce jeu, rares, deviennent « ? »). Les largeurs de texte sont celles de Helvetica (approchées pour les lettres accentuées).
 */
final class Pdf
{
    public const A4_W = 841.89;   // paysage
    public const A4_H = 595.28;

    /** Largeurs Helvetica (millièmes d'em), caractères 32 à 126. */
    private const W_REG = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
    private const W_BOLD = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
        975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
        333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584];

    /** @var string[] contenu de chaque page */
    private array $pages = [];
    private string $cur = '';
    private array $meta = [];
    public float $w;
    public float $h;

    public function __construct(float $w = self::A4_W, float $h = self::A4_H, array $meta = [])
    {
        $this->w = $w; $this->h = $h; $this->meta = $meta;
        $this->addPage();
    }

    public function addPage(): void
    {
        if ($this->pages || $this->cur !== '') $this->pages[] = $this->cur;
        $this->cur = '';
        if (!$this->pages) $this->pages = [];
    }
    public function pageCount(): int { return count($this->pages) + 1; }
    /** Numéro (à partir de 1) de la page en cours d'écriture. */
    public function pageNo(): int { return count($this->pages) + 1; }

    /** Texte UTF-8 → octets Windows-1252. */
    public static function enc(string $s): string
    {
        $s = str_replace(["\u{2192}", "\u{2013}", "\u{2014}", "\u{2019}", "\u{2018}", "\u{201C}", "\u{201D}", "\u{2026}", "\u{00A0}", "\u{202F}"], ['>', '-', '-', "'", "'", '"', '"', '...', ' ', ' '], $s);
        if (function_exists('mb_convert_encoding')) {
            $o = @mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
            if (is_string($o)) return $o;
        }
        $o = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s);
        return is_string($o) ? $o : preg_replace('/[^\x20-\x7E]/', '?', $s);
    }

    /** Largeur d'un texte en points. */
    public function width(string $s, float $size, bool $bold = false): float
    {
        $t = self::enc($s); $w = 0; $tab = $bold ? self::W_BOLD : self::W_REG;
        for ($i = 0, $n = strlen($t); $i < $n; $i++) { $c = ord($t[$i]); $w += ($c >= 32 && $c <= 126) ? $tab[$c - 32] : 556; }
        return $w * $size / 1000;
    }

    /** Raccourcit un texte avec « ... » pour qu'il tienne dans $max points. */
    public function fit(string $s, float $max, float $size, bool $bold = false): string
    {
        if ($this->width($s, $size, $bold) <= $max) return $s;
        $chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        while ($chars && $this->width(implode('', $chars) . '...', $size, $bold) > $max) array_pop($chars);
        return implode('', $chars) . '...';
    }

    private static function num(float $n): string { return rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.') ?: '0'; }
    private static function col(array $c): string { return self::num($c[0]) . ' ' . self::num($c[1]) . ' ' . self::num($c[2]); }

    /** Texte dont la ligne de base est à $y (origine en haut à gauche de la page, comme à l'écran). */
    public function text(float $x, float $y, string $s, float $size = 9, bool $bold = false, array $rgb = [0, 0, 0]): void
    {
        if ($s === '') return;
        $t = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], self::enc($s));
        $this->cur .= self::col($rgb) . ' rg BT /' . ($bold ? 'F2' : 'F1') . ' ' . self::num($size) . ' Tf ' . self::num($x) . ' ' . self::num($this->h - $y) . ' Td (' . $t . ') Tj ET' . "\n";
    }
    public function textRight(float $xRight, float $y, string $s, float $size = 9, bool $bold = false, array $rgb = [0, 0, 0]): void
    {
        $this->text($xRight - $this->width($s, $size, $bold), $y, $s, $size, $bold, $rgb);
    }
    public function line(float $x1, float $y1, float $x2, float $y2, float $width = 0.5, array $rgb = [0, 0, 0]): void
    {
        $this->cur .= self::col($rgb) . ' RG ' . self::num($width) . ' w ' . self::num($x1) . ' ' . self::num($this->h - $y1) . ' m ' . self::num($x2) . ' ' . self::num($this->h - $y2) . " l S\n";
    }
    public function rect(float $x, float $y, float $w, float $h, array $fill): void
    {
        $this->cur .= self::col($fill) . ' rg ' . self::num($x) . ' ' . self::num($this->h - $y - $h) . ' ' . self::num($w) . ' ' . self::num($h) . " re f\n";
    }

    /** Renvoie le fichier PDF. $afterPages reçoit (Pdf, numéro de page, total) pour écrire en-têtes et pieds de page sur chaque page. */
    public function output(?callable $afterPages = null): string
    {
        $all = $this->pages; $all[] = $this->cur; $total = count($all);
        if ($afterPages) {
            $keep = [$this->pages, $this->cur];
            foreach ($all as $i => $content) { $this->cur = ''; $afterPages($this, $i + 1, $total); $all[$i] = $content . $this->cur; }
            [$this->pages, $this->cur] = $keep;
        }
        $objs = [];   // numéro => contenu
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = []; $n = 5;
        foreach ($all as $content) {
            $pageObj = $n++; $cObj = $n++; $kids[] = $pageObj . ' 0 R';
            $deflate = function_exists('gzcompress');
            $data = $deflate ? gzcompress($content, 6) : $content;
            $objs[$pageObj] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::num($this->w) . ' ' . self::num($this->h) . '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' . $cObj . ' 0 R >>';
            $objs[$cObj] = '<< /Length ' . strlen($data) . ($deflate ? ' /Filter /FlateDecode' : '') . " >>\nstream\n" . $data . "\nendstream";
        }
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $info = $n; $esc = fn(string $s) => str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], self::enc($s));
        $objs[$info] = '<< /Title (' . $esc((string)($this->meta['title'] ?? '')) . ') /Author (' . $esc((string)($this->meta['author'] ?? '')) . ') /Producer (Registre EPI) >>';
        ksort($objs);
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"; $pos = [];
        foreach ($objs as $no => $body) { $pos[$no] = strlen($out); $out .= $no . " 0 obj\n" . $body . "\nendobj\n"; }
        $xref = strlen($out); $max = max(array_keys($objs));
        $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) $out .= isset($pos[$i]) ? sprintf("%010d 00000 n \n", $pos[$i]) : "0000000000 65535 f \n";
        return $out . 'trailer << /Size ' . ($max + 1) . ' /Root 1 0 R /Info ' . $info . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";
    }
}
