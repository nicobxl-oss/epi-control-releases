<?php
declare(strict_types=1);
namespace Epi;

final class ApiError extends \RuntimeException
{
    public function __construct(public readonly int $status, public readonly string $errorCode, public readonly array $extra = [])
    {
        parent::__construct($errorCode);
    }
}
