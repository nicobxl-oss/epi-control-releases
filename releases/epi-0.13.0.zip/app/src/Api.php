<?php
declare(strict_types=1);
namespace Epi;

/**
 * Routeur JSON. handle() ne touche ni à $_SERVER ni aux en-têtes : il reçoit tout en paramètres
 * (testable sans serveur web) et renvoie [statut, données, cookies à poser].
 */
final class Api
{
    public const COOKIE = 'epi_s';

    public function __construct(private App $app) {}

    /** @return array{0:int,1:array,2:array} */
    public function handle(string $method, string $path, array $body, array $cookies, array $headers, string $ip, ?string $raw = null, array $query = []): array
    {
        $set = [];
        try {
            $method = strtoupper($method);
            $h = array_change_key_case($headers, CASE_LOWER);
            $this->checkOrigin($h);
            $token = (string)($cookies[self::COOKIE] ?? '');
            $parts = array_values(array_filter(explode('/', trim($path, '/')), 'strlen'));
            $route = $method . ' ' . ($parts[0] ?? '');
            $app = $this->app;

            // ---- routes sans session ----
            if ($method === 'POST' && $parts === ['login']) {
                $r = $app->auth->login((string)($body['email'] ?? ''), (string)($body['password'] ?? ''), $ip);
                if (!$r['ok']) throw new ApiError($r['error'] === 'too_many_attempts' ? 429 : 401, $r['error'], isset($r['retry_after']) ? ['retry_after' => $r['retry_after']] : []);
                $set[] = $this->cookie($r['token'], $r['ttl']);
                return [200, ['step' => 'totp'], $set];
            }
            if ($method === 'POST' && $parts === ['login', 'verify']) {
                $r = $app->auth->verifySecond($token, (string)($body['code'] ?? ''), !empty($body['remember']), $ip);
                if (!$r['ok']) throw new ApiError($r['error'] === 'too_many_attempts' ? 429 : 401, $r['error'], isset($r['retry_after']) ? ['retry_after' => $r['retry_after']] : []);
                $set[] = $this->cookie($r['token'], $r['ttl']);
                return [200, ['csrf' => $r['csrf'], 'recovery_left' => $r['recovery_left']], $set];
            }
            if ($method === 'GET' && $parts === ['version']) return [200, ['version' => App::VERSION], []];
            if ($method === 'GET' && ($parts[0] ?? '') === 'invite' && count($parts) === 2) return [200, $app->users->invitationInfo($parts[1]), []];
            if ($method === 'POST' && $parts === ['email', 'confirm']) return [200, $app->users->confirmEmailChange((string)($body['token'] ?? ''), $ip), []];
            if ($method === 'POST' && $parts === ['forgot']) { $app->users->forgot((string)($body['email'] ?? ''), $ip); return [200, ['ok' => true], []]; }
            if ($method === 'POST' && $parts === ['reset', 'info']) return [200, $app->users->resetInfo((string)($body['token'] ?? '')), []];
            if ($method === 'POST' && $parts === ['reset', 'finish']) { $app->users->resetFinish((string)($body['token'] ?? ''), (string)($body['password'] ?? ''), $ip); return [200, ['ok' => true], []]; }
            if ($method === 'POST' && $parts === ['activate', 'start']) return [200, $app->users->activateStart((string)($body['token'] ?? '')), []];
            if ($method === 'POST' && $parts === ['activate', 'finish'])
                return [200, $app->users->activateFinish((string)($body['token'] ?? ''), (string)($body['password'] ?? ''), (string)($body['code'] ?? ''), $ip), []];

            // ---- routes avec session complète ----
            $cur = $app->auth->current($token);
            if (!$cur) throw new ApiError(401, 'unauthenticated');
            $user = $cur['user']; $sess = $cur['session'];
            if ($method !== 'GET' && !Crypto::eq((string)$sess['csrf'], (string)($h['x-csrf-token'] ?? ''))) throw new ApiError(403, 'csrf');

            if ($method === 'POST' && $parts === ['profile']) return [200, $app->users->updateProfile($user, (string)($body['last_name'] ?? ''), (string)($body['first_name'] ?? ''), $ip), []];
            if ($method === 'POST' && $parts === ['profile', 'email']) return [200, $app->users->requestEmailChange($user, (string)($body['email'] ?? ''), $ip), []];
            if ($method === 'POST' && $parts === ['logout']) { $app->auth->logout($token); $set[] = $this->cookie('', -3600); return [200, ['ok' => true], $set]; }
            if ($method === 'GET' && $parts === ['me'] && $user['role'] === 'admin' && $app->mailer && isset($h['host'])) $app->mailer->rememberBase((string)$h['host'], (string)($h['x-forwarded-proto'] ?? 'https'));
            if ($method === 'GET' && $parts === ['me']) return [200, ['user' => $user + ['member' => Users::memberLabel((int)$user['member_no'])], 'csrf' => $sess['csrf'], 'inventories' => $app->access->accessible($user), 'club' => $app->registry->clubConfig()], []];
            if ($method === 'GET' && $parts === ['inventories']) return [200, ['inventories' => $app->access->accessible($user)], []];
            if ($method === 'GET' && $parts === ['members']) return [200, ['members' => $app->users->directory($user)], []];

            if (($parts[0] ?? '') === 'inventories' && ($parts[2] ?? '') === 'shares' && ctype_digit($parts[1] ?? '')) {
                $inv = (int)$parts[1];
                if ($method === 'GET' && count($parts) === 3) return [200, ['shares' => $app->access->shares($user, $inv)], []];
                if ($method === 'POST' && count($parts) === 3) { $app->access->share($user, $inv, (int)($body['user_id'] ?? 0), (string)($body['level'] ?? ''), $ip); return [200, ['ok' => true], []]; }
                if ($method === 'DELETE' && count($parts) === 4 && ctype_digit($parts[3])) { $app->access->revoke($user, $inv, (int)$parts[3], $ip); return [200, ['ok' => true], []]; }
            }


            // ---- registre (listes, équipements) ----
            $reg = $app->registry; $first = $parts[0] ?? '';
            if ($first === 'inventories' && ctype_digit($parts[1] ?? '') && ($parts[2] ?? '') !== 'shares') {
                $inv = (int)$parts[1]; $sub = $parts[2] ?? '';
                if ($method === 'GET' && $sub === 'data' && count($parts) === 3) return [200, $reg->snapshot($user, $inv), []];
                if ($method === 'GET' && $sub === 'report' && count($parts) === 4 && $parts[3] === 'cordes') return [200, ['_bytes' => (new Report($app->db, $reg))->ropes($user, $inv, (string)($query['filtre'] ?? 'all'), App::VERSION)], []];
                if ($method === 'POST' && $sub === 'items' && count($parts) === 3) return [201, ['item' => $reg->create($user, $inv, $body, $ip)], []];
                if ($method === 'POST' && $sub === 'bulk' && count($parts) === 3) return [200, $reg->bulk($user, $inv, (array)($body['uids'] ?? []), (string)($body['action'] ?? ''), $body, $ip), []];
                if ($method === 'POST' && $sub === 'import' && count($parts) === 3) return [200, $reg->import($user, $inv, (array)($body['rows'] ?? []), $ip), []];
                if ($method === 'POST' && $sub === 'lists' && count($parts) === 3) return [201, $reg->addValue($user, $inv, (string)($body['kind'] ?? ''), (string)($body['label'] ?? ''), $ip), []];
            }
            if ($first === 'items' && count($parts) >= 2 && preg_match('/^[A-Z0-9-]{3,24}$/', $parts[1])) {
                $uid = $parts[1];
                if (($parts[2] ?? '') === 'files') {
                    $files = $app->files;
                    if (count($parts) === 3 && $method === 'GET') return [200, $files->list($user, $uid), []];
                    if (count($parts) === 3 && $method === 'POST') return [201, $files->add($user, $uid, (string)($query['kind'] ?? ''), (string)($query['name'] ?? ''), (string)$raw, ($query['same_model'] ?? '') === '1', $ip), []];
                    if (count($parts) === 4 && ctype_digit($parts[3]) && $method === 'GET') return [200, ['_file' => $files->open($user, $uid, (int)$parts[3], ($query['thumb'] ?? '') === '1')], []];
                    if (count($parts) === 4 && ctype_digit($parts[3]) && $method === 'DELETE') return [200, $files->remove($user, $uid, (int)$parts[3], $ip), []];
                    if (count($parts) === 5 && ctype_digit($parts[3]) && $parts[4] === 'main' && $method === 'POST') return [200, $files->setMain($user, $uid, (int)$parts[3], $ip), []];
                    throw new ApiError(404, 'not_found');
                }
                if ($method === 'POST' && count($parts) === 2) return [200, ['item' => $reg->update($user, $uid, $body, $ip)], []];
                if ($method === 'DELETE' && count($parts) === 2) { $reg->delete($user, $uid, $ip); return [200, ['ok' => true], []]; }
                if ($method === 'POST' && ($parts[2] ?? '') === 'measures' && count($parts) === 3) return [201, ['item' => $reg->addMeasure($user, $uid, $body, $ip)], []];
                if ($method === 'POST' && ($parts[2] ?? '') === 'duplicate' && count($parts) === 3) return [201, $reg->duplicate($user, $uid, array_map('strval', (array)($body['lots'] ?? [])), $ip), []];
                if ($method === 'POST' && ($parts[2] ?? '') === 'uncut' && count($parts) === 3) return [200, $reg->uncut($user, $uid, $ip), []];
                if ($method === 'POST' && ($parts[2] ?? '') === 'cut' && count($parts) === 3) return [201, $reg->cut($user, $uid, (array)($body['pieces'] ?? []), (array)($body['options'] ?? []), $ip), []];
            }
            if ($first === 'lists' && ctype_digit($parts[1] ?? '') && count($parts) === 2) {
                if ($method === 'POST') { $reg->updateValue($user, (int)$parts[1], $body, $ip); return [200, ['ok' => true], []]; }
                if ($method === 'DELETE') { $reg->removeValue($user, (int)$parts[1], $ip); return [200, ['ok' => true], []]; }
            }
            if ($method === 'GET' && $parts === ['storage']) return [200, $app->files->usage($user), []];
            if ($method === 'GET' && $parts === ['journal', 'club']) {
                if (!in_array($user['role'], ['admin', 'manager'], true)) throw new ApiError(403, 'forbidden');
                return [200, ['events' => $app->audit->feed('club')], []];
            }
            if ($method === 'GET' && $parts === ['journal', 'accounts']) {
                if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden');
                return [200, ['events' => $app->audit->feed('accounts')], []];
            }
            if (($parts[0] ?? '') === 'admin' && ($parts[1] ?? '') === 'mail') {
                if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden');
                $mx = $app->mailer;
                if ($method === 'GET' && count($parts) === 2) return [200, ['from' => $mx->from(), 'base_url' => $mx->baseUrl(), 'enabled' => $mx->enabled()], []];
                if ($method === 'POST' && count($parts) === 2) { $mx->setFrom((string)($body['from'] ?? '')); return [200, ['from' => $mx->from(), 'enabled' => $mx->enabled()], []]; }
                if ($method === 'POST' && ($parts[2] ?? '') === 'test' && count($parts) === 3) {
                    if (!$mx->enabled()) throw new ApiError(409, 'mail_not_configured');
                    if (!$mx->send((string)$user['email'], 'Test d’envoi — Registre EPI', "Bonjour,\n\nCeci est un message de test du Registre EPI. Si vous le lisez, l’envoi d’e-mails fonctionne.\n")) throw new ApiError(502, 'mail_failed');
                    return [200, ['sent_to' => $user['email']], []];
                }
            }
            if ($method === 'GET' && $parts === ['admin', 'system']) {
                if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden');
                $pdo = $app->db->pdo;
                return [200, ['version' => App::VERSION, 'schema' => (int)($app->db->val("SELECT v FROM settings WHERE k = 'schema_version'") ?? 0), 'schema_expected' => App::SCHEMA_VERSION, 'php' => PHP_VERSION,
                    'db' => $app->db->isSqlite() ? 'SQLite ' . $pdo->getAttribute(\PDO::ATTR_SERVER_VERSION) : 'MariaDB/MySQL ' . $pdo->getAttribute(\PDO::ATTR_SERVER_VERSION), 'repo' => (new Updater($app->config))->repo()], []];
            }
            if ($method === 'GET' && $parts === ['admin', 'update', 'check']) {
                if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden');
                return [200, (new Updater($app->config))->check(), []];
            }
            if ($method === 'POST' && $parts === ['admin', 'config']) { $app->registry->saveClubConfig($user, $body, $ip); return [200, ['ok' => true], []]; }
            if ($method === 'POST' && $parts === ['admin', 'migrate']) {
                if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden');
                $app->installSchema(dirname(__DIR__) . '/sql'); $app->audit->log((int)$user['id'], 'system.migrate', null, null, null, $ip);
                return [200, ['ok' => true], []];
            }

            if (($parts[0] ?? '') === 'admin') {
                if ($method === 'GET' && $parts === ['admin', 'users']) return [200, ['users' => $app->users->listAll($user)], []];
                if ($method === 'GET' && $parts === ['admin', 'audit']) { if ($user['role'] !== 'admin') throw new ApiError(403, 'forbidden'); return [200, ['events' => $app->audit->recent(200)], []]; }
                if ($method === 'POST' && $parts === ['admin', 'users']) {
                    $r = $app->users->invite($user, (string)($body['email'] ?? ''), (isset($body['last_name']) ? (string)$body['last_name'] : (string)($body['name'] ?? '')), (string)($body['role'] ?? 'member'), $ip, !empty($body['send_mail']), isset($body['last_name']) ? (string)($body['first_name'] ?? '') : null);
                    return [201, ['member' => $r['member'], 'user_id' => $r['user_id'], 'invite_path' => '/#/invitation/' . $r['token'], 'mail' => $r['mail']], []];
                }
                if ($method === 'POST' && count($parts) === 4 && $parts[1] === 'users' && ctype_digit($parts[2])) {
                    $id = (int)$parts[2];
                    if ($parts[3] === 'reset') return [200, ['invite_path' => '/#/invitation/' . $app->users->reset($user, $id, $ip)['token']], []];
                    if ($parts[3] === 'resend') { $r = $app->users->resend($user, $id, !empty($body['send_mail']), $ip); return [200, ['invite_path' => '/#/invitation/' . $r['token'], 'mail' => $r['mail']], []]; }
                    if ($parts[3] === 'reactivate') return [200, ['invite_path' => '/#/invitation/' . $app->users->reactivate($user, $id, $ip)['token']], []];
                    if ($parts[3] === 'disable') { $app->users->disable($user, $id, $ip); return [200, ['ok' => true], []]; }
                    if ($parts[3] === 'role') { $app->users->setRole($user, $id, (string)($body['role'] ?? ''), $ip); return [200, ['ok' => true], []]; }
                }
            }
            throw new ApiError(404, 'not_found');
        } catch (ApiError $e) {
            return [$e->status, ['error' => $e->errorCode] + $e->extra, $set];
        }
    }

    private function cookie(string $value, int $ttl): array
    {
        return ['name' => self::COOKIE, 'value' => $value, 'expires' => $ttl > 0 ? Clock::now() + $ttl : 1, 'secure' => (bool)($this->app->config['secure_cookies'] ?? true)];
    }

    /** Refuse les requêtes dont l'origine n'est pas le site lui-même. */
    private function checkOrigin(array $h): void
    {
        $base = (string)($this->app->config['base_url'] ?? '');
        if ($base === '' || !isset($h['origin'])) return;
        if (parse_url($h['origin'], PHP_URL_HOST) !== parse_url($base, PHP_URL_HOST)) throw new ApiError(403, 'bad_origin');
    }
}
