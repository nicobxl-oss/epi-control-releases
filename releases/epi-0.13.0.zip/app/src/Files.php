<?php
declare(strict_types=1);
namespace Epi;

/**
 * Documents des équipements : photos, factures, fiches techniques, manuels.
 *  - les fichiers vivent dans un dossier privé (jamais servi directement) sous leur empreinte SHA-256 ;
 *  - un même fichier envoyé deux fois dans un même inventaire n'est stocké qu'une fois (un lien par équipement) ;
 *  - club et inventaires personnels ne partagent jamais un fichier (cloisonnement) ;
 *  - factures : visibles seulement par ceux qui peuvent modifier l'inventaire (comme les prix) ;
 *  - les morceaux d'une corde voient les documents de leur bobine.
 */
final class Files
{
    public const KINDS = ['photo', 'facture', 'fiche', 'manuel'];
    private const MAX_PER_KIND = ['photo' => 6, 'facture' => 3, 'fiche' => 3, 'manuel' => 3];
    private const MAX_IMAGE = 8 * 1024 * 1024;
    private const MAX_PDF = 20 * 1024 * 1024;
    public const DEFAULT_CAP = 10 * 1024 * 1024 * 1024;

    public function __construct(private Db $db, private Access $access, private Audit $audit, private array $config = []) {}

    // ------------------------------------------------------------------ utilitaires
    private function dir(): string
    {
        $d = (string)($this->config['storage_dir'] ?? '');
        if ($d === '') throw new ApiError(503, 'storage_unavailable');
        return rtrim($d, '/\\');
    }
    public function cap(): int { return (int)($this->config['storage_cap'] ?? self::DEFAULT_CAP); }
    public function used(): int { return (int)$this->db->val('SELECT COALESCE(SUM(size), 0) FROM files'); }

    /** Espace utilisé, plafond et alerte (80 %). */
    public function usage(array $actor): array
    {
        if (!in_array($actor['role'] ?? '', ['admin', 'manager'], true)) throw new ApiError(403, 'forbidden');
        $used = $this->used(); $cap = $this->cap();
        $n = (int)$this->db->val('SELECT COUNT(*) FROM files');
        return ['used' => $used, 'cap' => $cap, 'pct' => $cap > 0 ? round($used * 100 / $cap, 1) : 0, 'warn' => $cap > 0 && $used >= 0.8 * $cap, 'files' => $n];
    }

    private function path(int $inv, string $sha): string { return $this->dir() . '/' . $inv . '/' . substr($sha, 0, 2) . '/' . $sha; }

    /** Vignette JPEG de 320 px (pour la liste), à côté du fichier ; sans la bibliothèque GD du serveur, il n'y en a simplement pas. */
    private function makeThumb(string $bytes, string $dest): void
    {
        if (!function_exists('imagecreatefromstring') || !function_exists('imagejpeg')) return;
        try {
            $src = @imagecreatefromstring($bytes); if (!$src) return;
            $w = imagesx($src); $h = imagesy($src); $r = min(1, 320 / max($w, $h));
            $tw = max(1, (int)round($w * $r)); $th = max(1, (int)round($h * $r));
            $dst = imagecreatetruecolor($tw, $th); imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $tw, $th, $w, $h);
            @imagejpeg($dst, $dest, 78);
        } catch (\Throwable) { @unlink($dest); }
    }

    private function ensureDir(): void
    {
        $d = $this->dir();
        if (!is_dir($d) && !@mkdir($d, 0750, true) && !is_dir($d)) throw new ApiError(503, 'storage_unavailable');
        // le dossier est refusé à tout accès direct, y compris si le dossier parent ne l'était pas
        if (!is_file($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\nOptions -Indexes\n");
        if (!is_file($d . '/index.html')) @file_put_contents($d . '/index.html', '');
    }

    /** Vérifie, une fois par jour, que le dossier n'est pas lisible depuis Internet. @return 'ok'|'open'|'unknown' */
    public function probe(): string
    {
        $fn = $this->config['storage_probe_fn'] ?? null;
        $last = $this->db->one("SELECT v FROM settings WHERE k = 'storage_probe'");
        if (!$fn && $last) { [$st, $ts] = array_pad(explode('|', (string)$last['v']), 2, '0'); if (in_array($st, ['ok', 'open'], true) && Clock::now() - (int)$ts < 86400) return $st; }
        $res = 'unknown';
        if ($fn) $res = (string)$fn();
        else {
            $base = rtrim((string)($this->config['base_url'] ?? ''), '/');
            if ($base !== '' && ini_get('allow_url_fopen')) {
                $name = 'probe-' . bin2hex(random_bytes(4)) . '.txt';
                if (@file_put_contents($this->dir() . '/' . $name, 'epi') !== false) {
                    $ctx = stream_context_create(['http' => ['timeout' => 4, 'ignore_errors' => true, 'follow_location' => 0]]);
                    $body = @file_get_contents($base . '/app/stockage/' . $name, false, $ctx);
                    $res = ($body === 'epi') ? 'open' : (isset($http_response_header) ? 'ok' : 'unknown');
                    @unlink($this->dir() . '/' . $name);
                }
            }
        }
        if ($res === 'ok' || $res === 'open') {
            $v = $res . '|' . Clock::now();
            if ($last) $this->db->run("UPDATE settings SET v = ? WHERE k = 'storage_probe'", [$v]); else $this->db->run("INSERT INTO settings (k, v) VALUES ('storage_probe', ?)", [$v]);
        }
        return $res;
    }

    private static function sniff(string $b): ?string
    {
        if (str_starts_with($b, "\xFF\xD8\xFF")) return 'image/jpeg';
        if (str_starts_with($b, "\x89PNG\r\n\x1A\n")) return 'image/png';
        if (strlen($b) > 12 && str_starts_with($b, 'RIFF') && substr($b, 8, 4) === 'WEBP') return 'image/webp';
        if (str_starts_with(ltrim(substr($b, 0, 1024), "\x00\t\r\n "), '%PDF-')) return 'application/pdf';
        return null;
    }

    private static function cleanName(string $n, string $mime, string $kind): string
    {
        $n = basename(str_replace('\\', '/', $n));
        $n = trim((string)preg_replace('/[\x00-\x1F\x7F"<>|:*?\/\\\\]+/u', ' ', $n));
        if ($n === '' || $n === '.' || $n === '..') $n = $kind . ($mime === 'application/pdf' ? '.pdf' : '.jpg');
        return mb_substr($n, 0, 120);
    }

    private function item(string $uid): array
    {
        $r = $this->db->one('SELECT id, uid, inventory_id, type_id, marque_id, modele, parent_uid FROM items WHERE uid = ?', [$uid]);
        if (!$r) throw new ApiError(404, 'not_found');
        return $r;
    }

    private function note(array $actor, int $inv, string $action, string $uid, string $detail, ?string $ip): void
    {
        $i = $this->access->inventory($inv);
        if ($i && $i['kind'] === 'club') $this->audit->log((int)$actor['id'], $action, $inv, $uid, $detail, $ip);
    }

    // ------------------------------------------------------------------ lecture
    /** @return array{files:array,can:array} documents de l'équipement + ceux de ses bobines d'origine (lecture seule). */
    public function list(array $actor, string $uid): array
    {
        $it = $this->item($uid); $inv = (int)$it['inventory_id'];
        $this->access->require($actor, $inv, 'view');
        $edit = $this->access->can($actor, $inv, 'edit');
        $chain = [$it]; $cur = $it; $n = 0;
        while ($cur['parent_uid'] && $n++ < 50) { $p = $this->db->one('SELECT id, uid, inventory_id, type_id, marque_id, modele, parent_uid FROM items WHERE uid = ?', [$cur['parent_uid']]); if (!$p) break; $chain[] = $p; $cur = $p; }
        $out = [];
        foreach ($chain as $c) {
            foreach ($this->db->all('SELECT l.id, l.kind, l.name, f.size, f.mime, l.created_at, l.is_main, f.id AS file_id FROM item_files l JOIN files f ON f.id = l.file_id WHERE l.item_id = ? ORDER BY l.kind, l.id', [$c['id']]) as $r) {
                if ($r['kind'] === 'facture' && !$edit) continue;
                $shared = (int)$this->db->val('SELECT COUNT(*) FROM item_files WHERE file_id = ?', [$r['file_id']]);
                $out[] = ['id' => (int)$r['id'], 'kind' => $r['kind'], 'name' => $r['name'], 'size' => (int)$r['size'], 'mime' => $r['mime'], 'at' => $r['created_at'], 'main' => false, '_flag' => (int)$r['is_main'] === 1,
                    'from' => $c['uid'] === $uid ? null : $c['uid'], 'shared' => $shared > 1 ? $shared : 0];
            }
        }
        // photo principale : celle marquée, sinon la plus ancienne ; un morceau sans photo reprend celle de sa bobine
        $pool = array_keys(array_filter($out, fn($f) => $f['kind'] === 'photo' && !$f['from']));
        if (!$pool) $pool = array_keys(array_filter($out, fn($f) => $f['kind'] === 'photo'));
        if ($pool) { $m = $pool[0]; foreach ($pool as $k) if (!empty($out[$k]['_flag'])) { $m = $k; break; } $out[$m]['main'] = true; }
        foreach ($out as &$f) unset($f['_flag']); unset($f);
        return ['files' => $out, 'can' => ['edit' => $edit], 'limits' => self::MAX_PER_KIND];
    }

    /** Fichier à envoyer au navigateur : [chemin, type, nom, taille]. */
    public function open(array $actor, string $uid, int $linkId, bool $thumb = false): array
    {
        $l = $this->db->one('SELECT l.id, l.kind, l.name, l.item_id, f.sha256, f.size, f.mime, f.inventory_id FROM item_files l JOIN files f ON f.id = l.file_id WHERE l.id = ?', [$linkId]);
        $it = $this->item($uid);
        if (!$l) throw new ApiError(404, 'not_found');
        // le document doit appartenir à cet équipement ou à l'une de ses bobines d'origine
        $ok = (int)$l['item_id'] === (int)$it['id']; $cur = $it; $n = 0;
        while (!$ok && $cur['parent_uid'] && $n++ < 50) { $cur = $this->db->one('SELECT id, parent_uid FROM items WHERE uid = ?', [$cur['parent_uid']]); if (!$cur) break; $ok = (int)$l['item_id'] === (int)$cur['id']; }
        if (!$ok) throw new ApiError(404, 'not_found');
        $inv = (int)$it['inventory_id'];
        $this->access->require($actor, $inv, 'view');
        if ($l['kind'] === 'facture') $this->access->require($actor, $inv, 'edit');
        $p = $this->path((int)$l['inventory_id'], $l['sha256']);
        if (!is_file($p)) throw new ApiError(404, 'file_missing');
        if ($thumb && str_starts_with((string)$l['mime'], 'image/') && is_file($p . '.t')) return ['path' => $p . '.t', 'mime' => 'image/jpeg', 'name' => $l['name'], 'size' => (int)filesize($p . '.t')];
        return ['path' => $p, 'mime' => $l['mime'], 'name' => $l['name'], 'size' => (int)$l['size']];
    }

    // ------------------------------------------------------------------ écriture
    /** Ajoute un document. $sameModel : fiche / manuel rattaché aussi aux équipements du même modèle. */
    public function add(array $actor, string $uid, string $kind, string $name, string $bytes, bool $sameModel = false, ?string $ip = null): array
    {
        if (!in_array($kind, self::KINDS, true)) throw new ApiError(422, 'invalid_kind');
        $it = $this->item($uid); $inv = (int)$it['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        $size = strlen($bytes);
        if ($size === 0) throw new ApiError(422, 'empty_file');
        $mime = self::sniff($bytes);
        $isImg = $mime !== null && str_starts_with($mime, 'image/');
        $allowed = match ($kind) { 'photo' => $isImg, 'facture' => $mime !== null, default => $mime === 'application/pdf' };
        if (!$allowed) throw new ApiError(415, $kind === 'photo' ? 'image_required' : 'pdf_required');
        if ($size > ($isImg ? self::MAX_IMAGE : self::MAX_PDF)) throw new ApiError(413, 'file_too_big', ['max' => $isImg ? self::MAX_IMAGE : self::MAX_PDF]);
        $this->ensureDir();
        if ($this->probe() === 'open') throw new ApiError(503, 'storage_unprotected');
        $sha = hash('sha256', $bytes); $name = self::cleanName($name, (string)$mime, $kind);

        $targets = [$it];
        if ($sameModel && in_array($kind, ['fiche', 'manuel'], true) && trim((string)$it['modele']) !== '') {
            foreach ($this->db->all("SELECT id, uid, inventory_id, type_id, marque_id, modele, parent_uid FROM items WHERE inventory_id = ? AND id <> ? AND type_id = ? AND modele = ? AND (marque_id " . ($it['marque_id'] === null ? 'IS NULL' : '= ?') . ") AND (parent_uid IS NULL OR parent_uid = '')",
                $it['marque_id'] === null ? [$inv, $it['id'], $it['type_id'], $it['modele']] : [$inv, $it['id'], $it['type_id'], $it['modele'], $it['marque_id']]) as $o) $targets[] = $o;
        }
        $res = $this->db->tx(function () use ($actor, $it, $inv, $kind, $name, $bytes, $sha, $mime, $size, $targets, $isImg) {
            $f = $this->db->one('SELECT id FROM files WHERE inventory_id = ? AND sha256 = ?', [$inv, $sha]);
            $dup = (bool)$f;
            if (!$f) {
                if ($this->used() + $size > $this->cap()) throw new ApiError(507, 'storage_full', ['used' => $this->used(), 'cap' => $this->cap()]);
                $p = $this->path($inv, $sha); $d = dirname($p);
                if (!is_dir($d) && !@mkdir($d, 0750, true) && !is_dir($d)) throw new ApiError(503, 'storage_unavailable');
                $tmp = $p . '.tmp' . bin2hex(random_bytes(3));
                if (@file_put_contents($tmp, $bytes) !== $size || !@rename($tmp, $p)) { @unlink($tmp); throw new ApiError(503, 'storage_unavailable'); }
                if ($isImg) $this->makeThumb($bytes, $p . '.t');
                $fid = $this->db->insert('INSERT INTO files (inventory_id, sha256, size, mime, created_at) VALUES (?,?,?,?,?)', [$inv, $sha, $size, $mime, Clock::ts()]);
            } else $fid = (int)$f['id'];
            $linked = 0; $mainId = 0;
            foreach ($targets as $i => $t) {
                if ($this->db->val('SELECT 1 FROM item_files WHERE item_id = ? AND file_id = ? AND kind = ?', [$t['id'], $fid, $kind])) { if ($i === 0) throw new ApiError(409, 'already_attached'); continue; }
                if ((int)$this->db->val('SELECT COUNT(*) FROM item_files WHERE item_id = ? AND kind = ?', [$t['id'], $kind]) >= self::MAX_PER_KIND[$kind]) { if ($i === 0) throw new ApiError(409, 'too_many_files', ['max' => self::MAX_PER_KIND[$kind]]); continue; }
                $lid = $this->db->insert('INSERT INTO item_files (item_id, file_id, kind, name, added_by, created_at) VALUES (?,?,?,?,?,?)', [$t['id'], $fid, $kind, $name, $actor['id'], Clock::ts()]);
                if ($i === 0) $mainId = $lid; else $linked++;
            }
            return ['id' => $mainId, 'dedup' => $dup, 'also' => $linked];
        });
        $lbl = ['photo' => 'photo', 'facture' => 'facture', 'fiche' => 'fiche technique', 'manuel' => 'manuel'][$kind];
        $this->note($actor, $inv, 'item.file_add', $uid, $lbl . ' : ' . $name . ($res['also'] ? ' (+ ' . $res['also'] . ' équipement' . ($res['also'] > 1 ? 's' : '') . ' du même modèle)' : ''), $ip);
        return $res + ['list' => $this->list($actor, $uid)];
    }

    /** Rattache aux copies (UID) les mêmes fichiers que l'équipement d'origine ; à appeler dans une transaction. */
    public function copyLinks(int $fromItemId, array $uids): void
    {
        $rows = $this->db->all('SELECT file_id, kind, name, is_main, added_by FROM item_files WHERE item_id = ? ORDER BY id', [$fromItemId]);
        if (!$rows) return;
        foreach ($uids as $u) {
            $id = (int)$this->db->val('SELECT id FROM items WHERE uid = ?', [$u]);
            foreach ($rows as $r) $this->db->run('INSERT INTO item_files (item_id, file_id, kind, name, is_main, added_by, created_at) VALUES (?,?,?,?,?,?,?)', [$id, $r['file_id'], $r['kind'], $r['name'], $r['is_main'], $r['added_by'], Clock::ts()]);
        }
    }

    /** Retire un document d'un équipement ; le fichier disparaît du disque quand plus aucun équipement n'y est rattaché. */
    public function remove(array $actor, string $uid, int $linkId, ?string $ip = null): array
    {
        $it = $this->item($uid); $inv = (int)$it['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        $l = $this->db->one('SELECT l.id, l.kind, l.name, l.file_id FROM item_files l WHERE l.id = ? AND l.item_id = ?', [$linkId, $it['id']]);
        if (!$l) throw new ApiError(404, 'not_found');
        $this->db->tx(function () use ($l) {
            $this->db->run('DELETE FROM item_files WHERE id = ?', [$l['id']]);
            $this->dropIfOrphan((int)$l['file_id']);
        });
        $this->note($actor, $inv, 'item.file_remove', $uid, $l['kind'] . ' : ' . $l['name'], $ip);
        return $this->list($actor, $uid);
    }

    /** Choisit la photo principale d'un équipement. */
    public function setMain(array $actor, string $uid, int $linkId, ?string $ip = null): array
    {
        $it = $this->item($uid); $inv = (int)$it['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        if (!$this->db->one("SELECT 1 FROM item_files WHERE id = ? AND item_id = ? AND kind = 'photo'", [$linkId, $it['id']])) throw new ApiError(404, 'not_found');
        $this->db->tx(function () use ($it, $linkId) {
            $this->db->run("UPDATE item_files SET is_main = 0 WHERE item_id = ? AND kind = 'photo'", [$it['id']]);
            $this->db->run('UPDATE item_files SET is_main = 1 WHERE id = ?', [$linkId]);
        });
        return $this->list($actor, $uid);
    }

    /** Photo principale de chaque équipement de l'inventaire : UID => numéro de lien (un morceau sans photo prend celle de sa bobine). @return array<string,int> */
    public function photos(int $inv): array
    {
        $own = []; $flagged = [];
        foreach ($this->db->all("SELECT i.uid, l.id, l.is_main FROM item_files l JOIN items i ON i.id = l.item_id WHERE i.inventory_id = ? AND l.kind = 'photo' ORDER BY l.id", [$inv]) as $r) {
            if ((int)$r['is_main'] === 1) { $own[$r['uid']] = (int)$r['id']; $flagged[$r['uid']] = true; }
            elseif (!isset($own[$r['uid']])) $own[$r['uid']] = (int)$r['id'];   // à défaut : la plus ancienne
        }
        if (!$own) return [];
        $par = []; foreach ($this->db->all("SELECT uid, parent_uid FROM items WHERE inventory_id = ? AND parent_uid IS NOT NULL AND parent_uid <> ''", [$inv]) as $r) $par[$r['uid']] = $r['parent_uid'];
        $out = $own;
        foreach ($par as $uid => $p) {
            if (isset($own[$uid])) continue;
            for ($n = 0; $p && $n < 50; $n++) { if (isset($own[$p])) { $out[$uid] = $own[$p]; break; } $p = $par[$p] ?? null; }
        }
        return $out;
    }

    private function dropIfOrphan(int $fileId): void
    {
        if ($this->db->val('SELECT 1 FROM item_files WHERE file_id = ?', [$fileId])) return;
        $f = $this->db->one('SELECT inventory_id, sha256 FROM files WHERE id = ?', [$fileId]);
        if (!$f) return;
        $this->db->run('DELETE FROM files WHERE id = ?', [$fileId]);
        $p = $this->path((int)$f['inventory_id'], $f['sha256']); @unlink($p); @unlink($p . '.t');
    }

    /** À l'effacement d'un équipement : ses liens disparaissent, et les fichiers devenus orphelins avec eux. */
    public function purgeItem(int $itemId): void
    {
        $ids = array_map(fn($r) => (int)$r['file_id'], $this->db->all('SELECT DISTINCT file_id FROM item_files WHERE item_id = ?', [$itemId]));
        $this->db->run('DELETE FROM item_files WHERE item_id = ?', [$itemId]);
        foreach ($ids as $fid) $this->dropIfOrphan($fid);
    }

    /** Nombre de documents par équipement, pour la liste (factures comptées seulement si $withInvoices). @return array<string,int> */
    public function counts(int $inv, bool $withInvoices): array
    {
        $rows = $this->db->all('SELECT i.uid, l.kind, COUNT(*) AS n FROM item_files l JOIN items i ON i.id = l.item_id WHERE i.inventory_id = ? GROUP BY i.uid, l.kind', [$inv]);
        $out = [];
        foreach ($rows as $r) { if ($r['kind'] === 'facture' && !$withInvoices) continue; $out[$r['uid']] = ($out[$r['uid']] ?? 0) + (int)$r['n']; }
        return $out;
    }
}
