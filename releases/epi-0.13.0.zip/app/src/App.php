<?php
declare(strict_types=1);
namespace Epi;

/** Assemble les services et crée l'état initial (inventaire du club + premier admin). */
final class App
{
    /** Version du programme (affichée en pied de page ; le paquet vérifie que les pages HTML portent la même). */
    public const VERSION = '0.13.0';

    public function __construct(
        public readonly Db $db, public readonly Crypto $crypto, public readonly Audit $audit, public readonly Throttle $throttle,
        public readonly Auth $auth, public readonly Users $users, public readonly Access $access, public readonly array $config,
        public readonly ?Registry $registry = null, public readonly ?Files $files = null, public readonly ?Mailer $mailer = null
    ) {}

    public static function build(Db $db, array $config): self
    {
        $crypto = new Crypto($config['app_key'], $config['argon'] ?? []);
        $audit = new Audit($db); $throttle = new Throttle($db);
        $auth = new Auth($db, $crypto, $audit, $throttle);
        $access = new Access($db, $audit); $files = new Files($db, $access, $audit, $config); $mailer = new Mailer($db, $config);
        return new self($db, $crypto, $audit, $throttle, $auth, new Users($db, $crypto, $audit, $auth, $config['issuer'] ?? 'Registre EPI', $mailer), $access, $config, new Registry($db, $access, $audit, $files), $files, $mailer);
    }

    public function installSchema(string $dir): void
    {
        // Chaque fichier ne contient que des « CREATE … IF NOT EXISTS » : on peut relancer sans risque (mises à jour).
        foreach (['schema', 'schema2'] as $part) {
            $file = $part . ($this->db->isSqlite() ? '.sqlite.sql' : '.mysql.sql');
            foreach (array_filter(array_map('trim', explode(';', (string)file_get_contents($dir . '/' . $file)))) as $stmt) $this->db->pdo->exec($stmt);
        }
    }

    /** Numéro à augmenter chaque fois qu'un fichier schema*.sql change : la base est alors mise à jour toute seule (CREATE … IF NOT EXISTS). */
    public const SCHEMA_VERSION = 10;
    /** Dépôt public du projet (page « Mise à jour »). */
    public const REPO = 'nicobxl-oss/epi-control';

    public function ensureSchema(string $dir): void
    {
        try { $v = $this->db->val("SELECT v FROM settings WHERE k = 'schema_version'"); }
        catch (\Throwable) { return; }   // pas encore installé : c'est install.php qui crée le schéma
        if ((int)$v >= self::SCHEMA_VERSION) return;
        $this->installSchema($dir);
        // v4 : colonne « remarque » sur les équipements (les bases créées avant ne l'ont pas)
        try { $this->db->val('SELECT remarque FROM items LIMIT 1'); }
        catch (\Throwable) { $this->db->run("ALTER TABLE items ADD COLUMN remarque " . ($this->db->isSqlite() ? "TEXT" : "VARCHAR(500)") . " NOT NULL DEFAULT ''"); }
        // v5 : prix d'achat par équipement
        try { $this->db->val('SELECT prix FROM items LIMIT 1'); }
        catch (\Throwable) { $this->db->run("ALTER TABLE items ADD COLUMN prix " . ($this->db->isSqlite() ? "REAL" : "DECIMAL(10,2)") . " NOT NULL DEFAULT 0"); }
        // v6 : prix au mètre figé (cordes et sangles)
        try { $this->db->val('SELECT prix_m FROM items LIMIT 1'); }
        catch (\Throwable) { $this->db->run("ALTER TABLE items ADD COLUMN prix_m " . ($this->db->isSqlite() ? "REAL" : "DECIMAL(10,4)") . " NOT NULL DEFAULT 0"); }
        // v8 : photo principale d'un équipement
        try { $this->db->val('SELECT is_main FROM item_files LIMIT 1'); }
        catch (\Throwable) { $this->db->run('ALTER TABLE item_files ADD COLUMN is_main ' . ($this->db->isSqlite() ? 'INTEGER' : 'TINYINT(1)') . ' NOT NULL DEFAULT 0'); }
        // v9 : dernière activité d'un compte (indicateur « en ligne »)
        try { $this->db->val('SELECT last_seen_at FROM users LIMIT 1'); }
        catch (\Throwable) { $this->db->run('ALTER TABLE users ADD COLUMN last_seen_at VARCHAR(19) NULL'); }
        // v10 : NOM et prénom séparés (« name » reste le nom affiché « NOM Prénom »), adresse en attente de confirmation sur les liens
        try { $this->db->val('SELECT last_name FROM users LIMIT 1'); }
        catch (\Throwable) {
            $this->db->run("ALTER TABLE users ADD COLUMN last_name VARCHAR(80) NOT NULL DEFAULT ''");
            $this->db->run("ALTER TABLE users ADD COLUMN first_name VARCHAR(80) NOT NULL DEFAULT ''");
            foreach ($this->db->all('SELECT id, name FROM users') as $u) {
                [$ln, $fn] = Users::splitName((string)$u['name']); $disp = Users::displayName($ln, $fn);
                $this->db->run('UPDATE users SET last_name = ?, first_name = ?, name = ? WHERE id = ?', [$ln, $fn, $disp, $u['id']]);
                if ($disp !== $u['name']) {   // l'historique garde le même nom écrit autrement : on le suit
                    $this->db->run('UPDATE items SET par = ? WHERE par = ?', [$disp, $u['name']]);
                    $this->db->run('UPDATE item_measures SET par = ? WHERE par = ?', [$disp, $u['name']]);
                }
            }
        }
        try { $this->db->val('SELECT data FROM invitations LIMIT 1'); }
        catch (\Throwable) { $this->db->run('ALTER TABLE invitations ADD COLUMN data VARCHAR(190) NULL'); }
        if ($v === null) $this->db->run("INSERT INTO settings (k, v) VALUES ('schema_version', ?)", [(string)self::SCHEMA_VERSION]);
        else $this->db->run("UPDATE settings SET v = ? WHERE k = 'schema_version'", [(string)self::SCHEMA_VERSION]);
    }

    public function isInstalled(): bool
    {
        try { return (int)$this->db->val('SELECT COUNT(*) FROM users') > 0; } catch (\Throwable) { return false; }
    }

    /** Premier lancement : inventaire du club + premier administrateur (lien d'invitation à usage unique). */
    public function bootstrap(string $clubName, string $adminEmail, string $adminName): array
    {
        if ($this->isInstalled()) throw new ApiError(409, 'already_installed');
        if (!$this->access->clubInventory()) $this->db->run("INSERT INTO inventories (kind, owner_user_id, name, created_at) VALUES ('club', NULL, ?, ?)", [$clubName, Clock::ts()]);
        $boot = ['id' => 0, 'role' => 'admin', 'status' => 'active'];
        $r = $this->users->invite($boot, $adminEmail, $adminName, 'admin');
        $this->db->run("INSERT INTO settings (k, v) SELECT 'schema_version', ? WHERE NOT EXISTS (SELECT 1 FROM settings WHERE k = 'schema_version')", [(string)self::SCHEMA_VERSION]);
        return $r;
    }
}
