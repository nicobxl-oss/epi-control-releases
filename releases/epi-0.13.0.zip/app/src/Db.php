<?php
declare(strict_types=1);
namespace Epi;

use PDO;

/** Mince enveloppe autour de PDO. Fonctionne avec MySQL/MariaDB (production) et SQLite (tests). */
final class Db
{
    public function __construct(public readonly PDO $pdo)
    {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') { $pdo->exec('PRAGMA foreign_keys = ON'); $pdo->exec('PRAGMA busy_timeout = 30000'); }
    }

    public static function connect(array $c): self
    {
        $pdo = new PDO($c['dsn'], $c['user'] ?? null, $c['pass'] ?? null);
        $db = new self($pdo);
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') $pdo->exec("SET time_zone = '+00:00'");
        return $db;
    }

    public function isSqlite(): bool { return $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite'; }
    public function run(string $sql, array $p = []): int { $s = $this->pdo->prepare($sql); $s->execute($p); return $s->rowCount(); }
    public function one(string $sql, array $p = []): ?array { $s = $this->pdo->prepare($sql); $s->execute($p); $r = $s->fetch(); return $r === false ? null : $r; }
    public function all(string $sql, array $p = []): array { $s = $this->pdo->prepare($sql); $s->execute($p); return $s->fetchAll(); }
    public function val(string $sql, array $p = []) { $r = $this->one($sql, $p); return $r ? array_values($r)[0] : null; }
    public function insert(string $sql, array $p = []): int { $this->run($sql, $p); return (int)$this->pdo->lastInsertId(); }

    private int $sp = 0;
    private bool $manual = false;

    /** Exécute $fn dans une transaction ; annule tout en cas d'exception. Imbriquée : point de reprise (SAVEPOINT) pour n'annuler que la partie interne. */
    public function tx(callable $fn)
    {
        if ($this->manual || $this->pdo->inTransaction()) {
            $name = 'sp' . (++$this->sp);
            $this->pdo->exec("SAVEPOINT $name");
            try { $r = $fn(); $this->pdo->exec("RELEASE SAVEPOINT $name"); return $r; }
            catch (\Throwable $e) { $this->pdo->exec("ROLLBACK TO SAVEPOINT $name"); $this->pdo->exec("RELEASE SAVEPOINT $name"); throw $e; }
        }
        if ($this->isSqlite()) {   // verrou d'écriture pris dès le début : deux transactions simultanées s'enchaînent au lieu de se bloquer mutuellement (« database is locked »)
            $this->pdo->exec('BEGIN IMMEDIATE'); $this->manual = true;
            try { $r = $fn(); $this->pdo->exec('COMMIT'); $this->manual = false; return $r; }
            catch (\Throwable $e) { if ($this->manual) { try { $this->pdo->exec('ROLLBACK'); } catch (\Throwable) { /* déjà annulée */ } $this->manual = false; } throw $e; }
        }
        $this->pdo->beginTransaction();
        try { $r = $fn(); $this->pdo->commit(); return $r; }
        catch (\Throwable $e) { if ($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
    }
}
