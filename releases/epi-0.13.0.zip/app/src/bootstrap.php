<?php
declare(strict_types=1);

spl_autoload_register(function (string $c): void {
    if (strncmp($c, 'Epi\\', 4) === 0) {
        $f = __DIR__ . '/' . substr($c, 4) . '.php';
        if (is_file($f)) require $f;
    }
});
