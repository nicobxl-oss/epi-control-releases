<?php
declare(strict_types=1);

namespace Epi;

/** Rapports PDF. Pour l'instant : l'état des lieux des cordes, avec l'arborescence des morceaux (bobine, morceaux, morceaux de morceaux). */
final class Report
{
    public const FILTERS = [
        'all' => ['Rapport complet', null],
        'service' => ['En stock et en service', ['stock', 'en_service']],
        'declasse' => ['Déclassées', ['declasse']],
    ];
    private const OUT = ['declasse', 'perdu', 'epuise'];

    public function __construct(private Db $db, private Registry $reg) {}

    private static function fmtDate(?string $iso): string
    {
        return $iso !== null && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $iso, $m) ? $m[3] . '/' . $m[2] . '/' . $m[1] : '';
    }
    private static function isoOk($s): bool { return is_string($s) && (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $s); }
    private static function fmtM($n): string
    {
        if ($n === '' || $n === null) return '';
        return str_replace('.', ',', (string)round((float)$n, 2)) . ' m';
    }
    /** Même règle que la page : +12 mois, le jour qui n'existe pas déborde sur le mois suivant. */
    private static function addMonths(string $iso, int $m): string
    {
        [$y, $mo, $d] = array_map('intval', explode('-', $iso));
        return gmdate('Y-m-d', gmmktime(0, 0, 0, $mo + $m, $d, $y));
    }
    /** Même règle que la page : le dernier jour de février reste le dernier jour de février. */
    private static function addMonthsEnd(string $iso, int $months): string
    {
        [$y, $mo, $d] = array_map('intval', explode('-', $iso));
        $tot = $y * 12 + ($mo - 1) + $months; $ty = intdiv($tot, 12); $tm = $tot % 12 + 1;
        $lastSrc = (int)gmdate('t', gmmktime(0, 0, 0, $mo, 1, $y)); $lastDst = (int)gmdate('t', gmmktime(0, 0, 0, $tm, 1, $ty));
        $day = ($mo === 2 && $tm === 2 && $d === $lastSrc) ? $lastDst : min($d, $lastDst);
        return sprintf('%04d-%02d-%02d', $ty, $tm, $day);
    }
    private static function years($v): ?float
    {
        if ($v === null || $v === '') return null;
        $n = is_numeric($v) ? (float)$v : null;
        return $n !== null && $n > 0 && $n <= 100 ? round($n * 12) / 12 : null;
    }
    private static function lifeEnd(array $it): ?string
    {
        $u = self::years($it['vieUtil'] ?? null); $t = self::years($it['vieTotale'] ?? null); $c = [];
        if ($u !== null && self::isoOk($it['mes'] ?? '')) $c[] = self::addMonthsEnd($it['mes'], (int)round($u * 12));
        if ($t !== null && self::isoOk($it['fab'] ?? '')) $c[] = self::addMonthsEnd($it['fab'], (int)round($t * 12));
        if (!$c) return null;
        sort($c);
        return $c[0];
    }

    /** Familles de cordes retenues pour un filtre : [[noeud, enfants[]]…], triées par UID. */
    public function families(array $items, string $filter): array
    {
        $ropes = []; foreach ($items as $it) if (($it['type_sys'] ?? '') === 'corde') $ropes[$it['uid']] = $it;
        $kids = [];
        foreach ($ropes as $u => $it) { $p = $it['parent'] ?? null; if ($p !== null && $p !== '' && isset($ropes[$p])) $kids[$p][] = $u; }
        $match = self::FILTERS[$filter][1];
        $walk = function (string $u, int $guard = 0) use (&$walk, $ropes, $kids): array {
            $ch = $kids[$u] ?? []; sort($ch);
            return ['it' => $ropes[$u], 'kids' => $guard < 30 ? array_map(fn($k) => $walk($k, $guard + 1), $ch) : []];
        };
        $any = function (array $n) use (&$any, $match): bool {
            if ($match === null || in_array($n['it']['etat_sys'] ?? '', $match, true)) return true;
            foreach ($n['kids'] as $k) if ($any($k)) return true;
            return false;
        };
        $roots = array_filter(array_keys($ropes), fn($u) => !(($ropes[$u]['parent'] ?? '') !== '' && isset($ropes[$ropes[$u]['parent']])));
        sort($roots);
        $out = [];
        foreach ($roots as $u) { $t = $walk($u); if ($any($t)) $out[] = $t; }
        return $out;
    }

    /** Longueur actuelle d'une corde : dernière mesure, sinon longueur d'origine. */
    private static function currentLength(array $it): float
    {
        $ms = $it['mesures'] ?? [];
        if ($ms) return (float)$ms[count($ms) - 1]['l'];
        return is_numeric($it['longueur'] ?? null) ? (float)$it['longueur'] : 0.0;
    }
    /** Métrage actuel des cordes en stock et des cordes en service des familles données : ['stock' => m, 'service' => m]. Bobines et morceaux ont chacun leur longueur actuelle, donc pas de double compte. */
    public function metres(array $families): array
    {
        $t = ['stock' => 0.0, 'service' => 0.0];
        $f = function (array $n) use (&$f, &$t) {
            $e = $n['it']['etat_sys'] ?? '';
            if ($e === 'stock') $t['stock'] += self::currentLength($n['it']);
            elseif ($e === 'en_service') $t['service'] += self::currentLength($n['it']);
            foreach ($n['kids'] as $k) $f($k);
        };
        foreach ($families as $fam) $f($fam);
        return ['stock' => round($t['stock'], 2), 'service' => round($t['service'], 2)];
    }
    private static function fmtTotal(float $n): string
    {
        $s = rtrim(rtrim(number_format($n, 2, ',', ' '), '0'), ',');
        return ($s === '' ? '0' : $s) . ' m';
    }

    /** Aplatit un arbre en lignes : [item, profondeur, [ancêtres qui continuent], dernierFrère]. */
    private static function flatten(array $node, int $depth, array $guides, bool $last, array &$rows): void
    {
        $rows[] = ['it' => $node['it'], 'd' => $depth, 'g' => $guides, 'last' => $last];
        $n = count($node['kids']);
        foreach ($node['kids'] as $i => $k) self::flatten($k, $depth + 1, $depth >= 1 ? array_merge($guides, [!$last]) : [], $i === $n - 1, $rows);
    }

    /** @return array{mime:string,name:string,content:string} */
    public function ropes(array $actor, int $inv, string $filter, string $appVersion = ''): array
    {
        if (!isset(self::FILTERS[$filter])) throw new ApiError(422, 'invalid_filter');
        $data = $this->reg->snapshot($actor, $inv);   // contrôle aussi le droit de lecture
        $fams = $this->families($data['items'], $filter);
        $invRow = $this->db->one('SELECT * FROM inventories WHERE id = ?', [$inv]) ?: [];
        $club = ($invRow['kind'] ?? '') === 'club' ? trim((string)($this->db->val("SELECT v FROM club_config WHERE k = 'nom'") ?? '')) : '';
        $label = $club !== '' ? $club : (string)($invRow['name'] ?? 'Registre');
        $today = gmdate('Y-m-d', Clock::now());
        $nRopes = 0; $famRows = [];
        foreach ($fams as $f) { $rows = []; self::flatten($f, 0, [], true, $rows); $nRopes += count($rows); $famRows[] = $rows; }

        $title = 'État des lieux des cordes';
        $pdf = new Pdf(Pdf::A4_W, Pdf::A4_H, ['title' => $title . ' - ' . $label, 'author' => 'Registre EPI']);
        $mx = 28.0; $top = 108.0; $bottom = Pdf::A4_H - 34; $rh = 15.0;
        // colonnes : [titre, largeur, alignement]
        $cols = [['UID', 108, 'l'], ["Lot / n°\nde série", 66, 'l'], ['Marque', 58, 'l'], ['Modèle', 84, 'l'], ['Fabrication', 50, 'r'], ["Longueur\nd’origine", 44, 'r'],
            ["Longueur\nactuelle", 44, 'r'], ["Mesurée\nle", 50, 'r'], ["Mise en\nservice", 50, 'r'], ["Dernier\ncontrôle", 50, 'r'], ["Prochain\ncontrôle", 50, 'r'], ["Fin de\nvie", 50, 'r'], ['État', 56, 'l']];
        $xs = []; $x = $mx; foreach ($cols as $c) { $xs[] = $x; $x += $c[1]; }
        $grey = [0.45, 0.45, 0.45]; $red = [0.72, 0.12, 0.1]; $line = [0.8, 0.8, 0.8]; $ink = [0.1, 0.1, 0.1];
        $y = $top;

        foreach ($famRows as $rows) {
            $need = count($rows) * $rh;
            if ($y + $need > $bottom && $need <= $bottom - $top) { $pdf->addPage(); $y = $top; }
            foreach ($rows as $r) {
                if ($y + $rh > $bottom) { $pdf->addPage(); $y = $top; }
                $it = $r['it']; $base = $y + 10.2; $d = $r['d'];
                $out = in_array($it['etat_sys'] ?? '', self::OUT, true);
                $fg = $out ? $grey : $ink;
                // arborescence
                $x0 = $xs[0] + 4;
                foreach ($r['g'] as $i => $cont) if ($cont) $pdf->line($x0 + $i * 11 + 4, $y, $x0 + $i * 11 + 4, $y + $rh, 0.5, $grey);
                if ($d >= 1) { $vx = $x0 + ($d - 1) * 11 + 4; $pdf->line($vx, $y, $vx, $r['last'] ? $y + $rh / 2 : $y + $rh, 0.5, $grey); $pdf->line($vx, $y + $rh / 2, $vx + 7, $y + $rh / 2, 0.5, $grey); }
                $ux = $x0 + $d * 11;
                $pdf->text($ux, $base, $it['uid'], 8.5, $d === 0, $fg);
                $cell = function (int $i, string $s, ?array $color = null, bool $bold = false) use ($pdf, $cols, $xs, $base, $fg) {
                    $pad = $cols[$i][2] === 'l' && $i === 12 ? 6 : 3; $w = $cols[$i][1] - 3 - $pad; $s = $pdf->fit($s, $w, 8, $bold); $c = $color ?? $fg;
                    $cols[$i][2] === 'r' ? $pdf->textRight($xs[$i] + $cols[$i][1] - 3, $base, $s, 8, $bold, $c) : $pdf->text($xs[$i] + $pad, $base, $s, 8, $bold, $c);
                };
                $cell(1, trim((string)($it['lot'] ?? '')) ?: '-');
                $cell(2, trim((string)($it['marque'] ?? '')) ?: '-');
                $cell(3, trim((string)($it['modele'] ?? '')) ?: '-');
                $cell(4, self::fmtDate($it['fab'] ?? '') ?: '-');
                $orig = self::fmtM($it['longueur'] ?? ''); $cell(5, $orig !== '' ? $orig : '-');
                $ms = $it['mesures'] ?? []; $lm = $ms ? $ms[count($ms) - 1] : null;
                $cur = $lm ? self::fmtM($lm['l']) : $orig; $cell(6, $cur !== '' ? $cur : '-');
                $cell(7, $lm ? (self::fmtDate($lm['d']) ?: '-') : '-');
                $cell(8, self::fmtDate($it['mes'] ?? '') ?: '-');
                $cell(9, self::fmtDate($it['ctrl'] ?? '') ?: '-');
                // prochain contrôle : 12 mois après le dernier contrôle (ou la mise en service) ; rien pour déclassé, perdu, épuisé
                $due = null;
                if (!$out) { $ref = self::isoOk($it['ctrl'] ?? '') ? $it['ctrl'] : (self::isoOk($it['mes'] ?? '') ? $it['mes'] : ''); if ($ref !== '') $due = self::addMonths($ref, 12); }
                $cell(10, $due ? self::fmtDate($due) : '-', $due && $due < $today ? $red : null, $due !== null && $due < $today);
                $end = $out ? null : self::lifeEnd($it);
                $cell(11, $end ? self::fmtDate($end) : '-', $end && $end < $today ? $red : null, $end !== null && $end < $today);
                $cell(12, (string)($it['etat'] ?? ''));
                $pdf->line($mx, $y + $rh, $x, $y + $rh, 0.25, $line);
                $y += $rh;
            }
            $pdf->line($mx, $y, $x, $y, 0.9, [0.55, 0.55, 0.55]);
            $y += 5;
        }
        if (!$famRows) { $pdf->text($mx, $top + 16, 'Aucune corde ne correspond à ce rapport.', 10, false, $grey); }

        $filterLabel = self::FILTERS[$filter][0]; $stamp = self::fmtDate($today);
        $nFam = count($famRows); $tot = $this->metres($fams); $metres = 'Longueur en stock : ' . self::fmtTotal($tot['stock']) . '  ·  en service : ' . self::fmtTotal($tot['service']) . '.';
        $summary = $nRopes . ($nRopes > 1 ? ' cordes' : ' corde') . ' dans ' . $nFam . ($nFam > 1 ? ' familles' : ' famille');
        $out = $pdf->output(function (Pdf $p, int $no, int $total) use ($title, $label, $filterLabel, $stamp, $summary, $metres, $cols, $xs, $mx, $appVersion, $grey, $red) {
            $p->text($mx, 40, $title, 16, true);
            $p->textRight(Pdf::A4_W - $mx, 40, $label, 11, true);
            $p->text($mx, 57, $filterLabel . '  -  ' . $summary . '  -  établi le ' . $stamp, 9, false, $grey);
            $p->text($mx, 70, 'Les morceaux sont placés sous leur corde d’origine. En rouge : échéance dépassée. En gris : déclassée, perdue ou épuisée.  ' . $metres, 7.5, false, $grey);
            $p->rect($mx, 78, array_sum(array_column($cols, 1)), 24, [0.93, 0.93, 0.93]);
            foreach ($cols as $i => $c) {
                $pad = $i === 12 ? 6 : 3; $lines = explode("\n", $c[0]); $y0 = count($lines) === 1 ? 93 : 88;
                foreach ($lines as $k => $ln) {
                    $s = $p->fit($ln, $c[1] - 6, 8, true);
                    $p->text($xs[$i] + ($c[1] - $p->width($s, 8, true)) / 2, $y0 + $k * 9.5, $s, 8, true);
                }
            }
            $p->text($mx, Pdf::A4_H - 16, 'Registre EPI' . ($appVersion !== '' ? ' ' . $appVersion : ''), 7.5, false, $grey);
            $p->textRight(Pdf::A4_W - $mx, Pdf::A4_H - 16, 'Page ' . $no . ' / ' . $total, 7.5, false, $grey);
        });
        return ['mime' => 'application/pdf', 'name' => 'etat-des-lieux-cordes-' . $today . '.pdf', 'content' => $out];
    }
}
