<?php
declare(strict_types=1);
namespace Epi;

/** Jetons, mots de passe, chiffrement du secret 2FA. */
final class Crypto
{
    private string $key;
    private array $argon;
    private ?string $dummy = null;

    public function __construct(string $appKeyB64, array $argon = [])
    {
        $this->argon = $argon + ['memory_cost' => 65536, 'time_cost' => 3, 'threads' => 1];
        $raw = base64_decode($appKeyB64, true);
        if ($raw === false || strlen($raw) < 32) throw new \RuntimeException('app_key invalide : 32 octets en base64 requis.');
        $this->key = sodium_crypto_generichash($raw, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
    }

    public static function token(int $bytes = 32): string { return bin2hex(random_bytes($bytes)); }
    public static function hash(string $t): string { return hash('sha256', $t); }
    public static function eq(string $a, string $b): bool { return hash_equals($a, $b); }

    public function hashPassword(string $p): string
    {
        return password_hash($p, PASSWORD_ARGON2ID, $this->argon);
    }
    public function verifyPassword(string $p, string $hash): bool { return password_verify($p, $hash); }
    /** Calcul factice pour que « utilisateur inconnu » et « mauvais mot de passe » prennent le même temps. */
    public function dummyVerify(): void
    {
        $this->dummy ??= password_hash('dummy-password-for-timing', PASSWORD_ARGON2ID, $this->argon);
        password_verify('x', $this->dummy);
    }

    public function encrypt(string $plain): string
    {
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($n . sodium_crypto_secretbox($plain, $n, $this->key));
    }
    public function decrypt(string $b64): ?string
    {
        $raw = base64_decode($b64, true);
        if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return null;
        $p = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $this->key);
        return $p === false ? null : $p;
    }

    /** @return string[] 10 codes de secours de la forme xxxxx-xxxxx */
    public static function recoveryCodes(int $n = 10): array
    {
        $alpha = 'abcdefghjkmnpqrstuvwxyz23456789';
        $out = [];
        for ($i = 0; $i < $n; $i++) {
            $c = '';
            for ($j = 0; $j < 10; $j++) $c .= $alpha[random_int(0, strlen($alpha) - 1)];
            $out[] = substr($c, 0, 5) . '-' . substr($c, 5);
        }
        return $out;
    }
    public static function normalizeRecovery(string $c): string { return strtolower(str_replace([' ', '-'], '', trim($c))); }
}
