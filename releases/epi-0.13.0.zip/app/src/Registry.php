<?php
declare(strict_types=1);
namespace Epi;

/**
 * Le registre du matériel : listes (types, états, marques, activités), équipements (EPI), mesures et découpe des cordes.
 * Les droits viennent de Access ; les actions sur l'inventaire du CLUB sont journalisées (qui, quand, quoi).
 * Les inventaires personnels ne sont jamais journalisés (cloisonnement).
 */
final class Registry
{
    public const KINDS = ['etat', 'type', 'marque', 'activite'];
    private const DEFAULTS = [
        'etat' => [['En service', 'en_service'], ['En fixe', 'fixe'], ['Stock', 'stock'], ['Épuisé', 'epuise'], ['Déclassé', 'declasse'], ['Perdu', 'perdu']],
        'type' => [['Sangle', 'SAN', 1, 'sangle'], ['Corde', 'COR', 1, 'corde'], ['Mousqueton', 'MOS', 0], ['Bloqueur', 'BLO', 0], ['Descendeur', 'DES', 0], ['Baudrier', 'BAU', 1],
            ['Textile', 'TEX', 0], ['Longes', 'LON', 1], ['Maillon', 'MAI', 0], ['Eclairage', 'ECL', 0], ['Casque', 'CAS', 1], ['Poulie', 'POU', 0], ['Portage', 'POR', 0]],
        'marque' => ['Petzl', 'Camp', 'ATK', 'Beal', 'Ce4Y', 'Edelrid'],
        'activite' => ['Spéléologie', 'Escalade', 'Via-Ferrata'],
    ];
    private const TEXT = ['modele' => 120, 'fournisseur' => 160, 'lot' => 80, 'par' => 80, 'remarque' => 500];
    private const DATES = ['fab', 'achat', 'mes', 'ctrl'];
    /** Caractéristiques de la corde d'origine : un morceau les reçoit de sa bobine et ne peut pas les modifier. L'activité est copiée à la découpe mais reste libre ; la longueur d'origine d'un morceau est fixée à la découpe. */
    private const INHERITED = ['marque_id', 'modele', 'fab', 'achat', 'fournisseur', 'lot', 'vie_util', 'vie_totale'];
    private const INHERITED_API = ['marque' => 'marque_id', 'modele' => 'modele', 'fab' => 'fab', 'achat' => 'achat', 'fournisseur' => 'fournisseur', 'lot' => 'lot', 'vieUtil' => 'vie_util', 'vieTotale' => 'vie_totale'];
    private const AUDIT_FIELDS = ['etat' => 'état', 'marque' => 'marque', 'modele' => 'modèle', 'fab' => 'fabrication', 'achat' => 'achat', 'fournisseur' => 'fournisseur', 'mes' => 'mise en service',
        'activite' => 'activité', 'longueur' => 'longueur', 'lot' => 'lot', 'ctrl' => 'contrôle', 'par' => 'contrôlé par', 'remarque' => 'remarque', 'prix' => 'prix', 'vieUtil' => 'durée d’utilisation', 'vieTotale' => 'durée de vie totale'];

    public function __construct(private Db $db, private Access $access, private Audit $audit, private ?Files $files = null) {}

    // ------------------------------------------------------------------ utilitaires
    public static function nkey(string $s): string
    {
        $s = strtr(mb_strtolower($s), ['à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a', 'å' => 'a', 'ç' => 'c', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e', 'í' => 'i', 'ì' => 'i',
            'î' => 'i', 'ï' => 'i', 'ñ' => 'n', 'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'ö' => 'o', 'õ' => 'o', 'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'ÿ' => 'y', 'œ' => 'oe', 'æ' => 'ae']);
        return trim((string)preg_replace('/[^a-z0-9]+/', ' ', $s));
    }
    public static function metres($v): ?float
    {
        if (is_int($v) || is_float($v)) return is_finite((float)$v) ? round((float)$v, 2) : null;
        if (!preg_match('/^\s*(\d+(?:[.,]\d+)?)\s*(?:m|mètres?|metres?)?\s*$/iu', (string)$v, $m)) return null;
        return round((float)str_replace(',', '.', $m[1]), 2);
    }
    private static function fmtM(float $n): string { return str_replace('.', ',', (string)round($n, 2)) . ' m'; }
    private static function validDate(string $s): bool
    {
        return (bool)preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
    }
    private static function years($v): ?float
    {
        if ($v === '' || $v === null) return null;
        $n = is_numeric($v) ? (float)$v : (float)str_replace(',', '.', preg_replace('/\s*ans?$/iu', '', (string)$v));
        return ($n > 0 && $n <= 100) ? round($n * 12) / 12 : null;
    }
    private static function today(): string { return gmdate('Y-m-d', Clock::now()); }
    private function note(array $actor, int $inv, string $action, ?string $target, ?string $detail, ?string $ip): void
    {
        $i = $this->access->inventory($inv);
        if ($i && $i['kind'] === 'club') $this->audit->log((int)$actor['id'], $action, $inv, $target, $detail, $ip);
    }

    // ------------------------------------------------------------------ club : nom et logo
    public function clubConfig(): array
    {
        $o = ['nom' => '', 'logo' => '', 'logoBg' => 'none'];
        foreach ($this->db->all('SELECT k, v FROM club_config') as $r) if (array_key_exists($r['k'], $o)) $o[$r['k']] = $r['v'];
        return $o;
    }
    public function saveClubConfig(array $actor, array $c, ?string $ip = null): void
    {
        if (($actor['role'] ?? '') !== 'admin') throw new ApiError(403, 'forbidden');
        $nom = mb_substr(trim((string)($c['nom'] ?? '')), 0, 60);
        $logo = (string)($c['logo'] ?? '');
        if ($logo !== '' && (!preg_match('#^data:image/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$#', $logo) || strlen($logo) > 200000)) throw new ApiError(422, 'invalid_logo');
        $bg = ($c['logoBg'] ?? '') === 'light' ? 'light' : 'none';
        $this->db->tx(function () use ($nom, $logo, $bg) {
            foreach (['nom' => $nom, 'logo' => $logo, 'logoBg' => $bg] as $k => $v) {
                $this->db->run('DELETE FROM club_config WHERE k = ?', [$k]);
                $this->db->run('INSERT INTO club_config (k, v) VALUES (?,?)', [$k, $v]);
            }
        });
        $this->audit->log((int)$actor['id'], 'config.club', null, null, 'nom : ' . $nom . ($logo !== '' ? ' ; logo' : ''), $ip);
    }

    // ------------------------------------------------------------------ listes
    public function ensureLists(int $inv): void
    {
        if ((int)$this->db->val('SELECT COUNT(*) FROM list_values WHERE inventory_id = ?', [$inv]) > 0) { $this->ensureFixe($inv); return; }
        $this->db->tx(function () use ($inv) {
            $this->lockInv($inv);
            if ((int)$this->db->val('SELECT COUNT(*) FROM list_values WHERE inventory_id = ?', [$inv]) > 0) return;   // un autre l'a fait entre-temps
            foreach (self::DEFAULTS as $kind => $vals) foreach ($vals as $pos => $v) {
                $v = (array)$v;
                $this->db->run('INSERT INTO list_values (inventory_id, kind, label, code, limited, sys, position) VALUES (?,?,?,?,?,?,?)',
                    [$inv, $kind, $v[0], $kind === 'type' ? $v[1] : null, $kind === 'type' ? (int)($v[2] ?? 0) : 0, $kind === 'etat' ? $v[1] : ($v[3] ?? null), $pos]);
            }
        });
    }

    /** Inventaires créés avant la 0.4.1 : ajoute l'état système « En fixe » (ou marque comme tel un état « En fixe » déjà créé à la main). */
    private function ensureFixe(int $inv): void
    {
        if ($this->db->val("SELECT 1 FROM list_values WHERE inventory_id = ? AND kind = 'etat' AND sys = 'fixe'", [$inv])) return;
        $this->db->tx(function () use ($inv) {
            $this->lockInv($inv);
            if ($this->db->val("SELECT 1 FROM list_values WHERE inventory_id = ? AND kind = 'etat' AND sys = 'fixe'", [$inv])) return;
            $mine = $this->valueRow($inv, 'etat', 'En fixe');
            if ($mine) { if ($mine['sys'] === null) $this->db->run('UPDATE list_values SET sys = ? WHERE id = ?', ['fixe', $mine['id']]); return; }
            $pos = (int)$this->db->val("SELECT position FROM list_values WHERE inventory_id = ? AND kind = 'etat' AND sys = 'en_service'", [$inv]);
            $this->db->run("UPDATE list_values SET position = position + 1 WHERE inventory_id = ? AND kind = 'etat' AND position > ?", [$inv, $pos]);
            $this->db->run('INSERT INTO list_values (inventory_id, kind, label, code, limited, sys, position) VALUES (?,?,?,?,?,?,?)', [$inv, 'etat', 'En fixe', null, 0, 'fixe', $pos + 1]);
        });
    }

    private function valueRow(int $inv, string $kind, string $label): ?array
    {
        foreach ($this->db->all('SELECT * FROM list_values WHERE inventory_id = ? AND kind = ?', [$inv, $kind]) as $r) if (self::nkey($r['label']) === self::nkey($label)) return $r;
        return null;
    }
    private function sysId(int $inv, string $kind, string $sys): ?int
    {
        $v = $this->db->val('SELECT id FROM list_values WHERE inventory_id = ? AND kind = ? AND sys = ?', [$inv, $kind, $sys]);
        return $v === null ? null : (int)$v;
    }
    private function makeCode(int $inv, string $label): string
    {
        $used = array_column($this->db->all("SELECT code FROM list_values WHERE inventory_id = ? AND kind = 'type'", [$inv]), 'code');
        $letters = strtoupper((string)preg_replace('/[^a-z]/', '', self::nkey($label)));
        $base = substr($letters . 'XXX', 0, 3);
        $c = [$base];
        for ($i = 3; $i < strlen($letters); $i++) $c[] = substr($letters, 0, 2) . $letters[$i];
        $c[] = substr($letters . 'XXXX', 0, 4);
        foreach (str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ') as $ch) $c[] = substr($base, 0, 2) . $ch;
        foreach ($c as $x) if (!in_array($x, $used, true)) return $x;
        throw new ApiError(409, 'no_code_available');
    }
    private function addValueRow(int $inv, string $kind, string $label): array
    {
        $label = trim($label);
        if ($label === '' || mb_strlen($label) > 80) throw new ApiError(422, 'invalid_value');
        if ($hit = $this->valueRow($inv, $kind, $label)) return $hit;
        $pos = 1 + (int)$this->db->val('SELECT COALESCE(MAX(position), 0) FROM list_values WHERE inventory_id = ? AND kind = ?', [$inv, $kind]);
        $id = $this->db->insert('INSERT INTO list_values (inventory_id, kind, label, code, limited, sys, position) VALUES (?,?,?,?,0,NULL,?)',
            [$inv, $kind, $label, $kind === 'type' ? $this->makeCode($inv, $label) : null, $pos]);
        return $this->db->one('SELECT * FROM list_values WHERE id = ?', [$id]);
    }

    public function lists(int $inv): array
    {
        $out = ['etat' => [], 'type' => [], 'marque' => [], 'activite' => []]; $rows = [];
        foreach ($this->db->all('SELECT * FROM list_values WHERE inventory_id = ? ORDER BY kind, position, id', [$inv]) as $r) {
            $rows[] = ['id' => (int)$r['id'], 'kind' => $r['kind'], 'label' => $r['label'], 'sys' => $r['sys'], 'used' => (int)$this->db->val(
                'SELECT COUNT(*) FROM items WHERE ' . ['etat' => 'etat_id', 'type' => 'type_id', 'marque' => 'marque_id', 'activite' => 'activite_id'][$r['kind']] . ' = ?', [$r['id']])];
            if ($r['kind'] === 'type') $out['type'][] = ['l' => $r['label'], 'c' => $r['code'], 'vie' => (bool)$r['limited'], 'sys' => $r['sys']];
            else $out[$r['kind']][] = $r['label'];
        }
        return $out + ['rows' => $rows];
    }

    public function addValue(array $actor, int $inv, string $kind, string $label, ?string $ip = null): array
    {
        $this->access->require($actor, $inv, 'edit');
        if (!in_array($kind, self::KINDS, true)) throw new ApiError(422, 'invalid_kind');
        $this->ensureLists($inv);
        $had = $this->valueRow($inv, $kind, $label) !== null;
        $r = $this->addValueRow($inv, $kind, $label);
        if (!$had) $this->note($actor, $inv, 'list.add', $kind, $r['label'], $ip);
        return ['id' => (int)$r['id'], 'label' => $r['label']];
    }

    private function valueForManage(array $actor, int $id): array
    {
        $r = $this->db->one('SELECT * FROM list_values WHERE id = ?', [$id]);
        if (!$r) throw new ApiError(404, 'not_found');
        $this->access->require($actor, (int)$r['inventory_id'], 'delete');
        return $r;
    }
    /** Renommer une valeur : tous les équipements suivent (ils pointent vers l'identifiant). Le code d'un type ne change jamais. */
    public function updateValue(array $actor, int $id, array $patch, ?string $ip = null): void
    {
        $r = $this->valueForManage($actor, $id); $inv = (int)$r['inventory_id'];
        if (array_key_exists('label', $patch)) {
            $label = trim((string)$patch['label']);
            if ($label === '' || mb_strlen($label) > 80) throw new ApiError(422, 'invalid_value');
            $twin = $this->valueRow($inv, $r['kind'], $label);
            if ($twin && (int)$twin['id'] !== $id) throw new ApiError(409, 'value_exists');
            $this->db->run('UPDATE list_values SET label = ? WHERE id = ?', [$label, $id]);
            $this->note($actor, $inv, 'list.rename', $r['kind'], $r['label'] . ' → ' . $label, $ip);
        }
        if (array_key_exists('limited', $patch)) {
            if ($r['kind'] !== 'type') throw new ApiError(422, 'invalid_kind');
            $this->db->run('UPDATE list_values SET limited = ? WHERE id = ?', [empty($patch['limited']) ? 0 : 1, $id]);
            $this->note($actor, $inv, 'list.life', $r['label'], empty($patch['limited']) ? 'durée de vie non limitée' : 'durée de vie limitée', $ip);
        }
    }
    public function removeValue(array $actor, int $id, ?string $ip = null): void
    {
        $r = $this->valueForManage($actor, $id);
        if ($r['sys']) throw new ApiError(409, 'system_value');
        $col = ['etat' => 'etat_id', 'type' => 'type_id', 'marque' => 'marque_id', 'activite' => 'activite_id'][$r['kind']];
        if ((int)$this->db->val("SELECT COUNT(*) FROM items WHERE $col = ?", [$id]) > 0) throw new ApiError(409, 'in_use');
        $this->db->run('DELETE FROM list_values WHERE id = ?', [$id]);
        $this->note($actor, (int)$r['inventory_id'], 'list.remove', $r['kind'], $r['label'], $ip);
    }

    // ------------------------------------------------------------------ lecture
    private const SELECT = 'SELECT i.*, t.label AS type_l, t.sys AS type_sys, t.limited AS type_lim, e.label AS etat_l, e.sys AS etat_sys, m.label AS marque_l, a.label AS act_l, cu.name AS cree_par, uu.name AS maj_par
        FROM items i JOIN list_values t ON t.id = i.type_id JOIN list_values e ON e.id = i.etat_id
        LEFT JOIN list_values m ON m.id = i.marque_id LEFT JOIN list_values a ON a.id = i.activite_id
        LEFT JOIN users cu ON cu.id = i.created_by LEFT JOIN users uu ON uu.id = i.updated_by';

    /** Nom affiché pour « créé par » / « modifié par » : '' si inconnu (fiche d'avant l'enregistrement), « ancien membre » si le compte n'existe plus. */
    private static function who($id, $name): string
    {
        if ($id === null || $id === '') return '';
        return $name !== null && $name !== '' ? (string)$name : 'ancien membre';
    }

    private function shape(array $r, array $measures, bool $withPrice = true): array
    {
        $metres = in_array($r['type_sys'], ['corde', 'sangle'], true);
        $it = ['id' => $r['uid'], 'uid' => $r['uid'], 'etat' => $r['etat_l'], 'etat_sys' => $r['etat_sys'], 'type' => $r['type_l'], 'type_sys' => $r['type_sys'],
            'marque' => $r['marque_l'] ?? '', 'modele' => $r['modele'], 'fab' => $r['fab'], 'achat' => $r['achat'], 'fournisseur' => $r['fournisseur'], 'mes' => $r['mes'],
            'activite' => $r['act_l'] ?? '', 'longueur' => ($metres && $r['longueur'] !== '') ? (float)$r['longueur'] : $r['longueur'], 'lot' => $r['lot'], 'ctrl' => $r['ctrl'], 'par' => $r['par'], 'remarque' => $r['remarque'],
            'mesures' => $measures, 'cree' => $r['created_at'], 'maj' => $r['updated_at'],
            'creePar' => self::who($r['created_by'] ?? null, $r['cree_par'] ?? null), 'majPar' => self::who($r['updated_by'] ?? null, $r['maj_par'] ?? null)];
        if ($withPrice) { $it['prix'] = round((float)($r['prix'] ?? 0), 2); $it['prixM'] = round((float)($r['prix_m'] ?? 0), 4); }
        if ($r['parent_uid'] !== null) $it['parent'] = $r['parent_uid'];
        if ($r['vie_util'] !== null) $it['vieUtil'] = round((float)$r['vie_util'], 6);
        if ($r['vie_totale'] !== null) $it['vieTotale'] = round((float)$r['vie_totale'], 6);
        return $it;
    }
    private function measuresOf(array $ids): array
    {
        $by = [];
        if ($ids) foreach ($this->db->all('SELECT item_id, d, l, par, note FROM item_measures WHERE item_id IN (' . implode(',', array_map('intval', $ids)) . ') ORDER BY id') as $m)
            $by[(int)$m['item_id']][] = ['d' => $m['d'], 'l' => (float)$m['l'], 'par' => $m['par'], 'note' => $m['note']];
        return $by;
    }
    public function snapshot(array $actor, int $inv): array
    {
        $this->access->require($actor, $inv, 'view');
        $this->ensureLists($inv);
        $rows = $this->db->all(self::SELECT . ' WHERE i.inventory_id = ? ORDER BY i.uid', [$inv]);
        $ms = $this->measuresOf(array_map(fn($r) => (int)$r['id'], $rows));
        // les prix ne sont montrés qu'à ceux qui peuvent modifier (admin et responsables matériel dans le club, propriétaire pour le perso)
        $edit = $this->access->can($actor, $inv, 'edit');
        return ['lists' => $this->lists($inv), 'items' => array_map(fn($r) => $this->shape($r, $ms[(int)$r['id']] ?? [], $edit), $rows),
            'docs' => $this->files ? $this->files->counts($inv, $edit) : [], 'photos' => $this->files ? $this->files->photos($inv) : (object)[],
            'people' => $this->access->people($inv),
            'can' => ['edit' => $edit, 'delete' => $this->access->can($actor, $inv, 'delete')]];
    }
    private function loadItem(string $uid): array
    {
        $r = $this->db->one(self::SELECT . ' WHERE i.uid = ?', [$uid]);
        if (!$r) throw new ApiError(404, 'not_found');
        return $r;
    }
    /** « Mesuré / contrôlé par » : un membre ayant accès à la liste (vide = la personne connectée). Une valeur déjà enregistrée reste acceptée telle quelle. */
    private function person(array $actor, int $inv, $v, string $keep = ''): string
    {
        $v = trim((string)$v);
        if ($v === '') return trim((string)($actor['name'] ?? ''));
        if ($keep !== '' && mb_strtolower($v) === mb_strtolower($keep)) return $keep;
        foreach ($this->access->people($inv) as $p) if (mb_strtolower($p['name']) === mb_strtolower($v)) return $p['name'];
        throw new ApiError(422, 'unknown_person');
    }
    private function fullItem(string $uid): array
    {
        $r = $this->loadItem($uid);
        return $this->shape($r, $this->measuresOf([(int)$r['id']])[(int)$r['id']] ?? []);
    }

    // ------------------------------------------------------------------ validation
    /** Ramène les champs reçus à des colonnes valides. $cur = équipement existant (modification) ou null (création). */
    private function columns(int $inv, array $d, ?array $cur, bool $autoAdd): array
    {
        $c = [];
        $resolve = function (string $kind, $label, bool $required) use ($inv, $autoAdd) {
            $label = trim((string)$label);
            if ($label === '') { if ($required) throw new ApiError(422, 'missing_' . $kind); return null; }
            $r = $this->valueRow($inv, $kind, $label);
            if (!$r) { if (!$autoAdd) throw new ApiError(422, 'unknown_' . $kind); $r = $this->addValueRow($inv, $kind, $label); }
            return $r;
        };
        if ($cur === null) {
            $t = $resolve('type', $d['type'] ?? '', true); $c['type_id'] = (int)$t['id']; $c['_type'] = $t;
        } else $c['_type'] = ['sys' => $cur['type_sys'], 'limited' => $cur['type_lim'], 'label' => $cur['type_l']];
        if ($cur === null || array_key_exists('etat', $d)) {
            $e = ($d['etat'] ?? '') === '' ? ['id' => $this->sysId($inv, 'etat', 'stock')] : $resolve('etat', $d['etat'], true);
            $c['etat_id'] = (int)$e['id'];
        }
        foreach (['marque' => 'marque_id', 'activite' => 'activite_id'] as $k => $col) if ($cur === null || array_key_exists($k, $d)) { $r = $resolve($k, $d[$k] ?? '', false); $c[$col] = $r ? (int)$r['id'] : null; }
        foreach (self::TEXT as $k => $max) if ($cur === null || array_key_exists($k, $d)) {
            $v = trim((string)($d[$k] ?? '')); if (mb_strlen($v) > $max) throw new ApiError(422, 'too_long', ['field' => $k]);
            if ($k === 'par' && $v !== '' && !$autoAdd) {   // contrôlé par : un membre ayant accès à la liste (ou la valeur déjà enregistrée)
                $keep = (string)($cur['par'] ?? ''); $ok = $keep !== '' && mb_strtolower($v) === mb_strtolower($keep);
                if (!$ok) foreach ($this->access->people($inv) as $pp) if (mb_strtolower($pp['name']) === mb_strtolower($v)) { $v = $pp['name']; $ok = true; break; }
                if (!$ok) throw new ApiError(422, 'unknown_person');
            }
            $c[$k] = $v;
        }
        if ($cur === null || array_key_exists('prix', $d)) {
            $raw = trim(str_replace(["\u{20AC}", ' ', "\u{00A0}"], '', (string)($d['prix'] ?? '')));
            if ($raw === '') $c['prix'] = 0.0;
            else {
                $raw = str_replace(',', '.', $raw);
                if (!is_numeric($raw) || (float)$raw < 0 || (float)$raw > 9999999) throw new ApiError(422, 'invalid_price');
                $c['prix'] = round((float)$raw, 2);
            }
        }
        foreach (self::DATES as $k) if ($cur === null || array_key_exists($k, $d)) {
            $v = trim((string)($d[$k] ?? '')); if ($v !== '' && !self::validDate($v)) throw new ApiError(422, 'invalid_date', ['field' => $k]); $c[$k] = $v;
        }
        if ($cur === null || array_key_exists('longueur', $d)) {
            $raw = $d['longueur'] ?? '';
            if (in_array($c['_type']['sys'], ['corde', 'sangle'], true) && trim((string)$raw) !== '') {
                $n = self::metres($raw); if ($n === null) throw new ApiError(422, 'invalid_length'); $c['longueur'] = (string)$n;
            } else $c['longueur'] = '';   // la longueur n'existe que pour les cordes et les sangles
        }
        // prix au mètre : figé à l'achat, recalculé seulement si l'utilisateur change le prix ou la longueur d'origine
        if (in_array($c['_type']['sys'], ['corde', 'sangle'], true)) {
            $pr = (float)($c['prix'] ?? ($cur['prix'] ?? 0)); $lg = (float)($c['longueur'] ?? ($cur['longueur'] ?? 0));
            $hasKids = $cur !== null && $this->db->val('SELECT 1 FROM items WHERE parent_uid = ?', [$cur['uid']]);   // une bobine déjà coupée garde son prix au mètre
            $changed = !$hasKids && ($cur === null || (array_key_exists('prix', $c) && round($c['prix'], 2) !== round((float)$cur['prix'], 2)) || (array_key_exists('longueur', $c) && (float)$c['longueur'] !== (float)$cur['longueur']));
            if ($changed) $c['prix_m'] = ($pr > 0 && $lg > 0) ? round($pr / $lg, 4) : 0.0;
        }
        foreach (['vieUtil' => 'vie_util', 'vieTotale' => 'vie_totale'] as $k => $col) if (($cur === null || array_key_exists($k, $d)) && array_key_exists($k, $d)) {
            if (!$c['_type']['limited']) { $c[$col] = null; continue; }
            $y = self::years($d[$k] ?? ''); if (($d[$k] ?? '') !== '' && $y === null) throw new ApiError(422, 'invalid_years', ['field' => $k]); $c[$col] = $y;
        }
        return $c;
    }
    private function needName(array $c, ?array $cur): void
    {
        $marque = array_key_exists('marque_id', $c) ? $c['marque_id'] : ($cur['marque_id'] ?? null);
        $modele = array_key_exists('modele', $c) ? $c['modele'] : ($cur['modele'] ?? '');
        if (!$marque && $modele === '') throw new ApiError(422, 'name_required');
    }
    private function rootOf(string $uid): string
    {
        for ($n = 0; $n < 50; $n++) { $p = $this->db->val('SELECT parent_uid FROM items WHERE uid = ?', [$uid]); if ($p === null || $p === '' || !$this->db->val('SELECT 1 FROM items WHERE uid = ?', [$p])) return $uid; $uid = $p; }
        return $uid;
    }
    private function checkLot(int $inv, array $c, ?array $cur, ?string $parent): void
    {
        $lot = array_key_exists('lot', $c) ? $c['lot'] : ($cur['lot'] ?? '');
        if ($lot === '') return;
        $marque = array_key_exists('marque_id', $c) ? $c['marque_id'] : ($cur['marque_id'] ?? null);
        $mine = $cur ? $this->rootOf($cur['uid']) : ($parent ? $this->rootOf($parent) : null);
        foreach ($this->db->all('SELECT uid, marque_id, lot FROM items WHERE inventory_id = ? AND lot <> ?', [$inv, '']) as $o) {
            if (self::nkey($o['lot']) !== self::nkey($lot) || (int)$o['marque_id'] !== (int)$marque) continue;
            if ($cur && $o['uid'] === $cur['uid']) continue;
            if ($mine !== null && $this->rootOf($o['uid']) === $mine) continue;
            throw new ApiError(409, 'duplicate_lot', ['uid' => $o['uid']]);
        }
    }

    // ------------------------------------------------------------------ UID
    private function uidPrefix(int $inv): string
    {
        $o = $this->db->val("SELECT owner_user_id FROM inventories WHERE id = ? AND kind = 'member'", [$inv]);
        return $o === null ? '' : Users::memberLabel((int)$this->db->val('SELECT member_no FROM users WHERE id = ?', [$o])) . '-';
    }
    /** Ramène un UID du fichier à l'inventaire visé : le préfixe membre (M07-) est remplacé par celui de l'inventaire. '' si le format est invalide. */
    private function normUid(int $inv, string $uid): string
    {
        $u = (string)preg_replace('/^M\d+-/', '', strtoupper(trim($uid)));
        return preg_match('/^[A-Z]{2,4}-\d{1,6}$/', $u) ? $this->uidPrefix($inv) . $u : '';
    }
    private function bumpCounter(int $inv, string $code, int $seq): void
    {
        $cur = $this->db->val('SELECT last FROM uid_counters WHERE inventory_id = ? AND code = ?' . ($this->db->isSqlite() ? '' : ' FOR UPDATE'), [$inv, $code]);
        if ($cur === null) $this->db->run('INSERT INTO uid_counters (inventory_id, code, last) VALUES (?,?,?)', [$inv, $code, $seq]);
        elseif ((int)$cur < $seq) $this->db->run('UPDATE uid_counters SET last = ? WHERE inventory_id = ? AND code = ?', [$seq, $inv, $code]);
    }
    /** Dans une transaction : verrouille la liste (MariaDB) pour que les contrôles « existe déjà », les numéros d'UID et les longueurs de corde se fassent l'un après l'autre, jamais en même temps. SQLite verrouille déjà tout (BEGIN IMMEDIATE). */
    private function lockInv(int $inv): void
    {
        if (!$this->db->isSqlite()) $this->db->val('SELECT id FROM inventories WHERE id = ? FOR UPDATE', [$inv]);
    }
    private function nextSeq(int $inv, string $code): int
    {
        $last = $this->db->val('SELECT last FROM uid_counters WHERE inventory_id = ? AND code = ?' . ($this->db->isSqlite() ? '' : ' FOR UPDATE'), [$inv, $code]);
        $max = $this->db->val('SELECT MAX(seq) FROM items WHERE inventory_id = ? AND code = ?', [$inv, $code]);
        $n = max((int)$last, (int)$max) + 1;
        $this->bumpCounter($inv, $code, $n);
        return $n;
    }
    private function uidFor(int $inv, string $code, int $seq): string { return $this->uidPrefix($inv) . $code . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT); }

    // ------------------------------------------------------------------ équipements
    /** Création interne (dans une transaction). $forced = UID imposé (import). */
    private function insertItem(array $actor, int $inv, array $d, bool $autoAdd, ?string $forced = null, ?string $parent = null): string
    {
        $this->lockInv($inv);
        $c = $this->columns($inv, $d, null, $autoAdd);
        if ($parent !== null && ($pr = $this->db->one('SELECT * FROM items WHERE uid = ?', [$parent]))) foreach (self::INHERITED as $col) $c[$col] = $pr[$col];   // un morceau ne diffère pas de sa bobine
        if ($parent !== null && !empty($pr) && (float)$pr['prix_m'] > 0 && in_array($c['_type']['sys'], ['corde', 'sangle'], true)) { $c['prix_m'] = (float)$pr['prix_m']; $c['prix'] = round($c['prix_m'] * (float)($c['longueur'] ?? 0), 2); }   // prix donné par la bobine
        $this->needName($c, null);
        $this->checkLot($inv, $c, null, $parent);
        $type = $c['_type']; unset($c['_type']);
        $code = (string)$type['code'];
        $seq = null;
        if ($forced !== null && preg_match('/^' . preg_quote($this->uidPrefix($inv), '/') . '([A-Z]{2,4})-(\d{1,6})$/', $forced, $m) && $m[1] === $code
            && !$this->db->val('SELECT 1 FROM items WHERE uid = ?', [$forced])) { $seq = (int)$m[2]; $this->bumpCounter($inv, $code, $seq); $uid = $forced; }
        else { $seq = $this->nextSeq($inv, $code); $uid = $this->uidFor($inv, $code, $seq); }
        $now = Clock::ts();
        $row = $c + ['inventory_id' => $inv, 'uid' => $uid, 'code' => $code, 'seq' => $seq, 'parent_uid' => $parent, 'created_at' => $now, 'created_by' => (int)$actor['id'], 'updated_at' => $now, 'updated_by' => (int)$actor['id']];
        $row += ['marque_id' => null, 'activite_id' => null, 'vie_util' => null, 'vie_totale' => null];
        $cols = array_keys($row);
        $this->db->run('INSERT INTO items (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($row));
        return $uid;
    }

    public function create(array $actor, int $inv, array $data, ?string $ip = null): array
    {
        $this->access->require($actor, $inv, 'edit');
        $this->ensureLists($inv);
        $uid = $this->db->tx(fn() => $this->insertItem($actor, $inv, $data, false));
        $it = $this->fullItem($uid);
        $this->note($actor, $inv, 'item.create', $uid, trim($it['type'] . ' ' . $it['marque'] . ' ' . $it['modele']), $ip);
        return $it;
    }

    /** Crée des copies d'un équipement : une par entrée de $lots (n° de lot / série de chaque copie, '' = vide). Tout ou rien. */
    public function duplicate(array $actor, string $uid, array $lots, ?string $ip = null): array
    {
        $cur = $this->loadItem($uid); $inv = (int)$cur['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        $n = count($lots);
        if ($n < 1 || $n > 50) throw new ApiError(422, 'invalid_count', ['max' => 50]);
        $src = $this->fullItem($uid);
        $base = [];
        foreach (['type', 'etat', 'marque', 'modele', 'fab', 'achat', 'fournisseur', 'mes', 'activite', 'longueur', 'remarque', 'prix', 'vieUtil', 'vieTotale'] as $k) if (array_key_exists($k, $src)) $base[$k] = $src[$k];
        $this->ensureLists($inv);
        $made = $this->db->tx(function () use ($actor, $inv, $base, $lots, $cur) {
            $out = [];
            foreach (array_values($lots) as $i => $lot) {
                try { $out[] = $this->insertItem($actor, $inv, $base + ['lot' => trim((string)$lot)], false); }
                catch (ApiError $e) { throw new ApiError($e->status, $e->errorCode, $e->extra + ['index' => $i]); }
            }
            if ($this->files) $this->files->copyLinks((int)$cur['id'], $out);
            return $out;
        });
        foreach ($made as $u) $this->note($actor, $inv, 'item.create', $u, trim($src['type'] . ' ' . $src['marque'] . ' ' . $src['modele']) . ' (copie de ' . $uid . ')', $ip);
        $items = array_map(fn($u) => $this->fullItem($u), $made);
        return ['items' => $items];
    }

    public function update(array $actor, string $uid, array $patch, ?string $ip = null): array
    {
        $cur = $this->loadItem($uid); $inv = (int)$cur['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        unset($patch['type']);
        $before = $this->fullItem($uid);
        $c = $this->columns($inv, $patch, $cur, false); unset($c['_type']);
        $isChild = $cur['parent_uid'] !== null && $cur['parent_uid'] !== '' && $this->db->val('SELECT 1 FROM items WHERE uid = ?', [$cur['parent_uid']]);
        if ($isChild) {
            $bad = [];
            foreach (self::INHERITED as $col) if (array_key_exists($col, $c)) {
                $same = in_array($col, ['vie_util', 'vie_totale'], true) ? ($c[$col] === null ? $cur[$col] === null : ($cur[$col] !== null && abs((float)$c[$col] - (float)$cur[$col]) < 0.0001)) : ((string)($c[$col] ?? '') === (string)($cur[$col] ?? ''));
                if ($same) unset($c[$col]); else $bad[] = array_search($col, self::INHERITED_API, true);
            }
            // le prix d'un morceau est donné par sa bobine : prix au mètre x longueur d'origine du morceau
            $pm = (float)$cur['prix_m'];
            if ($pm > 0 && in_array($cur['type_sys'], ['corde', 'sangle'], true)) {
                $len = (float)($c['longueur'] ?? $cur['longueur']); $due = round($pm * $len, 2);
                if (array_key_exists('prix', $c) && abs($c['prix'] - $due) > 0.004 && abs($c['prix'] - (float)$cur['prix']) > 0.004) $bad[] = 'prix';
                $c['prix'] = $due; unset($c['prix_m']);
            }
            if (array_key_exists('longueur', $c)) { if ((float)$c['longueur'] === (float)$cur['longueur']) unset($c['longueur']); else $bad[] = 'longueur'; }
            if ($bad) throw new ApiError(422, 'inherited_field', ['fields' => $bad, 'parent' => $cur['parent_uid']]);
        }
        $this->needName($c, $cur);
        $this->db->tx(function () use ($c, $cur, $actor, $inv) {
            $this->lockInv($inv); $this->checkLot($inv, $c, $cur, null);
            if ($c) {
                $c['updated_at'] = Clock::ts(); $c['updated_by'] = (int)$actor['id'];
                $this->db->run('UPDATE items SET ' . implode(', ', array_map(fn($k) => "$k = ?", array_keys($c))) . ' WHERE id = ?', array_merge(array_values($c), [$cur['id']]));
            }
        });
        $propagated = $this->propagate($actor, $inv, $cur, $ip);
        $after = $this->fullItem($uid);
        $diff = [];
        foreach (self::AUDIT_FIELDS as $k => $label) if (($before[$k] ?? '') !== ($after[$k] ?? '')) $diff[] = $label . ' : ' . (($before[$k] ?? '') === '' ? '∅' : $before[$k]) . ' → ' . (($after[$k] ?? '') === '' ? '∅' : $after[$k]);
        if ($diff) $this->note($actor, $inv, 'item.update', $uid, implode(' ; ', $diff), $ip);
        return $after;
    }

    /** Action groupée sur des équipements d'une même liste : 'control' (date + contrôlé par) ou 'etat' (nouvel état, par exemple Déclassé).
     *  Tout ou rien : si un équipement est refusé, aucun n'est modifié. Chaque équipement garde sa trace dans le journal (comme une modification à la main). */
    public function bulk(array $actor, int $inv, array $uids, string $action, array $p, ?string $ip = null): array
    {
        $this->access->require($actor, $inv, 'edit');
        $uids = array_values(array_unique(array_map('strval', $uids)));
        if (!$uids) throw new ApiError(422, 'no_selection');
        if (count($uids) > 200) throw new ApiError(413, 'too_many_items', ['max' => 200]);
        if ($action === 'control') {
            $d = trim((string)($p['date'] ?? ''));
            if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $d, $m) || !checkdate((int)$m[2], (int)$m[3], (int)$m[1])) throw new ApiError(422, 'invalid_date');
            if ($d > gmdate('Y-m-d', Clock::now() + 86400)) throw new ApiError(422, 'future_date');   // un contrôle ne peut pas être dans le futur (un jour de marge pour les fuseaux)
            $par = $this->person($actor, $inv, $p['par'] ?? '');
            $patch = ['ctrl' => $d, 'par' => $par]; $label = 'contrôle du ' . $d . ($par !== '' ? ' par ' . $par : '');
        } elseif ($action === 'etat') {
            $e = trim((string)($p['etat'] ?? ''));
            if ($e === '') throw new ApiError(422, 'missing_etat');
            $row = $this->valueRow($inv, 'etat', $e); if (!$row) throw new ApiError(422, 'unknown_etat');
            $patch = ['etat' => $row['label']]; $label = 'état « ' . $row['label'] . ' »';
        } else throw new ApiError(422, 'invalid_action');
        foreach ($uids as $u) {
            $r = $this->db->one('SELECT inventory_id FROM items WHERE uid = ?', [$u]);
            if (!$r || (int)$r['inventory_id'] !== $inv) throw new ApiError(404, 'not_found', ['uid' => $u]);
        }
        $out = $this->db->tx(function () use ($actor, $inv, $uids, $patch, $ip) {
            $this->lockInv($inv); $res = [];
            foreach ($uids as $u) {
                try { $res[] = $this->update($actor, $u, $patch, $ip); }
                catch (ApiError $e) { throw new ApiError($e->status, $e->errorCode, $e->extra + ['uid' => $u]); }
            }
            return $res;
        });
        $this->note($actor, $inv, 'item.bulk', null, count($out) . ' équipement' . (count($out) > 1 ? 's' : '') . ' : ' . $label, $ip);
        return ['items' => $out, 'count' => count($out)];
    }

    /** Après modification d'une bobine : recopie ses caractéristiques communes sur tous ses morceaux (et leurs morceaux), avec trace dans le journal du club. */
    private function propagate(array $actor, int $inv, array $before, ?string $ip): int
    {
        $uid = $before['uid'];
        $kids = $this->db->all('SELECT uid FROM items WHERE parent_uid = ?', [$uid]);
        if (!$kids) return 0;
        $now = $this->loadItem($uid); $set = []; $labels = [];
        foreach (self::INHERITED as $col) if ((string)($before[$col] ?? '') !== (string)($now[$col] ?? '') && !(in_array($col, ['vie_util', 'vie_totale'], true) && $before[$col] !== null && $now[$col] !== null && abs((float)$before[$col] - (float)$now[$col]) < 0.0001)) { $set[$col] = $now[$col]; $labels[] = self::AUDIT_FIELDS[array_search($col, self::INHERITED_API, true)] ?? $col; }
        if (!$set) return 0;
        $n = 0; $todo = array_column($kids, 'uid'); $seen = [];
        while ($todo) {
            $u = array_shift($todo); if (isset($seen[$u])) continue; $seen[$u] = 1;
            $this->db->run('UPDATE items SET ' . implode(', ', array_map(fn($k) => "$k = ?", array_keys($set))) . ', updated_at = ?, updated_by = ? WHERE uid = ?', array_merge(array_values($set), [Clock::ts(), (int)$actor['id'], $u]));
            $this->note($actor, $inv, 'item.update', $u, 'hérité de ' . $uid . ' : ' . implode(', ', $labels), $ip);
            $n++;
            foreach ($this->db->all('SELECT uid FROM items WHERE parent_uid = ?', [$u]) as $k) $todo[] = $k['uid'];
        }
        return $n;
    }

    public function delete(array $actor, string $uid, ?string $ip = null): void
    {
        $cur = $this->loadItem($uid); $inv = (int)$cur['inventory_id'];
        $this->access->require($actor, $inv, 'delete');
        // les morceaux se retirent par « annuler la découpe » (la longueur retourne à la bobine) ; une bobine ne disparaît pas avec ses morceaux
        if ($this->db->val('SELECT 1 FROM items WHERE parent_uid = ?', [$uid])) throw new ApiError(409, 'has_pieces');
        if ($cur['parent_uid'] !== null && $cur['parent_uid'] !== '' && $this->db->val('SELECT 1 FROM items WHERE uid = ?', [$cur['parent_uid']])) throw new ApiError(409, 'is_piece', ['parent' => $cur['parent_uid']]);
        $label = trim($cur['type_l'] . ' ' . ($cur['marque_l'] ?? '') . ' ' . $cur['modele']);
        $this->db->tx(function () use ($cur) {
            $this->db->run('DELETE FROM item_measures WHERE item_id = ?', [$cur['id']]);
            $this->files?->purgeItem((int)$cur['id']);
            $this->db->run('DELETE FROM items WHERE id = ?', [$cur['id']]);
        });
        $this->note($actor, $inv, 'item.delete', $uid, $label, $ip);
    }

    /** Annule la découpe d'un morceau : sa longueur et son prix retournent à la bobine, le morceau disparaît (son UID n'est jamais réutilisé). */
    public function uncut(array $actor, string $uid, ?string $ip = null): array
    {
        $c = $this->loadItem($uid); $inv = (int)$c['inventory_id'];
        $this->access->require($actor, $inv, 'delete');
        $pu = (string)($c['parent_uid'] ?? '');
        $p = $pu !== '' ? $this->db->one(self::SELECT . ' WHERE i.uid = ?', [$pu]) : null;
        if (!$p) throw new ApiError(422, 'not_a_piece');
        if ($this->db->val('SELECT 1 FROM items WHERE parent_uid = ?', [$uid])) throw new ApiError(409, 'has_pieces');
        $len = self::metres($c['longueur']);
        $this->db->tx(function () use ($actor, $c, $uid, $len, $inv, $pu) {
            $this->lockInv($inv);
            $p = $this->db->one(self::SELECT . ' WHERE i.uid = ?', [$pu]); if (!$p) throw new ApiError(422, 'not_a_piece');
            $pid = (int)$p['id']; $patch = ['updated_at' => Clock::ts(), 'updated_by' => (int)$actor['id'], 'prix' => round((float)$p['prix'] + (float)$c['prix'], 2)];
            if ($len !== null && $len > 0) {
                $now = (float)($this->lenNow($p) ?? 0); $new = round($now + $len, 2);
                $this->addMeasureRow($pid, self::today(), $new, '', 'Découpe de ' . $uid . ' annulée (+' . self::fmtM($len) . ')');
                if ($p['etat_sys'] === 'epuise' && ($st = $this->sysId($inv, 'etat', 'stock'))) $patch['etat_id'] = $st;   // la bobine n'est plus épuisée
            }
            $this->db->run('UPDATE items SET ' . implode(', ', array_map(fn($k) => "$k = ?", array_keys($patch))) . ' WHERE id = ?', array_merge(array_values($patch), [$pid]));
            $this->db->run('DELETE FROM item_measures WHERE item_id = ?', [$c['id']]);
            $this->files?->purgeItem((int)$c['id']);
            $this->db->run('DELETE FROM items WHERE id = ?', [$c['id']]);
        });
        $this->note($actor, $inv, 'item.uncut', $uid, 'découpe annulée : ' . ($len !== null ? self::fmtM($len) : '?') . ' rendus à ' . $pu, $ip);
        return ['item' => $this->fullItem($pu)];
    }

    private function addMeasureRow(int $itemId, string $d, float $l, string $par, string $note): void
    {
        $this->db->run('INSERT INTO item_measures (item_id, d, l, par, note) VALUES (?,?,?,?,?)', [$itemId, $d, $l, mb_substr($par, 0, 80), mb_substr($note, 0, 200)]);
    }
    private function lenNow(array $r): ?float
    {
        $l = $this->db->val('SELECT l FROM item_measures WHERE item_id = ? ORDER BY id DESC LIMIT 1', [$r['id']]);
        return $l !== null ? round((float)$l, 2) : self::metres($r['longueur']);
    }

    public function addMeasure(array $actor, string $uid, array $d, ?string $ip = null): array
    {
        $r = $this->loadItem($uid); $inv = (int)$r['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        if (!in_array($r['type_sys'], ['corde', 'sangle'], true)) throw new ApiError(422, 'not_measurable');
        $l = self::metres($d['l'] ?? null); if ($l === null) throw new ApiError(422, 'invalid_length');
        $date = trim((string)($d['d'] ?? '')) ?: self::today(); if (!self::validDate($date)) throw new ApiError(422, 'invalid_date');
        $this->addMeasureRow((int)$r['id'], $date, $l, $this->person($actor, $inv, $d['par'] ?? ''), trim((string)($d['note'] ?? '')) ?: 'Nouvelle mesure');
        $this->db->run('UPDATE items SET updated_at = ?, updated_by = ? WHERE id = ?', [Clock::ts(), $actor['id'], $r['id']]);
        $this->note($actor, $inv, 'item.measure', $uid, self::fmtM($l), $ip);
        return $this->fullItem($uid);
    }

    /** Découpe d'une corde en morceaux : tout ou rien. @param float[]|string[] $pieces */
    public function cut(array $actor, string $uid, array $pieces, array $opt, ?string $ip = null): array
    {
        $p = $this->loadItem($uid); $inv = (int)$p['inventory_id'];
        $this->access->require($actor, $inv, 'edit');
        if ($p['type_sys'] !== 'corde') throw new ApiError(422, 'not_cuttable');
        if (in_array($p['etat_sys'], ['declasse', 'perdu', 'epuise'], true)) throw new ApiError(409, 'not_in_use');
        $cur = $this->lenNow($p);
        if ($cur === null) throw new ApiError(422, 'length_unknown');
        if (!$pieces) throw new ApiError(422, 'no_pieces');
        $vals = array_map([self::class, 'metres'], $pieces);
        foreach ($vals as $v) if ($v === null || $v <= 0) throw new ApiError(422, 'invalid_piece');
        if (count($vals) > 50) throw new ApiError(422, 'too_many_pieces');
        if (round($cur - array_sum($vals), 2) < 0) throw new ApiError(422, 'too_long', ['available' => $cur]);
        $mes = trim((string)($opt['mes'] ?? '')); if ($mes !== '' && !self::validDate($mes)) throw new ApiError(422, 'invalid_date');
        $etat = trim((string)($opt['etat'] ?? '')) ?: 'Stock';
        $made = $this->db->tx(function () use ($actor, $uid, $inv, $vals, $mes, $etat, $opt) {
            $this->lockInv($inv);
            $p = $this->loadItem($uid); $cur = $this->lenNow($p);   // relu sous verrou : une autre découpe a pu passer entre-temps
            if (in_array($p['etat_sys'], ['declasse', 'perdu', 'epuise'], true)) throw new ApiError(409, 'not_in_use');
            if ($cur === null || round($cur - array_sum($vals), 2) < 0) throw new ApiError(422, 'too_long', ['available' => $cur ?? 0]);
            $er = $this->valueRow($inv, 'etat', $etat); if (!$er) throw new ApiError(422, 'unknown_etat');
            $day = self::today(); $rest = $cur; $made = []; $pid = (int)$p['id']; $given = 0.0;
            foreach ($vals as $v) {
                $data = ['etat' => $er['label'], 'type' => $p['type_l'], 'marque' => $p['marque_l'] ?? '', 'modele' => $p['modele'], 'fab' => $p['fab'], 'achat' => $p['achat'],
                    'fournisseur' => $p['fournisseur'], 'mes' => $mes, 'activite' => $p['act_l'] ?? '', 'longueur' => $v, 'lot' => $p['lot'], 'ctrl' => '', 'par' => '', 'remarque' => ''];
                if ($p['vie_util'] !== null) $data['vieUtil'] = (float)$p['vie_util'];
                if ($p['vie_totale'] !== null) $data['vieTotale'] = (float)$p['vie_totale'];
                $share = (float)$p['prix_m'] > 0 ? round((float)$p['prix_m'] * $v, 2) : ($cur > 0 ? round((float)$p['prix'] * $v / $cur, 2) : 0.0); $data['prix'] = $share; $given += $share;   // prix au mètre de la bobine x longueur du morceau
                $u = $this->insertItem($actor, $inv, $data, false, null, $p['uid']);
                if ((float)$p['prix_m'] > 0) $this->db->run('UPDATE items SET prix_m = ? WHERE uid = ?', [(float)$p['prix_m'], $u]);
                $rest = round($rest - $v, 2);
                $this->addMeasureRow($pid, $day, $rest, '', 'Découpe de ' . $u . ' (' . self::fmtM($v) . ')');
                $made[] = $u;
            }
            $patch = [];
            if (!empty($opt['rebut']) && $rest > 0) { $this->addMeasureRow($pid, $day, 0.0, '', 'Rebut : ' . self::fmtM($rest)); $rest = 0.0; }
            if (!empty($opt['declasser'])) { $patch['etat_id'] = $this->sysId($inv, 'etat', 'declasse'); }
            elseif ($rest <= 0 && $p['etat_sys'] === 'stock' && ($ep = $this->sysId($inv, 'etat', 'epuise'))) {
                $patch['etat_id'] = $ep;
                $last = $this->db->one('SELECT id, l, note FROM item_measures WHERE item_id = ? ORDER BY id DESC LIMIT 1', [$pid]);
                if ($last && (float)$last['l'] === 0.0) $this->db->run('UPDATE item_measures SET note = ? WHERE id = ?', [mb_substr($last['note'] . ' · bobine épuisée', 0, 200), $last['id']]);
                else $this->addMeasureRow($pid, $day, 0.0, '', 'Entièrement découpée : bobine épuisée');
            }
            $patch = array_filter($patch, fn($x) => $x !== null);
            $patch['prix'] = $rest <= 0 ? 0.0 : max(0.0, round((float)$p['prix'] - $given, 2));
            $patch['updated_at'] = Clock::ts(); $patch['updated_by'] = (int)$actor['id'];
            $this->db->run('UPDATE items SET ' . implode(', ', array_map(fn($k) => "$k = ?", array_keys($patch))) . ' WHERE id = ?', array_merge(array_values($patch), [$pid]));
            return $made;
        });
        $this->note($actor, $inv, 'item.cut', $uid, count($made) . ' morceau(x) : ' . implode(', ', $made), $ip);
        return ['made' => $made, 'item' => $this->fullItem($uid)];
    }

    /**
     * Import en lot (CSV préparé par l'interface). Chaque ligne : ['uid' => ?, 'data' => [...], 'cur' => ?float, 'line' => n].
     * Une ligne refusée n'empêche pas les autres ; le résultat liste ce qui a été fait et ce qui a été écarté.
     */
    public function import(array $actor, int $inv, array $rows, ?string $ip = null): array
    {
        $this->access->require($actor, $inv, 'edit');
        if (count($rows) > 2000) throw new ApiError(413, 'too_many_rows');
        $this->ensureLists($inv);
        $res = ['created' => 0, 'updated' => 0, 'errors' => []];
        foreach ($rows as $row) {
            $line = (int)($row['line'] ?? 0); $data = (array)($row['data'] ?? []); $uid = $this->normUid($inv, (string)($row['uid'] ?? '')); $cur = $row['cur'] ?? null;
            try {
                $this->db->tx(function () use ($actor, $inv, $data, $uid, $cur, &$res) {
                    $exists = $uid !== '' ? $this->db->one('SELECT * FROM items WHERE uid = ?', [$uid]) : null;
                    if ($exists && (int)$exists['inventory_id'] !== $inv) $exists = null;
                    if ($exists) {
                        unset($data['type']); $c = $this->columns($inv, $data, $this->loadItem($uid), true); unset($c['_type']);
                        $this->needName($c, $this->loadItem($uid)); $this->checkLot($inv, $c, $this->loadItem($uid), null);
                        if ($c) { $c['updated_at'] = Clock::ts(); $c['updated_by'] = (int)$actor['id'];
                            $this->db->run('UPDATE items SET ' . implode(', ', array_map(fn($k) => "$k = ?", array_keys($c))) . ' WHERE id = ?', array_merge(array_values($c), [$exists['id']])); }
                        $target = $uid; $res['updated']++;
                    } else {
                        $parent = $this->normUid($inv, (string)($data['parent'] ?? '')) ?: null; unset($data['parent']);
                        $target = $this->insertItem($actor, $inv, $data, true, $uid !== '' ? $uid : null, $parent); $res['created']++;
                    }
                    if ($cur !== null && is_numeric($cur)) {
                        $r = $this->loadItem($target);
                        if (in_array($r['type_sys'], ['corde', 'sangle'], true)) {
                            $now = $this->lenNow($r);
                            if ($now === null || abs($now - (float)$cur) >= 0.005) $this->addMeasureRow((int)$r['id'], self::today(), round((float)$cur, 2), '', 'Importé du CSV');
                        }
                    }
                });
            } catch (ApiError $e) { $res['errors'][] = ['line' => $line, 'error' => $e->errorCode]; }
        }
        $this->note($actor, $inv, 'item.import', null, $res['created'] . ' créé(s), ' . $res['updated'] . ' mis à jour, ' . count($res['errors']) . ' refusé(s)', $ip);
        return $res;
    }
}
