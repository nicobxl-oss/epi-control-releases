<?php
use Epi\{App, Api, Clock, Totp};

/** Petit client de test : garde le cookie de session et l'en-tête CSRF comme le ferait un navigateur. */
function client(App $app, string $ip = '5.5.5.5'): object
{
    return new class($app, $ip) {
        public array $cookies = []; public ?string $csrf = null; public array $headers = [];
        public function __construct(private App $app, private string $ip) {}
        public function call(string $m, string $p, array $b = [], array $extra = []): array
        {
            $h = $this->headers + $extra + ($m !== 'GET' && $this->csrf ? ['X-CSRF-Token' => $this->csrf] : []);
            [$s, $d, $c] = (new Api($this->app))->handle($m, $p, $b, $this->cookies, $h, $this->ip);
            foreach ($c as $ck) { if ($ck['expires'] <= 1 || $ck['value'] === '') unset($this->cookies[$ck['name']]); else $this->cookies[$ck['name']] = $ck['value']; }
            return [$s, $d, $c];
        }
        public function login(string $email, string $pw, string $secret): array
        {
            [$s] = $this->call('POST', '/login', ['email' => $email, 'password' => $pw]); eq($s, 200);
            Clock::advance(31);
            [$s, $d] = $this->call('POST', '/login/verify', ['code' => Totp::code($secret, Totp::step())]); eq($s, 200);
            $this->csrf = $d['csrf']; return $d;
        }
    };
}
function apiWorld(): array
{
    $app = freshApp(); $boot = $app->bootstrap('Club', 'a@club.be', 'Admin');
    $api = client($app);
    [$s, $st] = $api->call('POST', '/activate/start', ['token' => $boot['token']]); eq($s, 200);
    [$s, $fin] = $api->call('POST', '/activate/finish', ['token' => $boot['token'], 'password' => PW, 'code' => Totp::code($st['secret'], Totp::step())]); eq($s, 200);
    return ['app' => $app, 'secret' => $st['secret'], 'codes' => $fin['recovery_codes']];
}

t('API : parcours complet invitation → activation → connexion → /me', function () {
    $w = apiWorld(); $api = client($w['app']);
    [$s] = $api->call('GET', '/me'); eq($s, 401);
    $api->login('a@club.be', PW, $w['secret']);
    [$s, $d] = $api->call('GET', '/me'); eq($s, 200); eq($d['user']['member'], 'M01'); ok(!isset($d['user']['password_hash']));
    eq(count($d['inventories']), 2);
});
t('API : la session « pre » (mot de passe seul) ne donne accès à rien', function () {
    $w = apiWorld(); $api = client($w['app']);
    [$s] = $api->call('POST', '/login', ['email' => 'a@club.be', 'password' => PW]); eq($s, 200);
    [$s] = $api->call('GET', '/me'); eq($s, 401);
});
t('API : CSRF obligatoire sur les écritures', function () {
    $w = apiWorld(); $api = client($w['app']); $api->login('a@club.be', PW, $w['secret']);
    $good = $api->csrf; $api->csrf = null;
    [$s, $d] = $api->call('POST', '/admin/users', ['email' => 'b@club.be', 'name' => 'Bob', 'role' => 'member']); eq($s, 403); eq($d['error'], 'csrf');
    $api->csrf = 'faux'; [$s] = $api->call('POST', '/admin/users', ['email' => 'b@club.be', 'name' => 'Bob', 'role' => 'member']); eq($s, 403);
    $api->csrf = $good; [$s, $d] = $api->call('POST', '/admin/users', ['email' => 'b@club.be', 'name' => 'Bob', 'role' => 'member']); eq($s, 201); ok(str_contains($d['invite_path'], '/invitation/'));
});
t('API : origine étrangère refusée', function () {
    $w = apiWorld(); $app = $w['app'];
    $app2 = new App($app->db, $app->crypto, $app->audit, $app->throttle, $app->auth, $app->users, $app->access, $app->config + ['base_url' => 'https://epi-test.molron.be'], $app->registry);
    [$s, $d] = (new Api($app2))->handle('POST', '/login', ['email' => 'a@club.be', 'password' => PW], [], ['Origin' => 'https://evil.example'], '1.1.1.1');
    eq($s, 403); eq($d['error'], 'bad_origin');
    [$s] = (new Api($app2))->handle('POST', '/login', ['email' => 'a@club.be', 'password' => PW], [], ['Origin' => 'https://epi-test.molron.be'], '1.1.1.1'); eq($s, 200);
});
t('API : cookie de session sécurisé et effacé à la déconnexion', function () {
    $w = apiWorld(); $api = client($w['app']);
    [, , $c] = $api->call('POST', '/login', ['email' => 'a@club.be', 'password' => PW]);
    eq($c[0]['name'], 'epi_s'); eq($c[0]['secure'], true); eq(strlen($c[0]['value']) >= 32, true);
    Clock::advance(31); $api->call('POST', '/login/verify', ['code' => Totp::code($w['secret'], Totp::step())]);
    $api->csrf = ($api->call('GET', '/me')[1])['csrf'];
    [$s] = $api->call('POST', '/logout'); eq($s, 200); eq($api->cookies, []);
});
t('API : cloisonnement — un membre ne voit pas l’inventaire d’un autre, l’admin non plus', function () {
    $w = apiWorld(); $app = $w['app']; $adm = client($app); $adm->login('a@club.be', PW, $w['secret']);
    $users = [];
    foreach (['b' => 'Bob', 'c' => 'Carl'] as $k => $n) {
        [, $d] = $adm->call('POST', '/admin/users', ['email' => "$k@club.be", 'name' => $n, 'role' => 'member']);
        $tok = basename($d['invite_path']); $anon = client($app);
        [, $st] = $anon->call('POST', '/activate/start', ['token' => $tok]);
        $anon->call('POST', '/activate/finish', ['token' => $tok, 'password' => PW, 'code' => Totp::code($st['secret'], Totp::step())]);
        $users[$k] = $st['secret'];
    }
    $b = client($app, '6.6.6.6'); $b->login('b@club.be', PW, $users['b']);
    $bInv = array_values(array_filter($b->call('GET', '/inventories')[1]['inventories'], fn($i) => $i['kind'] === 'member'))[0]['id'];
    $c = client($app, '7.7.7.7'); $c->login('c@club.be', PW, $users['c']);
    [$s, $d] = $c->call('GET', "/inventories/$bInv/shares"); eq($s, 404); eq($d['error'], 'not_found');
    [$s] = $adm->call('GET', "/inventories/$bInv/shares"); eq($s, 404);
    [$s] = $b->call('GET', "/inventories/$bInv/shares"); eq($s, 200);
    // Bob partage en lecture avec Carl
    $cid = (int)$app->db->val("SELECT id FROM users WHERE email = 'c@club.be'");
    [$s] = $b->call('POST', "/inventories/$bInv/shares", ['user_id' => $cid, 'level' => 'read']); eq($s, 200);
    ok(in_array($bInv, array_column($c->call('GET', '/inventories')[1]['inventories'], 'id')));
    [$s] = $c->call('POST', "/inventories/$bInv/shares", ['user_id' => $cid, 'level' => 'edit']); eq($s, 403);
    [$s] = $b->call('DELETE', "/inventories/$bInv/shares/$cid"); eq($s, 200);
    ok(!in_array($bInv, array_column($c->call('GET', '/inventories')[1]['inventories'], 'id')));
});
t('API : routes admin interdites aux membres, journal réservé aux admins', function () {
    $w = apiWorld(); $app = $w['app']; $adm = client($app); $adm->login('a@club.be', PW, $w['secret']);
    [, $d] = $adm->call('POST', '/admin/users', ['email' => 'b@club.be', 'name' => 'Bob', 'role' => 'member']);
    $tok = basename($d['invite_path']); $x = client($app); [, $st] = $x->call('POST', '/activate/start', ['token' => $tok]);
    $x->call('POST', '/activate/finish', ['token' => $tok, 'password' => PW, 'code' => Totp::code($st['secret'], Totp::step())]);
    $b = client($app, '8.8.8.8'); $b->login('b@club.be', PW, $st['secret']);
    [$s] = $b->call('GET', '/admin/users'); eq($s, 403);
    [$s] = $b->call('GET', '/admin/audit'); eq($s, 403);
    [$s] = $b->call('POST', '/admin/users', ['email' => 'z@club.be', 'name' => 'Z', 'role' => 'admin']); eq($s, 403);
    [$s, $d] = $adm->call('GET', '/admin/audit'); eq($s, 200); ok(count($d['events']) > 0);
    foreach ($d['events'] as $e) ok(!str_contains(json_encode($e), $w['secret']));
});
t('API : verrouillage après trop d’échecs (429)', function () {
    $w = apiWorld(); $api = client($w['app'], '9.9.9.9'); $last = 0;
    for ($i = 0; $i < 7; $i++) [$last] = $api->call('POST', '/login', ['email' => 'a@club.be', 'password' => 'faux-faux-faux-faux']);
    eq($last, 429);
});
t('API : route inconnue → 404, JSON invalide géré par le point d’entrée', function () {
    $w = apiWorld(); $api = client($w['app']); $api->login('a@club.be', PW, $w['secret']);
    [$s, $d] = $api->call('GET', '/nimporte/quoi'); eq($s, 404); eq($d['error'], 'not_found');
});

t('API : changement de rôle, désactivation puis réactivation', function () {
    $w = apiWorld(); $app = $w['app']; $adm = client($app); $adm->login('a@club.be', PW, $w['secret']);
    [, $d] = $adm->call('POST', '/admin/users', ['email' => 'b@club.be', 'name' => 'Bob', 'role' => 'member']); $id = $d['user_id'];
    $adminId = (int)$app->db->val("SELECT id FROM users WHERE email = 'a@club.be'");
    [$s, $e] = $adm->call('POST', "/admin/users/$adminId/role", ['role' => 'member']); eq($s, 409); eq($e['error'], 'last_admin');
    [$s, $e] = $adm->call('POST', "/admin/users/$adminId/disable"); eq($s, 409);
    [$s] = $adm->call('POST', "/admin/users/$id/role", ['role' => 'manager']); eq($s, 200);
    eq($app->db->val('SELECT role FROM users WHERE id = ?', [$id]), 'manager');
    [$s, $e] = $adm->call('POST', "/admin/users/$id/reactivate"); eq($s, 409); eq($e['error'], 'not_disabled');
    [$s] = $adm->call('POST', "/admin/users/$id/disable"); eq($s, 200);
    [$s, $e] = $adm->call('POST', "/admin/users/$id/reactivate"); eq($s, 200); ok(str_contains($e['invite_path'], '/invitation/'));
});
