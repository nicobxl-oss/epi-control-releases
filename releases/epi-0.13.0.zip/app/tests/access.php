<?php
use Epi\{App, Db, Clock, Totp, Crypto, ApiError, Users, Access};
/** Matrice complète : (qui, inventaire) => [view, edit, delete, share] */
t('Matrice des droits : club et inventaires personnels', function () {
    $w = world(); $app = $w['app'];
    $users = ['A' => $w['A'], 'G' => $w['G']['user'], 'm1' => $w['m1']['user'], 'm2' => $w['m2']['user']];
    $exp = [
        // inventaire du club
        'club' => ['A' => [1, 1, 1, 0], 'G' => [1, 1, 1, 0], 'm1' => [1, 0, 0, 0], 'm2' => [1, 0, 0, 0]],
        // inventaire personnel de m1 : seul m1 y a accès ; les admins et responsables n'ont RIEN
        'm1' => ['A' => [0, 0, 0, 0], 'G' => [0, 0, 0, 0], 'm1' => [1, 1, 1, 1], 'm2' => [0, 0, 0, 0]],
        'A' => ['A' => [1, 1, 1, 1], 'G' => [0, 0, 0, 0], 'm1' => [0, 0, 0, 0], 'm2' => [0, 0, 0, 0]],
    ];
    foreach ($exp as $invKey => $rows) {
        $invId = $invKey === 'club' ? $w['club'] : $w['inv'][$invKey];
        foreach ($rows as $who => $want) foreach (Access::ACTIONS as $i => $action)
            eq($app->access->can($users[$who], $invId, $action), (bool)$want[$i], "$who/$invKey/$action");
    }
});
t('Cloisonnement : personne ne voit l\'inventaire personnel d\'un autre (tous contre tous)', function () {
    $w = world(); $app = $w['app'];
    $users = ['A' => $w['A'], 'G' => $w['G']['user'], 'm1' => $w['m1']['user'], 'm2' => $w['m2']['user'], 'm3' => $w['m3']['user']];
    foreach ($users as $who => $u) foreach ($w['inv'] as $owner => $invId) {
        if ($who === $owner) continue;
        eq($app->access->level($u, $invId), 'none', "$who -> inventaire de $owner");
        throws(fn() => $app->access->require($u, $invId, 'view'), 404);
    }
    foreach ($users as $who => $u) { $ids = array_column($app->access->accessible($u), 'id'); eq(count(array_intersect($ids, array_values(array_diff_key($w['inv'], [$who => 1])))), 0, "liste de $who"); }
});
t('Inventaires accessibles : club + le sien (+ partagés)', function () {
    $w = world(); $app = $w['app']; $l = $app->access->accessible($w['m1']['user']);
    eq(array_column($l, 'kind'), ['club', 'member']); eq($l[1]['level'], 'owner'); eq($l[1]['member'], 'M' . str_pad((string)$w['m1']['member_no'], 2, '0', STR_PAD_LEFT));
    $app->access->share($w['m2']['user'], $w['inv']['m2'], $w['m1']['id'], 'read'); eq(count($app->access->accessible($w['m1']['user'])), 3);
});
t('Partage en lecture : le destinataire lit, ne modifie pas', function () {
    $w = world(); $app = $w['app']; $app->access->share($w['m1']['user'], $w['inv']['m1'], $w['m2']['id'], 'read');
    $m2 = $w['m2']['user']; $i = $w['inv']['m1'];
    eq([$app->access->can($m2, $i, 'view'), $app->access->can($m2, $i, 'edit'), $app->access->can($m2, $i, 'delete'), $app->access->can($m2, $i, 'share')], [true, false, false, false]);
    throws(fn() => $app->access->require($m2, $i, 'edit'), 403);
});
t('Partage en écriture : ajoute, modifie et supprime, mais ne repartage pas', function () {
    $w = world(); $app = $w['app']; $app->access->share($w['m1']['user'], $w['inv']['m1'], $w['m2']['id'], 'write');
    $m2 = $w['m2']['user']; $i = $w['inv']['m1'];
    eq([$app->access->can($m2, $i, 'view'), $app->access->can($m2, $i, 'edit'), $app->access->can($m2, $i, 'delete'), $app->access->can($m2, $i, 'share')], [true, true, true, false]);
    throws(fn() => $app->access->share($m2, $i, $w['m3']['id'], 'read'), 403);
    eq($app->access->can($w['m3']['user'], $i, 'view'), false, 'pas de repartage');
});
t('Partage : changer le niveau, puis retirer l\'accès (effet immédiat)', function () {
    $w = world(); $app = $w['app']; $m1 = $w['m1']['user']; $i = $w['inv']['m1'];
    $app->access->share($m1, $i, $w['m2']['id'], 'read'); $app->access->share($m1, $i, $w['m2']['id'], 'write');
    eq($app->access->level($w['m2']['user'], $i), 'write'); eq(count($app->access->shares($m1, $i)), 1);
    $app->access->revoke($m1, $i, $w['m2']['id']); eq($app->access->level($w['m2']['user'], $i), 'none');
    throws(fn() => $app->access->revoke($m1, $i, $w['m2']['id']), 404);
});
t('Partage : le destinataire peut renoncer, un tiers ne peut rien retirer', function () {
    $w = world(); $app = $w['app']; $i = $w['inv']['m1'];
    $app->access->share($w['m1']['user'], $i, $w['m2']['id'], 'read');
    throws(fn() => $app->access->revoke($w['m3']['user'], $i, $w['m2']['id']), 404);
    throws(fn() => $app->access->shares($w['m2']['user'], $i), 403, 'forbidden');
    $app->access->revoke($w['m2']['user'], $i, $w['m2']['id']); eq($app->access->level($w['m2']['user'], $i), 'none');
});
t('Partage : refus pour soi-même, niveau invalide, compte inconnu/désactivé, inventaire du club ou d\'autrui', function () {
    $w = world(); $app = $w['app']; $m1 = $w['m1']['user']; $i = $w['inv']['m1'];
    throws(fn() => $app->access->share($m1, $i, $w['m1']['id'], 'read'), 422, 'cannot_share_with_self');
    throws(fn() => $app->access->share($m1, $i, $w['m2']['id'], 'admin'), 422, 'invalid_level');
    throws(fn() => $app->access->share($m1, $i, 9999, 'read'), 404);
    $app->users->disable($w['A'], $w['m3']['id']); throws(fn() => $app->access->share($m1, $i, $w['m3']['id'], 'read'), 404);
    throws(fn() => $app->access->share($w['A'], $w['club'], $w['m2']['id'], 'read'), 403);
    throws(fn() => $app->access->share($w['m2']['user'], $i, $w['m3']['id'], 'read'), 404, 'not_found');
    throws(fn() => $app->access->share($w['A'], $i, $w['m2']['id'], 'read'), 404, 'not_found');
});
t('Un compte désactivé n\'a plus aucun droit, même sur le club', function () {
    $w = world(); $app = $w['app']; $u = ['status' => 'disabled'] + $w['G']['user'];
    foreach (Access::ACTIONS as $a) eq($app->access->can($u, $w['club'], $a), false, $a);
});
t('Rétrograder un responsable lui retire l\'écriture sur le club immédiatement', function () {
    $w = world(); $app = $w['app']; eq($app->access->can($w['G']['user'], $w['club'], 'edit'), true);
    $app->users->setRole($w['A'], $w['G']['id'], 'member');
    $g = $app->db->one('SELECT id, email, name, member_no, role, status FROM users WHERE id = ?', [$w['G']['id']]);
    eq($app->access->can($g, $w['club'], 'edit'), false); eq($app->access->can($g, $w['club'], 'view'), true);
});
t('Action inconnue refusée', function () { $w = world(); eq($w['app']->access->can($w['A'], $w['club'], 'drop_database'), false); });
