<?php
declare(strict_types=1);

use Epi\{Report, Pdf};

/** Famille de test : bobine COR-0001 (100 m) coupée en 3, un morceau recoupé, un morceau perdu, un déclassé ; plus une corde seule déclassée. */
function ropeFamily(array $w): array
{
    $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'Antidote 10,5', 'etat' => 'En service', 'longueur' => 100, 'fab' => '2024-03-01', 'mes' => '2024-06-15', 'ctrl' => '2025-01-10', 'vieUtil' => 5, 'vieTotale' => 10]));
    $r = $reg->cut($g, $b['uid'], [30, 25, 10], ['mes' => '2024-07-01', 'etat' => 'En service']);   // COR-0002/3/4
    $r2 = $reg->cut($g, $r['made'][0], [12, 8], ['etat' => 'Stock']);                                // petits-enfants COR-0005/6
    $reg->update($g, $r['made'][1], ['etat' => 'Perdu']);
    $reg->update($g, $r2['made'][1], ['etat' => 'Déclassé']);
    $solo = $reg->create($g, $c, basic(['type' => 'Corde', 'marque' => 'Petzl', 'modele' => 'Club', 'etat' => 'Déclassé', 'longueur' => 40]));
    $other = $reg->create($g, $c, basic(['type' => 'Corde', 'marque' => 'Edelrid', 'modele' => 'Tower', 'etat' => 'Stock', 'longueur' => 60]));
    return ['root' => $b['uid'], 'kids' => $r['made'], 'grand' => $r2['made'], 'solo' => $solo['uid'], 'other' => $other['uid']];
}
function uidsOf(array $fams): array { $o = []; $f = function (array $n) use (&$f, &$o) { $o[] = $n['it']['uid']; foreach ($n['kids'] as $k) $f($k); }; foreach ($fams as $x) $f($x); return $o; }

t('État des lieux des cordes : familles, filtres (un arbre apparaît dès qu’une de ses cordes correspond, et on le voit en entier)', function () {
    $w = world(); $f = ropeFamily($w); $app = $w['app']; $rep = new Report($app->db, $app->registry);
    $items = $app->registry->snapshot($w['G']['user'], $w['club'])['items'];
    $all = $rep->families($items, 'all');
    eq(count($all), 3, 'trois familles (bobine, corde déclassée, corde en stock)');
    eq($all[0]['it']['uid'], $f['root']); eq(count($all[0]['kids']), 3); eq(count($all[0]['kids'][0]['kids']), 2, 'petits-enfants sous leur parent');
    eq(uidsOf([$all[0]]), array_merge([$f['root']], [$f['kids'][0]], $f['grand'], [$f['kids'][1], $f['kids'][2]]), 'ordre : parent, enfants, petits-enfants');
    // en stock / en service : la famille de la bobine (en service) apparaît en entier, avec le perdu et le déclassé ; la corde seule déclassée disparaît
    $svc = $rep->families($items, 'service'); eq(array_map(fn($n) => $n['it']['uid'], $svc), [$f['root'], $f['other']]);
    eq(count(uidsOf([$svc[0]])), 6, 'toute la famille, y compris perdu et déclassé');
    // déclassées : la corde seule, et la famille qui contient un déclassé
    $dec = $rep->families($items, 'declasse'); eq(array_map(fn($n) => $n['it']['uid'], $dec), [$f['root'], $f['solo']]);
    // métrages : en service = bobine restante 35 + 10 + 10 = 55 ; en stock = 12 + 60 = 72 ; le perdu (25) et les déclassés (8, 40) ne comptent pas
    eq($rep->metres($all), ['stock' => 72.0, 'service' => 55.0], 'métrage en stock et en service, séparés');
    eq($rep->metres($rep->families($items, 'declasse')), ['stock' => 12.0, 'service' => 55.0], 'déclassées : seule la famille de la bobine compte');
    // une bobine épuisée dont les morceaux sont en service apparaît dans « en service »
    $reg = $app->registry; $g = $w['G']['user'];
    $b = $reg->create($g, $w['club'], basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 20])); $reg->cut($g, $b['uid'], [20], ['etat' => 'En service']);
    $items = $reg->snapshot($g, $w['club'])['items']; eq($reg->snapshot($g, $w['club'])['items'][array_search($b['uid'], array_column($items, 'uid'))]['etat'], 'Épuisé');
    ok(in_array($b['uid'], array_map(fn($n) => $n['it']['uid'], $rep->families($items, 'service')), true), 'bobine épuisée, morceau en service : famille présente');
    // sangles et autres types : jamais dans le rapport
    $reg->create($g, $w['club'], basic(['type' => 'Sangle', 'longueur' => 5]));
    ok(!in_array('SAN-0001', uidsOf($rep->families($reg->snapshot($g, $w['club'])['items'], 'all')), true), 'pas de sangle');
});
t('État des lieux des cordes : PDF valide, droits, filtre inconnu, rapport vide', function () {
    $w = world(); $f = ropeFamily($w); $app = $w['app']; $rep = new Report($app->db, $app->registry);
    $r = $rep->ropes($w['G']['user'], $w['club'], 'all', '9.9.9');
    eq($r['mime'], 'application/pdf'); ok(str_starts_with($r['content'], '%PDF-1.4'), 'en-tête PDF'); ok(str_ends_with(rtrim($r['content']), '%%EOF'), 'fin PDF');
    ok(preg_match('/^etat-des-lieux-cordes-\d{4}-\d{2}-\d{2}\.pdf$/', $r['name']) === 1, 'nom de fichier');
    ok(preg_match('/\/Count (\d+)/', $r['content'], $m) && (int)$m[1] >= 1, 'au moins une page');
    // un membre simple peut lire le registre du club, donc éditer le rapport ; la liste personnelle d'un autre reste fermée
    $rep->ropes($w['m1']['user'], $w['club'], 'all');
    try { $rep->ropes($w['m2']['user'], $w['inv']['G'], 'all'); throw new Exception('accès à la liste d\'un autre'); } catch (Epi\ApiError $e) { ok(in_array($e->status, [403, 404], true), 'refusé sans droit'); }
    throws(fn() => $rep->ropes($w['G']['user'], $w['club'], 'tout'), 422, 'invalid_filter');
    // inventaire sans corde
    $empty = $rep->ropes($w['G']['user'], $w['inv']['G'], 'all'); ok(str_starts_with($empty['content'], '%PDF'), 'rapport vide quand même valide');
    // beaucoup de familles : plusieurs pages
    $reg = $app->registry;
    for ($i = 0; $i < 70; $i++) { $b = $reg->create($w['G']['user'], $w['club'], basic(['type' => 'Corde', 'etat' => 'En service', 'longueur' => 30, 'marque' => 'Petzl', 'modele' => 'Modèle ' . $i])); }
    $big = $rep->ropes($w['G']['user'], $w['club'], 'all'); preg_match('/\/Count (\d+)/', $big['content'], $m2); ok((int)$m2[1] >= 2, 'plusieurs pages (' . $m2[1] . ')');
    if (($p = getenv('EPI_PDF_SAMPLE'))) { file_put_contents($p . '/echantillon-complet.pdf', $big['content']); file_put_contents($p . '/echantillon-petit.pdf', $r['content']); file_put_contents($p . '/echantillon-vide.pdf', $empty['content']);
        $svc = $rep->ropes($w['G']['user'], $w['club'], 'declasse', '9.9.9'); file_put_contents($p . '/echantillon-declasse.pdf', $svc['content']); }
});
t('Générateur PDF : accents, parenthèses, texte long raccourci', function () {
    $p = new Pdf(); ok($p->width('Hello', 10) > 20 && $p->width('Hello', 10) < 40);
    eq(Pdf::enc("é à ç’ (x)"), mb_convert_encoding("é à ç' (x)", 'Windows-1252', 'UTF-8'));
    $long = str_repeat('Marque très longue ', 10); $s = $p->fit($long, 100, 8); ok($p->width($s, 8) <= 100 && str_ends_with($s, '...'));
    eq($p->fit('court', 100, 8), 'court');
    $p->text(10, 20, 'Test (parenthèses) \\ ok'); $out = $p->output(); ok(str_starts_with($out, '%PDF') && str_contains($out, 'startxref'));
});
