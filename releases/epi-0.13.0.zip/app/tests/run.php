<?php
declare(strict_types=1);
// Lancer : php tests/run.php   (SQLite en mémoire, aucune installation requise)
require __DIR__ . '/../src/bootstrap.php';
require __DIR__ . '/lib.php';
require __DIR__ . '/security.php';
require __DIR__ . '/accounts.php';
require __DIR__ . '/access.php';
require __DIR__ . '/api.php';
require __DIR__ . '/registry.php';
require __DIR__ . '/files.php';
require __DIR__ . '/report.php';
require __DIR__ . '/updater.php';
// ménage des dossiers de stockage de test
foreach ($GLOBALS['STORAGE_DIRS'] ?? [] as $d) if (is_dir($d)) { foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); } @rmdir($d); }
echo "\n$pass réussis, $fail échec(s)\n";
exit($fail ? 1 : 0);
