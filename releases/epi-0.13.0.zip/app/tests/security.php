<?php
use Epi\{App, Db, Clock, Totp, Crypto, ApiError, Users, Access};
// RFC 6238 (annexe B) : secret ASCII « 12345678901234567890 », SHA-1, 8 chiffres.
t('TOTP : vecteurs de test RFC 6238', function () {
    $s = Totp::b32encode('12345678901234567890');
    foreach ([59 => '94287082', 1111111109 => '07081804', 1111111111 => '14050471', 1234567890 => '89005924', 2000000000 => '69279037', 20000000000 => '65353130'] as $time => $exp)
        eq(Totp::code($s, intdiv($time, 30), 8), $exp, "t=$time");
});
t('TOTP : base32 aller-retour', function () { $b = random_bytes(20); eq(Totp::b32decode(Totp::b32encode($b)), $b); });
t('TOTP : tolérance ±1 pas, pas au-delà', function () {
    Clock::$fixed = 1_800_000_000; $s = Totp::newSecret(); $n = Totp::step();
    ok(Totp::verify($s, Totp::code($s, $n - 1)) === $n - 1); ok(Totp::verify($s, Totp::code($s, $n + 1)) === $n + 1);
    eq(Totp::verify($s, Totp::code($s, $n - 2)), null); eq(Totp::verify($s, Totp::code($s, $n + 2)), null);
});
t('TOTP : un code déjà utilisé est refusé (anti-rejeu)', function () {
    Clock::$fixed = 1_800_000_000; $s = Totp::newSecret(); $n = Totp::step();
    $step = Totp::verify($s, Totp::code($s, $n)); ok($step !== null);
    eq(Totp::verify($s, Totp::code($s, $n), $step), null);
});
t('TOTP : formats invalides refusés', function () {
    $s = Totp::newSecret(); foreach (['', 'abcdef', '12345', '1234567'] as $c) eq(Totp::verify($s, $c), null, $c);
});
t('Chiffrement du secret : aller-retour, falsification détectée, mauvaise clé', function () {
    $c = new Crypto(base64_encode(random_bytes(32))); $e = $c->encrypt('SECRET');
    eq($c->decrypt($e), 'SECRET'); ok($e !== $c->encrypt('SECRET'), 'nonce différent');
    $raw = base64_decode($e); $raw[strlen($raw) - 1] = $raw[strlen($raw) - 1] ^ "\x01";
    eq($c->decrypt(base64_encode($raw)), null);
    eq((new Crypto(base64_encode(random_bytes(32))))->decrypt($e), null);
});
t('Clé applicative trop courte refusée', function () { try { new Crypto(base64_encode('court')); } catch (RuntimeException) { return; } throw new Exception('acceptée'); });
t('Mot de passe : Argon2id, vérification', function () {
    $c = new Crypto(base64_encode(random_bytes(32))); $h = $c->hashPassword('un mot de passe long');
    ok(str_starts_with($h, '$argon2id$')); ok($c->verifyPassword('un mot de passe long', $h)); ok(!$c->verifyPassword('autre', $h));
});
t('Politique de mot de passe', function () {
    throws(fn() => Users::checkPassword('court', 'a@b.be'), 422, 'password_too_short');
    throws(fn() => Users::checkPassword('aaaaaaaaaaaaaaaa', 'a@b.be'), 422, 'password_too_weak');
    throws(fn() => Users::checkPassword('Jean@Club.be', 'jean@club.be'), 422, 'password_too_weak');
    Users::checkPassword('une phrase de passe correcte', 'a@b.be');
});
t('Codes de secours : 10 codes distincts au bon format', function () {
    $c = Crypto::recoveryCodes(); eq(count($c), 10); eq(count(array_unique($c)), 10);
    foreach ($c as $x) ok(preg_match('/^[a-z2-9]{5}-[a-z2-9]{5}$/', $x) === 1, $x);
});
