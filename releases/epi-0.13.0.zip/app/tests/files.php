<?php
use Epi\{Clock, ApiError, Api};

/** Petits fichiers valides (en-têtes reconnus) mais de contenu distinct. */
function fakeJpg(string $tag = 'a', int $pad = 200): string { return "\xFF\xD8\xFF\xE0" . str_repeat($tag, $pad); }
function fakePdf(string $tag = 'a', int $pad = 200): string { return "%PDF-1.4\n" . str_repeat($tag, $pad); }
/** Vraie image PNG (GD) de couleur déterminée par $tag. */
function realPng(int $w, int $h, string $tag): string
{
    if (!function_exists('imagecreatetruecolor')) return "\xFF\xD8\xFF\xE0" . str_repeat($tag, 300 + $w);   // sans GD : faux JPEG distinct
    $im = imagecreatetruecolor($w, $h); $c = crc32($tag); imagefill($im, 0, 0, imagecolorallocate($im, $c & 255, ($c >> 8) & 255, ($c >> 16) & 255));
    imagefilledrectangle($im, (int)($w / 4), (int)($h / 4), (int)($w * 3 / 4), (int)($h * 3 / 4), imagecolorallocate($im, 255, 255, 255));
    ob_start(); imagepng($im); return (string)ob_get_clean();
}
function fitem(array $w, string $who = 'G', array $o = []): array
{
    $inv = $who === 'G' ? $w['club'] : $w['inv'][$who];
    return $w['app']->registry->create($w[$who]['user'] ?? $w['A'], $inv, $o + ['type' => 'Mousqueton', 'marque' => 'Petzl', 'modele' => 'Am’D', 'etat' => 'Stock']);
}

t('Fichiers : ajout d\'une photo, lecture, contenu relu à l\'identique', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $it = fitem($w);
    $r = $f->add($g, $it['uid'], 'photo', 'am.jpg', fakeJpg());
    eq($r['dedup'], false); eq(count($r['list']['files']), 1); eq($r['list']['files'][0]['kind'], 'photo');
    $o = $f->open($g, $it['uid'], $r['id']); eq(file_get_contents($o['path']), fakeJpg()); eq($o['mime'], 'image/jpeg');
    ok(is_file(dirname($o['path'], 3) . '/.htaccess'), 'dossier protégé par .htaccess');
});
t('Fichiers : contenu inconnu, mauvais type et fichier vide refusés', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $it = fitem($w);
    throws(fn() => $f->add($g, $it['uid'], 'photo', 'x.jpg', 'ceci n\'est pas une image'), 415, 'image_required');
    throws(fn() => $f->add($g, $it['uid'], 'fiche', 'x.pdf', fakeJpg()), 415, 'pdf_required');
    throws(fn() => $f->add($g, $it['uid'], 'photo', 'x.jpg', ''), 422, 'empty_file');
    throws(fn() => $f->add($g, $it['uid'], 'machin', 'x.pdf', fakePdf()), 422, 'invalid_kind');
    $f->add($g, $it['uid'], 'facture', 'f.jpg', fakeJpg('f'));   // une facture peut être une photo
});
t('Fichiers : le même fichier n\'est stocké qu\'une fois (liens multiples, taille comptée une fois)', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w); $b = fitem($w);
    $f->add($g, $a['uid'], 'fiche', 'fiche.pdf', fakePdf('z'));
    $r = $f->add($g, $b['uid'], 'fiche', 'autre-nom.pdf', fakePdf('z'));
    eq($r['dedup'], true); eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 1); eq($f->used(), strlen(fakePdf('z')));
    eq($r['list']['files'][0]['shared'], 2);
    throws(fn() => $f->add($g, $b['uid'], 'fiche', 'encore.pdf', fakePdf('z')), 409, 'already_attached');
});
t('Fichiers : club et inventaire personnel ne partagent jamais un fichier', function () {
    $w = world(); $f = $w['app']->files; $club = fitem($w); $mine = fitem($w, 'm1');
    $f->add($w['G']['user'], $club['uid'], 'fiche', 'f.pdf', fakePdf('q'));
    $f->add($w['m1']['user'], $mine['uid'], 'fiche', 'f.pdf', fakePdf('q'));
    eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 2);
});
t('Fichiers : suppression d\'un lien — le fichier reste tant qu\'un équipement l\'utilise, puis disparaît du disque', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w); $b = fitem($w);
    $ra = $f->add($g, $a['uid'], 'manuel', 'm.pdf', fakePdf('m')); $rb = $f->add($g, $b['uid'], 'manuel', 'm.pdf', fakePdf('m'));
    $path = $f->open($g, $a['uid'], $ra['id'])['path'];
    $f->remove($g, $a['uid'], $ra['id']); ok(is_file($path), 'encore utilisé par B'); eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 1);
    $f->remove($g, $b['uid'], $rb['id']); ok(!is_file($path), 'effacé du disque'); eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 0); eq($f->used(), 0);
});
t('Fichiers : supprimer un équipement libère ses documents', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w);
    $r = $f->add($g, $a['uid'], 'photo', 'p.jpg', fakeJpg('p')); $path = $f->open($g, $a['uid'], $r['id'])['path'];
    $w['app']->registry->delete($g, $a['uid']); ok(!is_file($path)); eq($w['app']->db->val('SELECT COUNT(*) FROM item_files'), 0); eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 0);
});
t('Fichiers : limites par type de document', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w);
    for ($i = 0; $i < 6; $i++) $f->add($g, $a['uid'], 'photo', "p$i.jpg", fakeJpg((string)$i));
    throws(fn() => $f->add($g, $a['uid'], 'photo', 'p7.jpg', fakeJpg('x')), 409, 'too_many_files');
    for ($i = 0; $i < 3; $i++) $f->add($g, $a['uid'], 'facture', "f$i.pdf", fakePdf((string)$i));
    throws(fn() => $f->add($g, $a['uid'], 'facture', 'f4.pdf', fakePdf('x')), 409, 'too_many_files');
});
t('Fichiers : taille maximale (image 8 Mo, PDF 20 Mo)', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w);
    throws(fn() => $f->add($g, $a['uid'], 'photo', 'g.jpg', fakeJpg('a', 8 * 1024 * 1024 + 1)), 413, 'file_too_big');
    throws(fn() => $f->add($g, $a['uid'], 'fiche', 'g.pdf', fakePdf('a', 20 * 1024 * 1024 + 1)), 413, 'file_too_big');
});
t('Fichiers : plafond d\'espace — refus à 100 %, alerte à 80 %', function () {
    $w = world(); $cfg = $w['app']->config; $cfg['storage_cap'] = 1000;
    $f = new Epi\Files($w['app']->db, $w['app']->access, $w['app']->audit, $cfg); $g = $w['G']['user']; $a = fitem($w);
    eq($f->usage($g)['warn'], false);
    $f->add($g, $a['uid'], 'photo', 'a.jpg', fakeJpg('a', 800 - 4));   // 800 octets = 80 %
    $u = $f->usage($g); eq($u['used'], 800); eq($u['pct'], 80.0); eq($u['warn'], true);
    throws(fn() => $f->add($g, $a['uid'], 'photo', 'b.jpg', fakeJpg('b', 300)), 507, 'storage_full');
    eq($f->used(), 800, 'rien n\'a été écrit');
    throws(fn() => $f->usage($w['m1']['user']), 403);
});
t('Fichiers : droits — le club se lit pour tous, s\'écrit pour responsables et admins ; factures cachées aux membres', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w);
    $ph = $f->add($g, $a['uid'], 'photo', 'p.jpg', fakeJpg('p')); $fa = $f->add($g, $a['uid'], 'facture', 'f.pdf', fakePdf('f'));
    $m = $w['m1']['user'];
    $l = $f->list($m, $a['uid']); eq(array_column($l['files'], 'kind'), ['photo']); eq($l['can']['edit'], false);
    ok(is_file($f->open($m, $a['uid'], $ph['id'])['path']));
    throws(fn() => $f->open($m, $a['uid'], $fa['id']), 403);
    throws(fn() => $f->add($m, $a['uid'], 'photo', 'x.jpg', fakeJpg('x')), 403);
    throws(fn() => $f->remove($m, $a['uid'], $ph['id']), 403);
    eq(array_column($f->list($g, $a['uid'])['files'], 'kind'), ['facture', 'photo']);
    eq($w['app']->registry->snapshot($m, $w['club'])['docs'][$a['uid']], 1, 'la liste ne compte pas les factures pour un membre');
    eq($w['app']->registry->snapshot($g, $w['club'])['docs'][$a['uid']], 2);
});
t('Fichiers : matériel perso — jamais accessible à l\'admin ; partage en lecture sans factures, en écriture avec', function () {
    $w = world(); $f = $w['app']->files; $m1 = $w['m1']['user']; $a = fitem($w, 'm1');
    $ph = $f->add($m1, $a['uid'], 'photo', 'p.jpg', fakeJpg('p')); $fa = $f->add($m1, $a['uid'], 'facture', 'f.pdf', fakePdf('f'));
    throws(fn() => $f->list($w['A'], $a['uid']), 404); throws(fn() => $f->open($w['A'], $a['uid'], $ph['id']), 404);
    $w['app']->access->share($m1, $w['inv']['m1'], (int)$w['m2']['id'], 'read');
    eq(array_column($f->list($w['m2']['user'], $a['uid'])['files'], 'kind'), ['photo']);
    throws(fn() => $f->open($w['m2']['user'], $a['uid'], $fa['id']), 403);
    $w['app']->access->share($m1, $w['inv']['m1'], (int)$w['m2']['id'], 'write');
    eq(array_column($f->list($w['m2']['user'], $a['uid'])['files'], 'kind'), ['facture', 'photo']);
    throws(fn() => $f->list($w['m3']['user'], $a['uid']), 404);
});
t('Fichiers : un document ne s\'ouvre que par l\'équipement auquel il est rattaché', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w); $b = fitem($w);
    $r = $f->add($g, $a['uid'], 'photo', 'p.jpg', fakeJpg('p'));
    throws(fn() => $f->open($g, $b['uid'], $r['id']), 404); throws(fn() => $f->remove($g, $b['uid'], $r['id']), 404);
});
t('Fichiers : les morceaux voient les documents de leur bobine (lecture seule)', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user'];
    $b = $w['app']->registry->create($g, $w['club'], ['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'Opera', 'etat' => 'Stock', 'longueur' => '50']);
    $r = $f->add($g, $b['uid'], 'facture', 'f.pdf', fakePdf('f'));
    $cut = $w['app']->registry->cut($g, $b['uid'], ['10'], []); $p = $cut['made'][0] ?? null; ok($p, 'morceau créé');
    $l = $f->list($g, $p); eq(count($l['files']), 1); eq($l['files'][0]['from'], $b['uid']);
    ok(is_file($f->open($g, $p, $r['id'])['path']));
    throws(fn() => $f->remove($g, $p, $r['id']), 404);
});
t('Fichiers : « même modèle » rattache la fiche aux équipements identiques seulement', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user'];
    $a = fitem($w); $b = fitem($w); $c = fitem($w, 'G', ['modele' => 'Autre']);
    $r = $f->add($g, $a['uid'], 'fiche', 'fiche.pdf', fakePdf('s'), true);
    eq($r['also'], 1); eq($w['app']->db->val('SELECT COUNT(*) FROM files'), 1);
    eq(count($f->list($g, $b['uid'])['files']), 1); eq(count($f->list($g, $c['uid'])['files']), 0);
    $d = fitem($w); $r2 = $f->add($g, $d['uid'], 'photo', 'p.jpg', fakeJpg('p'), true); eq($r2['also'], 0, 'la photo reste propre à l\'équipement');
});
t('Fichiers : actions du club journalisées, jamais celles du matériel perso', function () {
    $w = world(); $f = $w['app']->files; $a = fitem($w); $b = fitem($w, 'm1');
    $r = $f->add($w['G']['user'], $a['uid'], 'photo', 'p.jpg', fakeJpg('p')); $f->remove($w['G']['user'], $a['uid'], $r['id']);
    $f->add($w['m1']['user'], $b['uid'], 'photo', 'p.jpg', fakeJpg('p'));
    eq($w['app']->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'item.file_add'"), 1); eq($w['app']->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'item.file_remove'"), 1);
});
t('Fichiers : dossier lisible depuis Internet → envoi refusé', function () {
    $w = world(); $cfg = $w['app']->config; $cfg['storage_probe_fn'] = fn() => 'open';
    $f = new Epi\Files($w['app']->db, $w['app']->access, $w['app']->audit, $cfg); $a = fitem($w);
    throws(fn() => $f->add($w['G']['user'], $a['uid'], 'photo', 'p.jpg', fakeJpg('p')), 503, 'storage_unprotected');
});
t('Fichiers : nom nettoyé (chemin, caractères de contrôle)', function () {
    $w = world(); $f = $w['app']->files; $a = fitem($w);
    $r = $f->add($w['G']['user'], $a['uid'], 'photo', "../../etc/pass\x00wd<b>.jpg", fakeJpg('n'));
    ok(!str_contains($r['list']['files'][0]['name'], '/') && !str_contains($r['list']['files'][0]['name'], '<'), $r['list']['files'][0]['name']);
});
t('Fichiers (API) : envoi brut, liste, ouverture (_file), suppression, CSRF obligatoire', function () {
    $w = world(); $app = $w['app']; $api = new Api($app); $a = fitem($w);
    $lg = loginFull($app, $w['G']); $ck = [Api::COOKIE => $lg['token']]; $csrf = (string)$app->db->val('SELECT csrf FROM sessions LIMIT 1');
    $h = ['X-CSRF-Token' => $csrf];
    [$st, $d] = $api->handle('POST', '/items/' . $a['uid'] . '/files', [], $ck, [], '1.1.1.1', fakeJpg('w'), ['kind' => 'photo', 'name' => 'a.jpg']); eq($st, 403, 'sans CSRF');
    [$st, $d] = $api->handle('POST', '/items/' . $a['uid'] . '/files', [], $ck, $h, '1.1.1.1', fakeJpg('w'), ['kind' => 'photo', 'name' => 'a.jpg']); eq($st, 201); $id = $d['id'];
    [$st, $d] = $api->handle('GET', '/items/' . $a['uid'] . '/files', [], $ck, [], '1.1.1.1'); eq($st, 200); eq(count($d['files']), 1);
    [$st, $d] = $api->handle('GET', '/items/' . $a['uid'] . '/files/' . $id, [], $ck, [], '1.1.1.1'); eq($st, 200); eq($d['_file']['mime'], 'image/jpeg');
    [$st, $d] = $api->handle('GET', '/storage', [], $ck, [], '1.1.1.1'); eq($st, 200); eq($d['files'], 1);
    [$st, $d] = $api->handle('DELETE', '/items/' . $a['uid'] . '/files/' . $id, [], $ck, $h, '1.1.1.1'); eq($st, 200); eq(count($d['files']), 0);
    [$st] = $api->handle('GET', '/items/' . $a['uid'] . '/files', [], [], [], '1.1.1.1'); eq($st, 401);
});
t('Photos : photo principale — la plus ancienne par défaut, modifiable ; vignette fabriquée', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $a = fitem($w);
    $p1 = $f->add($g, $a['uid'], 'photo', '1.png', realPng(900, 600, 'r')); $p2 = $f->add($g, $a['uid'], 'photo', '2.png', realPng(900, 600, 'b'));
    eq($w['app']->registry->snapshot($g, $w['club'])['photos'][$a['uid']], $p1['id'], 'défaut : la première');
    $l = $f->list($g, $a['uid'])['files']; eq(array_column(array_filter($l, fn($x) => $x['main']), 'id'), [$p1['id']]);
    $f->setMain($g, $a['uid'], $p2['id']);
    eq($w['app']->registry->snapshot($g, $w['club'])['photos'][$a['uid']], $p2['id']);
    eq(array_values(array_column(array_filter($f->list($g, $a['uid'])['files'], fn($x) => $x['main']), 'id')), [$p2['id']]);
    if (function_exists('imagecreatefromstring')) {
        $th = $f->open($g, $a['uid'], $p1['id'], true); ok(str_ends_with($th['path'], '.t'), 'vignette'); ok($th['size'] < filesize($f->open($g, $a['uid'], $p1['id'])['path']), 'vignette plus légère');
        [$tw, $tH] = getimagesize($th['path']); ok(max($tw, $tH) <= 320, "$tw x $tH");
        $f->remove($g, $a['uid'], $p1['id']); ok(!is_file($th['path']), 'vignette effacée avec le fichier');
    }
    throws(fn() => $f->setMain($w['m1']['user'], $a['uid'], $p2['id']), 403);
});
t('Photos : un morceau sans photo reprend celle de sa bobine pour la liste', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user'];
    $b = $w['app']->registry->create($g, $w['club'], ['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'Opera', 'etat' => 'Stock', 'longueur' => '50']);
    $r = $f->add($g, $b['uid'], 'photo', 'p.png', realPng(300, 300, 'g'));
    $m = $w['app']->registry->cut($g, $b['uid'], ['10', '5'], [])['made']; $ph = $w['app']->registry->snapshot($g, $w['club'])['photos'];
    eq($ph[$b['uid']], $r['id']); eq($ph[$m[0]], $r['id']); eq($ph[$m[1]], $r['id']);
    $own = $f->add($g, $m[1], 'photo', 'q.png', realPng(300, 300, 'y')); eq($w['app']->registry->snapshot($g, $w['club'])['photos'][$m[1]], $own['id']);
});
t('Photos (API) : vignette via ?thumb=1 et route « main »', function () {
    $w = world(); $app = $w['app']; $api = new Api($app); $a = fitem($w);
    $lg = loginFull($app, $w['G']); $ck = [Api::COOKIE => $lg['token']]; $h = ['X-CSRF-Token' => (string)$app->db->val('SELECT csrf FROM sessions LIMIT 1')];
    [, $d] = $api->handle('POST', '/items/' . $a['uid'] . '/files', [], $ck, $h, '1.1.1.1', realPng(800, 800, 'a'), ['kind' => 'photo', 'name' => 'a.png']); $id = $d['id'];
    [, $d2] = $api->handle('POST', '/items/' . $a['uid'] . '/files', [], $ck, $h, '1.1.1.1', realPng(800, 800, 'z'), ['kind' => 'photo', 'name' => 'b.png']);
    [$st, $x] = $api->handle('GET', '/items/' . $a['uid'] . '/files/' . $id, [], $ck, [], '1.1.1.1', null, ['thumb' => '1']); eq($st, 200);
    [$st, $y] = $api->handle('POST', '/items/' . $a['uid'] . '/files/' . $d2['id'] . '/main', [], $ck, $h, '1.1.1.1'); eq($st, 200);
    eq(array_values(array_column(array_filter($y['files'], fn($f) => $f['main']), 'id')), [$d2['id']]);
    [$st] = $api->handle('POST', '/items/' . $a['uid'] . '/files/' . $d2['id'] . '/main', [], $ck, [], '1.1.1.1'); eq($st, 403, 'CSRF');
});
t('Duplication : copies avec leurs lots/séries, documents partagés, tout ou rien, droits', function () {
    $w = world(); $f = $w['app']->files; $g = $w['G']['user']; $r = $w['app']->registry;
    $a = $r->create($g, $w['club'], ['type' => 'Mousqueton', 'marque' => 'Petzl', 'modele' => 'Attache', 'etat' => 'Stock', 'fournisseur' => 'Decath', 'achat' => '2026-10-01', 'prix' => '12,5', 'remarque' => 'lot commande', 'lot' => 'ORIG1']);
    $p = $f->add($g, $a['uid'], 'photo', 'p.png', realPng(300, 300, 'g')); $f->add($g, $a['uid'], 'facture', 'f.pdf', "%PDF-1.4\n%x\n");
    $res = $r->duplicate($g, $a['uid'], ['S1', 'S2', '']);
    eq(count($res['items']), 3); $u = array_column($res['items'], 'uid'); eq(count(array_unique($u)), 3); ok(!in_array($a['uid'], $u));
    eq(array_column($res['items'], 'lot'), ['S1', 'S2', '']);
    foreach ($res['items'] as $c) { eq($c['marque'], 'Petzl'); eq($c['modele'], 'Attache'); eq($c['fournisseur'], 'Decath'); eq($c['achat'], '2026-10-01'); eq($c['prix'], 12.5); eq($c['remarque'], 'lot commande'); eq($c['etat'], 'Stock'); ok(empty($c['parent'])); }
    foreach ($u as $x) { $l = $f->list($g, $x)['files']; eq(count($l), 2, 'documents suivent'); }
    $fid = (int)$w['app']->db->val('SELECT COUNT(*) FROM files'); eq($fid, 2, 'aucun fichier recopié');
    $f->remove($g, $u[0], $f->list($g, $u[0])['files'][0]['id']); ok(count($f->list($g, $a['uid'])['files']) === 2, 'l\'original garde ses fichiers');
    // tout ou rien : doublon dans la liste, ou déjà au registre
    $n = (int)$w['app']->db->val('SELECT COUNT(*) FROM items');
    try { $r->duplicate($g, $a['uid'], ['Z1', 'Z1']); ok(false); } catch (\Epi\ApiError $e) { eq($e->errorCode, 'duplicate_lot'); eq($e->extra['index'], 1); }
    try { $r->duplicate($g, $a['uid'], ['Y1', 'S1']); ok(false); } catch (\Epi\ApiError $e) { eq($e->errorCode, 'duplicate_lot'); eq($e->extra['index'], 1); }
    eq((int)$w['app']->db->val('SELECT COUNT(*) FROM items'), $n, 'rien créé');
    throws(fn() => $r->duplicate($g, $a['uid'], []), 422, 'invalid_count'); throws(fn() => $r->duplicate($g, $a['uid'], array_fill(0, 51, '')), 422, 'invalid_count');
    throws(fn() => $r->duplicate($w['m1']['user'], $a['uid'], ['']), 403);
});
