<?php
declare(strict_types=1);

use Epi\{App, Db, Clock, Totp, Crypto, ApiError, Users, Access};

$GLOBALS['pass'] = $GLOBALS['fail'] = 0;
function t(string $name, callable $fn): void
{
    global $pass, $fail;
    try { $fn(); $pass++; echo "ok   $name\n"; }
    catch (Throwable $e) { $fail++; echo "FAIL $name : " . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ")\n"; }
}
function eq($a, $b, string $m = ''): void { if ($a !== $b) throw new Exception(($m ? "$m : " : '') . 'attendu ' . var_export($b, true) . ', obtenu ' . var_export($a, true)); }
function ok($c, string $m = ''): void { if (!$c) throw new Exception($m ?: 'condition fausse'); }
function throws(callable $fn, int $status, string $code = ''): void
{
    try { $fn(); } catch (ApiError $e) { eq($e->status, $status, 'statut'); if ($code !== '') eq($e->errorCode, $code, 'code'); return; }
    throw new Exception("ApiError $status attendue");
}

const TEST_CFG = ['issuer' => 'Test', 'mail_transport' => 'memory', 'argon' => ['memory_cost' => 1024, 'time_cost' => 1, 'threads' => 1]];
/** Base fraîche à chaque test. Par défaut SQLite en mémoire ; sur le serveur (auto-test), la base MySQL vide, nettoyée entre deux tests. */
function freshApp(): App
{
    Clock::$fixed = 1_800_000_000;
    $sd = sys_get_temp_dir() . '/epi-test-' . bin2hex(random_bytes(4)); $GLOBALS['STORAGE_DIRS'][] = $sd;
    $cfg = ['app_key' => base64_encode(random_bytes(32)), 'storage_dir' => $sd] + TEST_CFG;
    if (isset($GLOBALS['EPI_TEST_DB'])) {
        $db = $GLOBALS['EPI_TEST_DB'];
        foreach (['audit_log', 'throttle', 'recovery_codes', 'sessions', 'invitations', 'inventory_shares', 'item_files', 'files', 'item_measures', 'items', 'uid_counters', 'list_values', 'inventories', 'users', 'settings'] as $tbl) $db->run("DELETE FROM $tbl");
        return App::build($db, $cfg);
    }
    $app = App::build(new Db(new PDO('sqlite::memory:')), $cfg);
    $app->installSchema(__DIR__ . '/../sql');
    return $app;
}
const PW = 'correct horse battery 42';
/** Crée et active un compte complet. @return array{id:int,email:string,secret:string,codes:array,user:array} */
function makeUser(App $app, array $admin, string $email, string $role = 'member', string $name = ''): array
{
    $inv = $app->users->invite($admin, $email, $name ?: ucfirst(strstr($email, '@', true)), $role);
    $st = $app->users->activateStart($inv['token']);
    $fin = $app->users->activateFinish($inv['token'], PW, Totp::code($st['secret'], Totp::step()));
    Clock::advance(31);
    $u = $app->db->one('SELECT * FROM users WHERE id = ?', [$inv['user_id']]);
    return ['id' => $inv['user_id'], 'email' => $email, 'secret' => $st['secret'], 'codes' => $fin['recovery_codes'], 'user' => $u, 'member_no' => $inv['member_no']];
}
function loginFull(App $app, array $u, bool $remember = false): array
{
    $a = $app->auth->login($u['email'], PW, '1.2.3.4');
    ok($a['ok'], 'login étape 1');
    Clock::advance(31);
    $b = $app->auth->verifySecond($a['token'], Totp::code($u['secret'], Totp::step()), $remember, '1.2.3.4');
    ok($b['ok'], 'login étape 2');
    return $b;
}
/** App avec un admin, un responsable et trois membres. */
function world(): array
{
    $app = freshApp();
    $boot = $app->bootstrap('Club test', 'admin@club.be', 'Admin Un');
    $st = $app->users->activateStart($boot['token']);
    $app->users->activateFinish($boot['token'], PW, Totp::code($st['secret'], Totp::step()));
    Clock::advance(31);
    $adminRow = $app->db->one('SELECT * FROM users WHERE email = ?', ['admin@club.be']);
    $admin = ['id' => (int)$adminRow['id'], 'email' => 'admin@club.be', 'secret' => $st['secret'], 'user' => $adminRow];
    $w = ['app' => $app, 'admin' => $admin, 'A' => $adminRow];
    $w['G'] = makeUser($app, $adminRow, 'gestion@club.be', 'manager', 'Gestion');
    foreach (['m1', 'm2', 'm3'] as $m) $w[$m] = makeUser($app, $adminRow, "$m@club.be", 'member', strtoupper($m));
    $w['club'] = (int)$app->access->clubInventory()['id'];
    foreach (['A' => $adminRow, 'G' => $w['G']['user'], 'm1' => $w['m1']['user'], 'm2' => $w['m2']['user'], 'm3' => $w['m3']['user']] as $k => $u)
        $w['inv'][$k] = (int)$app->db->val("SELECT id FROM inventories WHERE owner_user_id = ?", [$u['id']]);
    return $w;
}

