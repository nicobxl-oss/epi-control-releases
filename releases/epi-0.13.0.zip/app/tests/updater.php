<?php
declare(strict_types=1);
use Epi\{Updater, ApiError};

function relFixture(string $ver = '0.13.0', array $over = [], ?string $sk = null): array
{
    static $kp = null; $kp ??= sodium_crypto_sign_keypair();
    $sk ??= sodium_crypto_sign_secretkey($kp); $sha = hash('sha256', 'zip ' . $ver); $size = 150000;
    $sig = base64_encode(sodium_crypto_sign_detached(Updater::message($ver, $sha, $size), $sk));
    $j = array_merge(['format' => 'epi-release-v1', 'version' => $ver, 'file' => 'epi-' . $ver . '.zip', 'sha256' => $sha, 'size' => $size, 'published' => '2026-11-14', 'notes' => ['Un point', 'Deux'], 'signature' => $sig], $over);
    return [$j, base64_encode(sodium_crypto_sign_publickey($kp))];
}
function updaterFor($j, string $pk, int $code = 200, ?array $cfg = null): Updater
{
    return new Updater($cfg ?? [], fn(string $u) => [$code, is_string($j) ? $j : json_encode($j)], $pk);
}

t('Mise à jour : version signée lue, comparée, nom du zip reconstruit', function () {
    [$j, $pk] = relFixture('0.13.0', ['file' => '../../evil.php']);
    $r = updaterFor($j, $pk)->check('0.12.0');
    eq([$r['latest'], $r['newer'], $r['current'], $r['published'], $r['notes']], ['0.13.0', true, '0.12.0', '2026-11-14', ['Un point', 'Deux']]);
    eq($r['file'], 'epi-0.13.0.zip'); ok(str_ends_with($r['url'], '/releases/epi-0.13.0.zip') && str_starts_with($r['url'], 'https://raw.githubusercontent.com/'), 'adresse du zip');
    eq(updaterFor($j, $pk)->check('0.13.0')['newer'], false); eq(updaterFor($j, $pk)->check('0.14.1')['newer'], false);   // même version ou plus récente chez moi : pas de mise à jour
    eq(updaterFor($j, $pk)->check('0.9.0')['newer'], true);   // 0.13.0 > 0.9.0 (comparaison numérique, pas de texte)
});
t('Mise à jour : signature fausse, message modifié, mauvaise clé, JSON invalide', function () {
    [$j, $pk] = relFixture();
    foreach ([['version' => '0.99.0'], ['sha256' => str_repeat('a', 64)], ['size' => 150001], ['signature' => base64_encode(str_repeat('x', 64))]] as $over)
        throws(fn() => updaterFor(array_merge($j, $over), $pk)->check('0.12.0'), 502, 'update_bad_signature');
    $other = base64_encode(sodium_crypto_sign_publickey(sodium_crypto_sign_keypair()));   // une autre clé publique que celle qui a signé
    throws(fn() => updaterFor($j, $other)->check('0.12.0'), 502, 'update_bad_signature');   // signé par quelqu'un d'autre
    eq(updaterFor(array_merge($j, ['notes' => ['Autre texte']]), $pk)->check('0.12.0')['notes'], ['Autre texte']);   // les nouveautés ne sont pas signées : simple texte affiché
    foreach ([['version' => '../1.0'], ['version' => '1.0'], ['sha256' => 'zz'], ['size' => '150000'], ['size' => 10], ['format' => 'autre'], ['signature' => 5]] as $over)
        throws(fn() => updaterFor(array_merge($j, $over), $pk)->check('0.12.0'), 502, 'update_invalid');
    throws(fn() => updaterFor('pas du json', $pk)->check('0.12.0'), 502, 'update_invalid');
    throws(fn() => updaterFor('[]', $pk)->check('0.12.0'), 502, 'update_invalid');
});
t('Mise à jour : rien de publié, serveur injoignable, dépôt configurable seulement au bon format', function () {
    [$j, $pk] = relFixture();
    throws(fn() => updaterFor($j, $pk, 404)->check('0.12.0'), 404, 'update_none_published');
    throws(fn() => updaterFor($j, $pk, 500)->check('0.12.0'), 502, 'update_unreachable');
    eq((new Updater([]))->repo(), Updater::RELEASES_REPO); eq((new Updater(['releases_repo' => 'moi/mes-versions']))->repo(), 'moi/mes-versions');
    eq((new Updater(['releases_repo' => 'x/../../etc']))->repo(), Updater::RELEASES_REPO); eq((new Updater(['releases_repo' => 'http://evil']))->repo(), Updater::RELEASES_REPO);
    eq(strlen(base64_decode(Updater::PUBLIC_KEY, true)), 32);
    $notes = array_fill(0, 50, str_repeat('e', 400)); $r = updaterFor(relFixture('0.13.0', ['notes' => $notes])[0], relFixture()[1])->check('0.12.0');
    eq(count($r['notes']), 30); eq(strlen($r['notes'][0]), 300);
});
