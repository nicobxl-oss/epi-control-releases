<?php
use Epi\{App, Clock, ApiError, Registry};

function basic(array $o = []): array { return $o + ['type' => 'Mousqueton', 'marque' => 'Petzl', 'modele' => 'Attache', 'etat' => 'En service']; }

t('Registre : les listes par défaut existent, les valeurs système sont marquées', function () {
    $w = world(); $reg = $w['app']->registry; $s = $reg->snapshot($w['G']['user'], $w['club']);
    eq(count($s['lists']['type']), 13); eq($s['lists']['etat'], ['En service', 'En fixe', 'Stock', 'Épuisé', 'Déclassé', 'Perdu']);
    $corde = array_values(array_filter($s['lists']['type'], fn($t) => $t['l'] === 'Corde'))[0]; eq($corde['c'], 'COR'); eq($corde['vie'], true); eq($corde['sys'], 'corde');
    eq($s['can'], ['edit' => true, 'delete' => true]);
    eq($reg->snapshot($w['m1']['user'], $w['club'])['can'], ['edit' => false, 'delete' => false]);
});
t('Registre : UID club COR-0001… et UID membre M0x-COR-0001, compteurs indépendants', function () {
    $w = world(); $reg = $w['app']->registry;
    $a = $reg->create($w['G']['user'], $w['club'], basic(['type' => 'Corde'])); $b = $reg->create($w['G']['user'], $w['club'], basic(['type' => 'Corde']));
    eq($a['uid'], 'COR-0001'); eq($b['uid'], 'COR-0002');
    $m = $reg->create($w['m1']['user'], $w['inv']['m1'], basic(['type' => 'Corde']));
    eq($m['uid'], 'M' . str_pad((string)$w['m1']['member_no'], 2, '0', STR_PAD_LEFT) . '-COR-0001');
    eq($reg->create($w['G']['user'], $w['club'], basic())['uid'], 'MOS-0001');
});
t('Registre : un UID n’est jamais réutilisé après suppression', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user'];
    $reg->create($g, $w['club'], basic()); $reg->create($g, $w['club'], basic());
    $reg->delete($g, 'MOS-0002');
    eq($reg->create($g, $w['club'], basic())['uid'], 'MOS-0003');
});
t('Registre : droits — membre lit le club mais ne modifie pas ; cloisonnement des inventaires personnels', function () {
    $w = world(); $reg = $w['app']->registry;
    $it = $reg->create($w['G']['user'], $w['club'], basic());
    throws(fn() => $reg->create($w['m1']['user'], $w['club'], basic()), 403);
    throws(fn() => $reg->update($w['m1']['user'], $it['uid'], ['modele' => 'X']), 403);
    throws(fn() => $reg->delete($w['m1']['user'], $it['uid']), 403);
    $mine = $reg->create($w['m1']['user'], $w['inv']['m1'], basic());
    throws(fn() => $reg->snapshot($w['m2']['user'], $w['inv']['m1']), 404);
    throws(fn() => $reg->snapshot($w['A'], $w['inv']['m1']), 404);
    throws(fn() => $reg->update($w['m2']['user'], $mine['uid'], ['modele' => 'X']), 404);
    throws(fn() => $reg->delete($w['A'], $mine['uid']), 404);
    throws(fn() => $reg->cut($w['m2']['user'], $mine['uid'], [1], []), 404);
});
t('Registre : partage — lecture seule ne modifie pas, « write » modifie et supprime', function () {
    $w = world(); $app = $w['app']; $reg = $app->registry;
    $mine = $reg->create($w['m1']['user'], $w['inv']['m1'], basic());
    $app->access->share($w['m1']['user'], $w['inv']['m1'], (int)$w['m2']['id'], 'read');
    eq(count($reg->snapshot($w['m2']['user'], $w['inv']['m1'])['items']), 1);
    throws(fn() => $reg->update($w['m2']['user'], $mine['uid'], ['modele' => 'X']), 403);
    $app->access->share($w['m1']['user'], $w['inv']['m1'], (int)$w['m2']['id'], 'write');
    eq($reg->update($w['m2']['user'], $mine['uid'], ['modele' => 'Nouveau'])['modele'], 'Nouveau');
    $reg->delete($w['m2']['user'], $mine['uid']);
    eq(count($reg->snapshot($w['m1']['user'], $w['inv']['m1'])['items']), 0);
});
t('Registre : validation (type, nom, dates, longueur, durées de vie, listes inconnues)', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    throws(fn() => $reg->create($g, $c, ['marque' => 'Petzl']), 422, 'missing_type');
    throws(fn() => $reg->create($g, $c, ['type' => 'Inconnu', 'marque' => 'Petzl']), 422, 'unknown_type');
    throws(fn() => $reg->create($g, $c, ['type' => 'Corde']), 422, 'name_required');
    throws(fn() => $reg->create($g, $c, basic(['marque' => 'Nouvelle'])), 422, 'unknown_marque');
    throws(fn() => $reg->create($g, $c, basic(['fab' => '2024-02-30'])), 422, 'invalid_date');
    throws(fn() => $reg->create($g, $c, basic(['type' => 'Corde', 'longueur' => 'beaucoup'])), 422, 'invalid_length');
    throws(fn() => $reg->create($g, $c, basic(['type' => 'Corde', 'vieUtil' => 'abc'])), 422, 'invalid_years');
    throws(fn() => $reg->create($g, $c, basic(['modele' => str_repeat('x', 121)])), 422, 'too_long');
    $r = $reg->create($g, $c, basic(['type' => 'Corde', 'longueur' => '60,5', 'vieUtil' => '4,5', 'vieTotale' => 10, 'fab' => '2024-02-29']));
    eq($r['longueur'], 60.5); eq($r['vieUtil'], 4.5); eq($r['fab'], '2024-02-29'); eq($r['type_sys'], 'corde');
    $m = $reg->create($g, $c, basic(['vieUtil' => 5]));
    ok(!isset($m['vieUtil']), 'durée ignorée pour un type non limité');
});
t('Registre : lot / n° de série unique par marque (sauf dans une même famille de cordes)', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $a = $reg->create($g, $c, basic(['type' => 'Corde', 'lot' => 'L-77', 'longueur' => 100]));
    throws(fn() => $reg->create($g, $c, basic(['lot' => 'l-77'])), 409, 'duplicate_lot');
    $reg->create($g, $c, basic(['lot' => 'L-77', 'marque' => 'Camp']));
    $cut = $reg->cut($g, $a['uid'], [10], []); ok(count($cut['made']) === 1, 'un morceau garde le lot de sa bobine');
});
t('Registre : modification — le type ne change pas, le nom est exigé, la liste se met à jour', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user'];
    $it = $reg->create($g, $w['club'], basic());
    $u = $reg->update($g, $it['uid'], ['type' => 'Corde', 'modele' => 'Autre', 'etat' => 'Stock']); eq($u['type'], 'Mousqueton'); eq($u['etat'], 'Stock'); eq($u['modele'], 'Autre');
    throws(fn() => $reg->update($g, $it['uid'], ['modele' => '', 'marque' => '']), 422, 'name_required');
    throws(fn() => $reg->update($g, 'ZZZ-0001', ['modele' => 'x']), 404);
});
t('Listes : ajouter, renommer (les équipements suivent), supprimer seulement si inutilisée et non système', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $v = $reg->addValue($g, $c, 'marque', 'Climbing Technology');
    $it = $reg->create($g, $c, basic(['marque' => 'Climbing Technology']));
    $reg->updateValue($g, $v['id'], ['label' => 'CT']);
    eq($reg->snapshot($g, $c)['items'][0]['marque'], 'CT', 'renommage répercuté');
    throws(fn() => $reg->removeValue($g, $v['id']), 409, 'in_use');
    $reg->delete($g, $it['uid']); $reg->removeValue($g, $v['id']);
    $sys = array_values(array_filter($reg->lists($c)['rows'], fn($r) => $r['sys'] === 'stock'))[0];
    throws(fn() => $reg->removeValue($g, $sys['id']), 409, 'system_value');
    $reg->updateValue($g, $sys['id'], ['label' => 'En réserve']);
    $it2 = $reg->create($g, $c, basic(['etat' => 'En réserve'])); eq($it2['etat_sys'], 'stock');
    throws(fn() => $reg->updateValue($g, $sys['id'], ['label' => 'Perdu']), 409, 'value_exists');
    throws(fn() => $reg->addValue($w['m1']['user'], $c, 'marque', 'X'), 403);
    $t = $reg->addValue($g, $c, 'type', 'Pitons'); $codes = array_column($reg->lists($c)['type'], 'c'); ok(in_array('PIT', $codes, true));
    $reg->updateValue($g, $t['id'], ['limited' => true]);
    eq($reg->create($g, $c, ['type' => 'Pitons', 'marque' => 'Petzl', 'vieUtil' => 3])['vieUtil'], 3.0);
    throws(fn() => $reg->updateValue($w['m1']['user'], $t['id'], ['label' => 'Z']), 403);
});
t('Cordes : mesure, longueur actuelle, découpe, bobine épuisée, rebut, déclassement', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'lot' => 'B1']));
    $r = $reg->cut($g, $b['uid'], [30, '25,5'], ['mes' => '', 'etat' => 'Stock']);
    eq($r['made'], ['COR-0002', 'COR-0003']); $p = $r['item']; eq(end($p['mesures'])['l'], 44.5); eq($p['etat'], 'Stock');
    $kid = $reg->snapshot($g, $c)['items'][1]; eq($kid['parent'], 'COR-0001'); eq($kid['longueur'], 30.0); eq($kid['mes'], ''); eq($kid['etat'], 'Stock'); eq($kid['lot'], 'B1');
    throws(fn() => $reg->cut($g, $b['uid'], [50], []), 422, 'too_long');
    throws(fn() => $reg->cut($g, $b['uid'], [0], []), 422, 'invalid_piece');
    throws(fn() => $reg->cut($g, $b['uid'], [], []), 422, 'no_pieces');
    $m = $reg->addMeasure($g, $b['uid'], ['l' => '40', 'par' => $g['name']]); eq(end($m['mesures'])['l'], 40.0);
    $r2 = $reg->cut($g, $b['uid'], [40], []); eq($r2['item']['etat'], 'Épuisé'); eq(end($r2['item']['mesures'])['l'], 0.0);
    throws(fn() => $reg->cut($g, $b['uid'], [1], []), 409, 'not_in_use');
    // rebut + déclassement
    $b2 = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'En service', 'longueur' => 50]));
    $r3 = $reg->cut($g, $b2['uid'], [20], ['rebut' => true, 'declasser' => true]); eq($r3['item']['etat'], 'Déclassé'); eq(end($r3['item']['mesures'])['l'], 0.0);
    // non corde
    $mq = $reg->create($g, $c, basic()); throws(fn() => $reg->cut($g, $mq['uid'], [1], []), 422, 'not_cuttable'); throws(fn() => $reg->addMeasure($g, $mq['uid'], ['l' => 1]), 422, 'not_measurable');
    // tout ou rien : étape invalide au milieu → rien n'est créé
    $n = count($reg->snapshot($g, $c)['items']); try { $reg->cut($g, $b2['uid'], [1], ['etat' => 'Inexistant']); } catch (ApiError $e) {} eq(count($reg->snapshot($g, $c)['items']), $n);
});
t('Import : création, mise à jour, UID imposé, parent, longueur actuelle, lignes refusées, ajout aux listes', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $res = $reg->import($g, $c, [
        ['line' => 2, 'uid' => 'COR-0007', 'data' => ['type' => 'Corde', 'marque' => 'Mammut', 'modele' => 'Tour', 'longueur' => 80, 'etat' => 'Stock'], 'cur' => 75.5],
        ['line' => 3, 'uid' => 'COR-0008', 'data' => ['type' => 'Corde', 'marque' => 'Mammut', 'modele' => 'Tour', 'longueur' => 10, 'parent' => 'COR-0007']],
        ['line' => 4, 'data' => ['type' => 'Bidule', 'marque' => 'X']],
        ['line' => 5, 'data' => ['type' => 'Corde', 'marque' => '', 'modele' => '']],
        ['line' => 6, 'uid' => 'COR-0007', 'data' => ['modele' => 'Tour 2'], 'cur' => 70],
    ], );
    eq([$res['created'], $res['updated']], [3, 1]);
    eq(array_column($res['errors'], 'line'), [5]);
    $s = $reg->snapshot($g, $c); $by = array_column($s['items'], null, 'uid');
    eq($by['COR-0007']['modele'], 'Tour 2'); eq(end($by['COR-0007']['mesures'])['l'], 70.0); eq(count($by['COR-0007']['mesures']), 2); eq($by['COR-0008']['parent'], 'COR-0007');
    ok(in_array('Mammut', $s['lists']['marque'], true), 'marque ajoutée'); ok(in_array('Bidule', array_column($s['lists']['type'], 'l'), true), 'type ajouté');
    eq($reg->create($g, $c, basic(['type' => 'Corde']))['uid'], 'COR-0009', 'le compteur dépasse les UID importés');
    throws(fn() => $reg->import($w['m1']['user'], $c, []), 403);
    $mine = $reg->import($w['m1']['user'], $w['inv']['m1'], [['data' => ['type' => 'Casque', 'marque' => 'Petzl']]]); eq($mine['created'], 1);
    $uid = $reg->snapshot($w['m1']['user'], $w['inv']['m1'])['items'][0]['uid']; ok(str_starts_with($uid, 'M'), 'UID membre');
    $imp = $reg->import($w['m1']['user'], $w['inv']['m1'], [['uid' => 'COR-0007', 'data' => ['modele' => 'pirate']]]);
    eq([$imp['created'], $imp['updated'], count($imp['errors'])], [0, 0, 1], 'un UID du club ne permet pas de modifier le club depuis un inventaire personnel');
    eq(array_column($reg->snapshot($g, $c)['items'], null, 'uid')['COR-0007']['modele'], 'Tour 2');
});
t('Journal : le club est journalisé (qui, quoi, ancien → nouveau), les inventaires personnels jamais', function () {
    $w = world(); $app = $w['app']; $reg = $app->registry; $g = $w['G']['user'];
    $it = $reg->create($g, $w['club'], basic()); $reg->update($g, $it['uid'], ['modele' => 'Neuf', 'etat' => 'Stock']);
    $reg->addMeasure($g, $reg->create($g, $w['club'], basic(['type' => 'Corde', 'longueur' => 5]))['uid'], ['l' => 4]); $reg->delete($g, $it['uid']);
    $ev = $app->audit->feed('club'); $acts = array_column($ev, 'action');
    foreach (['item.create', 'item.update', 'item.measure', 'item.delete'] as $a) ok(in_array($a, $acts, true), $a);
    $upd = array_values(array_filter($ev, fn($e) => $e['action'] === 'item.update'))[0];
    ok(str_contains($upd['detail'], 'modèle : Attache → Neuf') && str_contains($upd['detail'], 'état : En service → Stock'), $upd['detail']); eq($upd['user_name'], 'GESTION');
    $before = count($app->audit->feed('club'));
    $reg->create($w['m1']['user'], $w['inv']['m1'], basic()); $reg->import($w['m1']['user'], $w['inv']['m1'], [['data' => basic()]]);
    $reg->update($w['m1']['user'], 'M0' . $w['m1']['member_no'] . '-MOS-0001', ['modele' => 'secret']);
    eq(count($app->audit->feed('club')), $before, 'rien de personnel dans le journal du club');
    ok(!in_array('item.create', array_column($app->audit->feed('accounts'), 'action'), true), 'le journal des comptes est à part');
});
t('Journal : purge des lignes de plus d’un an', function () {
    $w = world(); $app = $w['app']; $app->audit->log(1, 'test.old'); Clock::advance(366 * 86400);
    $n = $app->audit->purge(); ok($n >= 1); eq((int)$app->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'test.old'"), 0);
});
t('API registre : instantané, création, droits, CSRF, découpe, journal club', function () {
    $w = apiWorld(); $app = $w['app']; $adm = client($app); $adm->login('a@club.be', PW, $w['secret']);
    $club = (int)$app->access->clubInventory()['id'];
    [$s, $d] = $adm->call('GET', "/inventories/$club/data"); eq($s, 200); eq(count($d['lists']['type']), 13);
    $csrf = $adm->csrf; $adm->csrf = null;
    [$s] = $adm->call('POST', "/inventories/$club/items", basic()); eq($s, 403); $adm->csrf = $csrf;
    [$s, $d] = $adm->call('POST', "/inventories/$club/items", basic(['type' => 'Corde', 'longueur' => 20])); eq($s, 201); $uid = $d['item']['uid']; eq($uid, 'COR-0001');
    [$s, $d] = $adm->call('POST', "/items/$uid/cut", ['pieces' => [5, 5], 'options' => ['etat' => 'Stock']]); eq($s, 201); eq(count($d['made']), 2);
    [$s, $d] = $adm->call('POST', "/items/$uid/measures", ['l' => 9.5]); eq($s, 201);
    [$s, $d] = $adm->call('POST', "/items/$uid", ['modele' => 'Via']); eq($s, 200); eq($d['item']['modele'], 'Via');
    [$s, $d] = $adm->call('POST', "/inventories/$club/import", ['rows' => [['data' => basic()]]]); eq($s, 200); eq($d['created'], 1);
    [$s, $d] = $adm->call('GET', '/journal/club'); eq($s, 200); ok(count($d['events']) >= 4);
    [$s] = $adm->call('GET', '/journal/accounts'); eq($s, 200);
    [$s] = $adm->call('DELETE', "/items/COR-0002"); eq($s, 409);                       // un morceau ne se supprime pas
    [$s, $d] = $adm->call('POST', "/items/COR-0002/uncut"); eq($s, 200); eq($d['item']['uid'], $uid);   // il s'annule
    [$s] = $adm->call('DELETE', "/items/$uid"); eq($s, 409);                           // la bobine a encore un morceau
    [$s, $d] = $adm->call('GET', '/items/zz'); eq($s, 404);
});

t('Club : nom et logo enregistrés par un admin seulement, logo vérifié', function () {
    $w = world(); $reg = $w['app']->registry;
    eq($reg->clubConfig(), ['nom' => '', 'logo' => '', 'logoBg' => 'none']);
    $logo = 'data:image/png;base64,iVBORw0KGgo=';
    $reg->saveClubConfig($w['A'], ['nom' => 'Spéléo Club', 'logo' => $logo, 'logoBg' => 'light']);
    eq($reg->clubConfig(), ['nom' => 'Spéléo Club', 'logo' => $logo, 'logoBg' => 'light']);
    throws(fn() => $reg->saveClubConfig($w['G']['user'], ['nom' => 'X']), 403);
    throws(fn() => $reg->saveClubConfig($w['A'], ['nom' => 'X', 'logo' => 'javascript:alert(1)']), 422, 'invalid_logo');
    throws(fn() => $reg->saveClubConfig($w['A'], ['nom' => 'X', 'logo' => 'data:image/svg+xml;base64,AAAA']), 422, 'invalid_logo');
    $reg->saveClubConfig($w['A'], ['nom' => 'Autre']); eq($reg->clubConfig()['logo'], '');
});

t('Import : les UID d’un autre inventaire sont ramenés à celui-ci (préfixe M0x), parents compris', function () {
    $w = world(); $reg = $w['app']->registry; $u = $w['m1']['user']; $inv = $w['inv']['m1']; $p = 'M0' . $w['m1']['member_no'] . '-';
    $r = $reg->import($u, $inv, [
        ['line' => 2, 'uid' => 'COR-0010', 'data' => ['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'A', 'longueur' => 100, 'etat' => 'Stock']],
        ['line' => 3, 'uid' => 'COR-0011', 'data' => ['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'A', 'longueur' => 30, 'parent' => 'COR-0010']],
        ['line' => 4, 'uid' => 'M99-COR-0012', 'data' => ['type' => 'Corde', 'marque' => 'Beal', 'modele' => 'A', 'longueur' => 30, 'parent' => 'M99-COR-0010']],
        ['line' => 5, 'uid' => 'pas un uid', 'data' => ['type' => 'Casque', 'marque' => 'Petzl']],
    ]);
    eq([$r['created'], count($r['errors'])], [4, 0]);
    $by = array_column($reg->snapshot($u, $inv)['items'], null, 'uid');
    ok(isset($by[$p . 'COR-0010'], $by[$p . 'COR-0011'], $by[$p . 'COR-0012']), implode(',', array_keys($by)));
    eq($by[$p . 'COR-0011']['parent'], $p . 'COR-0010'); eq($by[$p . 'COR-0012']['parent'], $p . 'COR-0010');
    ok(isset($by[$p . 'CAS-0001']), 'UID invalide : un nouvel UID est attribué');
});

t('Remarque : enregistrée, modifiable, importée, trop longue refusée', function () {
    $w = world(); $reg = $w['app']->registry; $u = $w['m1']['user']; $inv = $w['inv']['m1'];
    $a = $reg->create($u, $inv, ['type' => 'Casque', 'marque' => 'Petzl', 'modele' => 'Boreo', 'remarque' => ' Dédié MC ']);
    eq($a['remarque'], 'Dédié MC');
    $b = $reg->update($u, $a['uid'], ['remarque' => 'Cadeau']); eq($b['remarque'], 'Cadeau');
    $r = $reg->import($u, $inv, [['line' => 2, 'uid' => '', 'data' => ['type' => 'Casque', 'marque' => 'Petzl', 'remarque' => 'Importée']]]);
    eq($r['created'], 1);
    throws(fn() => $reg->update($u, $a['uid'], ['remarque' => str_repeat('x', 501)]), 422, 'too_long');
});

t('Prix : saisie, virgule, refus, visibilité (membre du club ne voit pas), perso toujours visible', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club']; $m1 = $w['m1']['user'];
    $a = $reg->create($g, $c, basic(['prix' => '24,90 €'])); eq($a['prix'], 24.9);
    $b = $reg->create($g, $c, basic(['modele' => 'sans prix'])); eq($b['prix'], 0.0);
    throws(fn() => $reg->create($g, $c, basic(['prix' => 'abc'])), 422, 'invalid_price');
    throws(fn() => $reg->create($g, $c, basic(['prix' => '-3'])), 422, 'invalid_price');
    $u = $reg->update($g, $a['uid'], ['prix' => 30]); eq($u['prix'], 30.0);
    $x = $reg->snapshot($m1, $c); ok(!array_key_exists('prix', $x['items'][0]), 'un membre simple ne voit pas les prix du club');
    $y = $reg->snapshot($g, $c); eq($y['items'][0]['prix'], 30.0);
    $mine = $reg->create($m1, $w['inv']['m1'], basic(['prix' => '12'])); eq($reg->snapshot($m1, $w['inv']['m1'])['items'][0]['prix'], 12.0);
    $r = $reg->import($g, $c, [['line' => 2, 'uid' => '', 'data' => ['type' => 'Casque', 'marque' => 'Petzl', 'prix' => '99,5']], ['line' => 3, 'uid' => '', 'data' => ['type' => 'Casque', 'marque' => 'Petzl', 'prix' => 'oops']]]);
    eq([$r['created'], count($r['errors'])], [1, 1]);
});
t('Prix : la découpe répartit le prix de la bobine au mètre, sans compter deux fois', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'prix' => 300]));
    $r = $reg->cut($g, $b['uid'], [35, 25], []);
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid');
    eq($by[$r['made'][0]]['prix'], 105.0); eq($by[$r['made'][1]]['prix'], 75.0); eq($by[$b['uid']]['prix'], 120.0);
    eq(round(array_sum(array_column($by, 'prix')), 2), 300.0);
    $r2 = $reg->cut($g, $b['uid'], [40], ['rebut' => true]);   // reste 0 après rebut => la bobine n'a plus de prix propre
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid');
    eq($by[$r2['made'][0]]['prix'], 120.0 * 40 / 40); eq($by[$b['uid']]['prix'], 0.0);
});

t('0.4.1 : Stock par défaut, longueur réservée aux cordes/sangles, prix au mètre figé, état En fixe ajouté aux anciennes bases', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $a = $reg->create($g, $c, ['type' => 'Mousqueton', 'marque' => 'Petzl', 'longueur' => '12 mm']); eq($a['etat'], 'Stock'); eq($a['longueur'], '');
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'prix' => 300]));
    eq($b['prixM'], 3.0);
    $r = $reg->cut($g, $b['uid'], [40], []);
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid');
    eq($by[$r['made'][0]]['prixM'], 3.0); eq($by[$b['uid']]['prixM'], 3.0); eq($by[$b['uid']]['prix'], 180.0);
    $u = $reg->update($g, $b['uid'], ['modele' => 'autre', 'prix' => 180, 'longueur' => 100]); eq($u['prixM'], 3.0);   // rien de changé : pas de recalcul
    $u = $reg->update($g, $b['uid'], ['prix' => 200]); eq($u['prixM'], 3.0);                                         // bobine déjà coupée : prix au mètre figé
    // ancienne base : l'état En fixe est créé, et un « En fixe » déjà saisi à la main devient l'état système
    $w['app']->db->run("DELETE FROM list_values WHERE inventory_id = ? AND sys = 'fixe'", [$c]);
    $snap = $reg->snapshot($g, $c); ok(in_array('En fixe', $snap['lists']['etat'], true), 'En fixe recréé');
    $row = array_values(array_filter($snap['lists']['rows'] ?? [], fn($x) => ($x['label'] ?? '') === 'En fixe'));
    ok(!$row || ($row[0]['sys'] ?? 'fixe') === 'fixe', 'état système');
    $f = $reg->create($g, $c, basic(['etat' => 'En fixe', 'modele' => 'poste fixe'])); eq($f['etat'], 'En fixe');
});

t('0.4.2 : les morceaux héritent des caractéristiques de leur bobine (propagation, verrou, journal)', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'lot' => 'L1', 'modele' => 'Ancien', 'vieUtil' => 10, 'fournisseur' => 'Shop']));
    $r = $reg->cut($g, $b['uid'], [20, 20], []); [$k1, $k2] = $r['made'];
    $sub = $reg->cut($g, $k1, [5], []); $g2 = $sub['made'][0];                       // morceau d'un morceau
    $reg->update($g, $b['uid'], ['modele' => 'Nouveau', 'lot' => 'L2', 'fournisseur' => 'Autre', 'vieUtil' => 8, 'remarque' => 'propre à la bobine']);
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid');
    foreach ([$k1, $k2, $g2] as $u) { eq($by[$u]['modele'], 'Nouveau'); eq($by[$u]['lot'], 'L2'); eq($by[$u]['fournisseur'], 'Autre'); eq($by[$u]['vieUtil'], 8.0); eq($by[$u]['remarque'], ''); }
    $reg->update($g, $b['uid'], ['activite' => 'Escalade']); $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid'); ok($by[$k2]['activite'] !== 'Escalade', 'l\'activité ne se propage pas');
    // verrou : un morceau ne change pas ses champs hérités, mais garde les siens
    try { $reg->update($g, $k1, ['modele' => 'X']); ok(false, 'refusé'); } catch (ApiError $e) { eq($e->getMessage() ?: $e->code ?? '', $e->getMessage()); eq($e->status, 422); }
    $same = $reg->update($g, $k1, ['modele' => 'Nouveau', 'lot' => 'L2', 'remarque' => 'à surveiller', 'etat' => 'En service']); eq($same['remarque'], 'à surveiller'); eq($same['etat'], 'En service');
    // import : un morceau reprend les valeurs de sa bobine
    $imp = $reg->import($g, $c, [['line' => 2, 'uid' => 'COR-0099', 'data' => ['type' => 'Corde', 'marque' => 'Camp', 'modele' => 'Autre modèle', 'parent' => $b['uid'], 'longueur' => 3]]]);
    eq($imp['created'], 1); $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid'); eq($by['COR-0099']['modele'], 'Nouveau'); eq($by['COR-0099']['marque'], 'Petzl');
    // traçabilité : une ligne de journal par morceau modifié
    $j = $w['app']->audit->feed('club', 200); $heritage = array_filter($j, fn($e) => str_contains((string)($e['detail'] ?? ''), 'hérité de ' . $b['uid']));
    ok(count($heritage) >= 3, 'journal : ' . count($heritage) . ' lignes héritées');
});

t('0.4.3 : le prix d\'un morceau vient de sa bobine (prix au mètre x longueur), même après une mesure', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'prix' => 100]));      // 1 € le mètre
    $reg->addMeasure($g, $b['uid'], ['l' => 98, 'note' => 'rétractation']);                                         // la corde a rétréci : le prix au mètre ne bouge pas
    $r = $reg->cut($g, $b['uid'], [35, 20], []); $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid');
    eq($by[$r['made'][0]]['prix'], 35.0); eq($by[$r['made'][1]]['prix'], 20.0); eq($by[$b['uid']]['prix'], 45.0);
    // un morceau ne peut pas recevoir un autre prix ; corriger sa longueur d'origine recalcule son prix
    try { $reg->update($g, $r['made'][0], ['prix' => 50]); ok(false, 'refusé'); } catch (ApiError $e) { eq($e->status, 422); }
    $u = $reg->update($g, $r['made'][0], ['prix' => 35, 'remarque' => 'ok']); eq($u['prix'], 35.0);
    try { $reg->update($g, $r['made'][0], ['longueur' => 40]); ok(false, 'longueur refusée'); } catch (ApiError $e) { eq($e->status, 422); }   // longueur d'origine fixée à la découpe
    $u = $reg->update($g, $r['made'][0], ['longueur' => 35, 'activite' => 'Escalade']); eq($u['prix'], 35.0); eq($u['activite'], 'Escalade');   // l'activité reste libre
    // import : un morceau reçoit son prix de la bobine, quoi qu'il indique
    $imp = $reg->import($g, $c, [['line' => 2, 'uid' => 'COR-0090', 'data' => ['type' => 'Corde', 'marque' => 'Petzl', 'modele' => 'Attache', 'parent' => $b['uid'], 'longueur' => 10, 'prix' => 999]]]);
    eq($imp['created'], 1); $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid'); eq($by['COR-0090']['prix'], 10.0);
});

t('0.4.5 : annuler la découpe rend la longueur et le prix à la bobine ; ni morceau ni bobine coupée ne se suppriment', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $c = $w['club']; $m = $w['m1']['user'];
    $b = $reg->create($g, $c, basic(['type' => 'Corde', 'etat' => 'Stock', 'longueur' => 100, 'prix' => 100]));
    $r = $reg->cut($g, $b['uid'], [60, 40], []);        // bobine entièrement découpée : épuisée
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid'); eq($by[$b['uid']]['etat'], 'Épuisé'); eq($by[$b['uid']]['prix'], 0.0);
    [$k1, $k2] = $r['made'];
    throws(fn() => $reg->delete($w['admin']['user'], $k1), 409, 'is_piece');
    throws(fn() => $reg->delete($w['admin']['user'], $b['uid']), 409, 'has_pieces');
    throws(fn() => $reg->uncut($m, $k1), 403);                                         // un membre simple du club ne peut pas
    $u = $reg->uncut($g, $k2)['item']; eq($u['etat'], 'Stock'); eq($u['prix'], 40.0); eq(end($u['mesures'])['l'], 40.0);
    $sub = $reg->cut($g, $k1, [10], []);
    throws(fn() => $reg->uncut($g, $k1), 409, 'has_pieces');                           // d'abord le morceau du morceau
    $reg->uncut($g, $sub['made'][0]); $reg->uncut($g, $k1);
    $by = array_column($reg->snapshot($g, $c)['items'], null, 'uid'); eq(array_keys($by), [$b['uid']]); eq($by[$b['uid']]['prix'], 100.0); eq(end($by[$b['uid']]['mesures'])['l'], 100.0);
    $n = $reg->cut($g, $b['uid'], [5], []); ok($n['made'][0] !== $k1 && $n['made'][0] !== $k2, 'les UID des morceaux annulés ne sont pas réutilisés');
    throws(fn() => $reg->uncut($g, $b['uid']), 422, 'not_a_piece');
    $ev = $w['app']->audit->feed('club', 200); ok(count(array_filter($ev, fn($e) => $e['action'] === 'item.uncut')) >= 3, 'journal : découpes annulées');
});

t('Registre : créé par / modifié par (noms), « ancien membre » si le compte n’existe plus', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user'];
    $it = $reg->create($g, $w['club'], basic());
    eq($it['creePar'], $g['name']); eq($it['majPar'], $g['name']);
    $s = $reg->snapshot($g, $w['club']); eq($s['items'][0]['creePar'], $g['name']);
    $w['app']->db->run('UPDATE items SET created_by = 99999 WHERE uid = ?', [$it['uid']]);   // compte disparu
    eq($reg->snapshot($g, $w['club'])['items'][0]['creePar'], 'ancien membre');
    $w['app']->db->run('UPDATE items SET created_by = NULL WHERE uid = ?', [$it['uid']]);    // jamais enregistré
    eq($reg->snapshot($g, $w['club'])['items'][0]['creePar'], '');
});

t('Actions groupées : contrôle (date + par, défaut = utilisateur connecté), uniquement les UID choisis', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $inv = $w['club'];
    $u = []; for ($i = 0; $i < 4; $i++) $u[] = $reg->create($g, $inv, basic(['modele' => "M$i"]))['uid'];
    $r = $reg->bulk($g, $inv, [$u[0], $u[2]], 'control', ['date' => '2027-01-15', 'par' => '']);
    eq($r['count'], 2); eq($r['items'][0]['ctrl'], '2027-01-15'); eq($r['items'][0]['par'], $g['name'], 'par = utilisateur connecté');
    $s = $reg->snapshot($g, $inv)['items']; $by = []; foreach ($s as $it) $by[$it['uid']] = $it;
    eq($by[$u[0]]['ctrl'], '2027-01-15'); eq($by[$u[2]]['par'], $g['name']); eq($by[$u[1]]['ctrl'], ''); eq($by[$u[3]]['ctrl'], '', 'les autres ne bougent pas');
    $reg->bulk($g, $inv, [$u[1]], 'control', ['date' => '2027-01-10', 'par' => $g['name']]);
    eq($reg->bulk($g, $inv, [$u[1]], 'control', ['date' => '2027-01-12', 'par' => $g['name']])['items'][0]['ctrl'], '2027-01-12');
    ok($w['app']->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'item.bulk'") >= 2, 'résumé dans le journal');
    ok($w['app']->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'item.update' AND target = ?", [$u[0]]) >= 1, 'trace par équipement');
});
t('Actions groupées : changement d’état (Déclassé), état inconnu refusé', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $inv = $w['club'];
    $a = $reg->create($g, $inv, basic())['uid']; $b = $reg->create($g, $inv, basic())['uid'];
    $r = $reg->bulk($g, $inv, [$a, $b], 'etat', ['etat' => 'Déclassé']); eq($r['items'][0]['etat'], 'Déclassé'); eq($r['items'][1]['etat_sys'], 'declasse');
    throws(fn() => $reg->bulk($g, $inv, [$a], 'etat', ['etat' => 'Inexistant']), 422, 'unknown_etat');
    throws(fn() => $reg->bulk($g, $inv, [$a], 'etat', ['etat' => '']), 422, 'missing_etat');
});
t('Actions groupées : validations (date, sélection vide, action inconnue, trop d’équipements)', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $inv = $w['club']; $a = $reg->create($g, $inv, basic())['uid'];
    throws(fn() => $reg->bulk($g, $inv, [$a], 'control', ['date' => '2027-13-40']), 422, 'invalid_date');
    throws(fn() => $reg->bulk($g, $inv, [$a], 'control', ['date' => '2099-01-01']), 422, 'future_date');
    throws(fn() => $reg->bulk($g, $inv, [], 'control', ['date' => '2027-01-01']), 422, 'no_selection');
    throws(fn() => $reg->bulk($g, $inv, [$a], 'supprimer', []), 422, 'invalid_action');
    throws(fn() => $reg->bulk($g, $inv, array_map(fn($i) => "MOS-$i", range(1, 201)), 'control', ['date' => '2027-01-01']), 413, 'too_many_items');
});
t('Actions groupées : tout ou rien, équipement d’une autre liste refusé, droits', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $inv = $w['club'];
    $a = $reg->create($g, $inv, basic())['uid']; $perso = $reg->create($w['m1']['user'], $w['inv']['m1'], basic())['uid'];
    throws(fn() => $reg->bulk($g, $inv, [$a, $perso], 'control', ['date' => '2027-01-15']), 404, 'not_found');
    eq($reg->snapshot($g, $inv)['items'][0]['ctrl'], '', 'rien modifié');
    throws(fn() => $reg->bulk($w['m1']['user'], $inv, [$a], 'control', ['date' => '2027-01-15']), 403);     // membre : lecture seule sur le club
    throws(fn() => $reg->bulk($w['m2']['user'], $w['inv']['m1'], [$perso], 'control', ['date' => '2027-01-15']), 404);   // liste perso d'un autre : on ne révèle même pas qu'elle existe
    eq($reg->bulk($w['m1']['user'], $w['inv']['m1'], [$perso], 'control', ['date' => '2027-01-15'])['count'], 1, 'propriétaire : ok sur sa liste');
});
t('Actions groupées : un morceau de corde peut être contrôlé ou déclassé', function () {
    $w = world(); $reg = $w['app']->registry; $g = $w['G']['user']; $inv = $w['club'];
    $c = $reg->create($g, $inv, basic(['type' => 'Corde', 'modele' => 'Opéra', 'longueur' => 100, 'lot' => 'L1']))['uid'];
    $cut = $reg->cut($g, $c, [10, 20], []); $ids = $cut['made'];
    eq(count($ids), 2);
    $r = $reg->bulk($g, $inv, array_merge([$c], $ids), 'control', ['date' => '2027-01-14', 'par' => $g['name']]); eq($r['count'], 3);
    $r = $reg->bulk($g, $inv, $ids, 'etat', ['etat' => 'Déclassé']); eq($r['items'][0]['etat'], 'Déclassé');
});

t('Mesuré / contrôlé par : la personne connectée par défaut, seulement un membre ayant accès à la liste', function () {
    $w = world(); $app = $w['app']; $reg = $app->registry; $m1 = $w['m1']['user']; $i = $w['inv']['m1'];
    $c = $reg->create($m1, $i, array_merge(basic(), ['type' => 'Corde', 'longueur' => '50']));
    $r = $reg->addMeasure($m1, $c['uid'], ['l' => 48]); eq(end($r['mesures'])['par'], $m1['name']);
    throws(fn() => $reg->addMeasure($m1, $c['uid'], ['l' => 47, 'par' => 'Inconnu Total']), 422, 'unknown_person');
    throws(fn() => $reg->addMeasure($m1, $c['uid'], ['l' => 47, 'par' => $w['m2']['user']['name']]), 422, 'unknown_person');   // m2 n'a pas accès à cette liste
    $app->access->share($m1, $i, (int)$w['m2']['id'], 'read');
    $r = $reg->addMeasure($m1, $c['uid'], ['l' => 47, 'par' => mb_strtolower($w['m2']['user']['name'])]); eq(end($r['mesures'])['par'], $w['m2']['user']['name']);
    throws(fn() => $reg->update($m1, $c['uid'], ['par' => 'Quelqu\'un d\'autre']), 422, 'unknown_person');
    eq($reg->update($m1, $c['uid'], ['par' => $w['m2']['user']['name']])['par'], $w['m2']['user']['name']);
});
