<?php
use Epi\{App, Db, Clock, Totp, Crypto, ApiError, Users, Access};
t('Invitation : numéros de membre M01, M02… et inventaire personnel créé', function () {
    $app = freshApp(); $boot = $app->bootstrap('Club', 'a@club.be', 'Admin');
    $a = $app->db->one('SELECT * FROM users WHERE email = ?', ['a@club.be']);
    eq($boot['member'], 'M01'); eq($boot['member_no'], 1);
    $b = $app->users->invite(['id' => $a['id'], 'role' => 'admin', 'status' => 'active'], 'b@club.be', 'Bob', 'member');
    eq($b['member'], 'M02');
    eq((int)$app->db->val("SELECT COUNT(*) FROM inventories WHERE kind = 'member'"), 2);
});
t('Invitation : réservée aux admins, e-mail/rôle/nom validés, doublon refusé', function () {
    $w = world(); $app = $w['app'];
    throws(fn() => $app->users->invite($w['G']['user'], 'x@club.be', 'X', 'member'), 403);
    throws(fn() => $app->users->invite($w['m1']['user'], 'x@club.be', 'X', 'member'), 403);
    throws(fn() => $app->users->invite($w['A'], 'pas-un-mail', 'X', 'member'), 422, 'invalid_email');
    throws(fn() => $app->users->invite($w['A'], 'x@club.be', '  ', 'member'), 422, 'invalid_name');
    throws(fn() => $app->users->invite($w['A'], 'x@club.be', 'X', 'root'), 422, 'invalid_role');
    throws(fn() => $app->users->invite($w['A'], 'M1@club.be', 'X', 'member'), 409, 'email_taken');
});
t('Activation : bon code requis, mot de passe vérifié, jeton à usage unique', function () {
    $app = freshApp(); $boot = $app->bootstrap('Club', 'a@club.be', 'Admin');
    $info = $app->users->invitationInfo($boot['token']); eq($info['email'], 'a@club.be');
    throws(fn() => $app->users->activateFinish($boot['token'], PW, '123456'), 409, 'totp_not_started');
    $st = $app->users->activateStart($boot['token']); ok(str_starts_with($st['uri'], 'otpauth://totp/'));
    throws(fn() => $app->users->activateFinish($boot['token'], PW, '000000'), 422, 'invalid_code');
    throws(fn() => $app->users->activateFinish($boot['token'], 'court', Totp::code($st['secret'], Totp::step())), 422, 'password_too_short');
    $fin = $app->users->activateFinish($boot['token'], PW, Totp::code($st['secret'], Totp::step()));
    eq(count($fin['recovery_codes']), 10);
    throws(fn() => $app->users->activateFinish($boot['token'], PW, Totp::code($st['secret'], Totp::step())), 410, 'invitation_invalid');
    eq($app->db->val("SELECT status FROM users WHERE email = 'a@club.be'"), 'active');
});
t('Invitation expirée ou inconnue refusée', function () {
    $app = freshApp(); $boot = $app->bootstrap('Club', 'a@club.be', 'Admin');
    throws(fn() => $app->users->invitationInfo('nimporte-quoi'), 410);
    Clock::advance(7 * 86400 + 1);
    throws(fn() => $app->users->invitationInfo($boot['token']), 410, 'invitation_invalid');
});
t('Aucun secret en clair : mot de passe haché, secret 2FA chiffré, jetons hachés', function () {
    $w = world(); $app = $w['app']; $row = $app->db->one('SELECT * FROM users WHERE email = ?', ['m1@club.be']);
    ok(str_starts_with($row['password_hash'], '$argon2id$')); ok(!str_contains($row['totp_secret_enc'], $w['m1']['secret']));
    $app->auth->login('m1@club.be', PW, '9.9.9.9');
    foreach ($app->db->all('SELECT token_hash FROM sessions') as $s) eq(strlen($s['token_hash']), 64);
    foreach ($app->db->all('SELECT code_hash FROM recovery_codes') as $r) eq(strlen($r['code_hash']), 64);
});
t('Connexion en deux temps, session, déconnexion', function () {
    $w = world(); $app = $w['app']; $u = $w['m1'];
    $a = $app->auth->login('M1@club.be ', PW, '1.1.1.1'); ok($a['ok']);
    eq($app->auth->current($a['token']), null, 'session « pre » inutilisable');
    Clock::advance(31);
    $b = $app->auth->verifySecond($a['token'], Totp::code($u['secret'], Totp::step()), false, '1.1.1.1'); ok($b['ok']);
    eq($app->auth->current($a['token']), null, 'jeton « pre » supprimé');
    $cur = $app->auth->current($b['token']); eq($cur['user']['email'], 'm1@club.be'); ok(!isset($cur['user']['password_hash']));
    $app->auth->logout($b['token']); eq($app->auth->current($b['token']), null);
});
t('Connexion : message identique pour compte inconnu et mauvais mot de passe', function () {
    $w = world(); $app = $w['app'];
    $x = $app->auth->login('inconnu@club.be', PW, '2.2.2.2'); $y = $app->auth->login('m1@club.be', 'mauvais mot de passe', '2.2.2.3');
    eq($x, ['ok' => false, 'error' => 'invalid_credentials']); eq($y, $x);
});
t('Connexion : compte invité ou désactivé refusé', function () {
    $w = world(); $app = $w['app']; $inv = $app->users->invite($w['A'], 'nouveau@club.be', 'Nouveau', 'member');
    eq($app->auth->login('nouveau@club.be', PW, '3.3.3.3')['error'], 'invalid_credentials');
    $app->users->disable($w['A'], $w['m3']['id']); eq($app->auth->login('m3@club.be', PW, '3.3.3.3')['error'], 'invalid_credentials');
});
t('Verrouillage : 5 mots de passe faux bloquent le compte 15 min, puis il se débloque', function () {
    $w = world(); $app = $w['app'];
    for ($i = 0; $i < 5; $i++) eq($app->auth->login('m1@club.be', 'faux' . $i, '4.4.4.' . $i)['error'], 'invalid_credentials');
    $r = $app->auth->login('m1@club.be', PW, '4.4.4.9'); eq($r['error'], 'too_many_attempts'); ok($r['retry_after'] > 800);
    Clock::advance(901); ok($app->auth->login('m1@club.be', PW, '4.4.4.9')['ok']);
});
t('Verrouillage par adresse IP : 20 essais sur des comptes différents', function () {
    $w = world(); $app = $w['app'];
    for ($i = 0; $i < 20; $i++) $app->auth->login("x$i@club.be", 'faux', '5.5.5.5');
    eq($app->auth->login('m1@club.be', PW, '5.5.5.5')['error'], 'too_many_attempts');
    ok($app->auth->login('m1@club.be', PW, '6.6.6.6')['ok'], 'une autre IP n\'est pas bloquée');
});
t('2FA : mauvais codes comptés, puis blocage', function () {
    $w = world(); $app = $w['app']; $a = $app->auth->login('m1@club.be', PW, '7.7.7.7');
    for ($i = 0; $i < 5; $i++) eq($app->auth->verifySecond($a['token'], '000000', false, '7.7.7.7')['error'], 'invalid_code');
    eq($app->auth->verifySecond($a['token'], Totp::code($w['m1']['secret'], Totp::step()), false, '7.7.7.7')['error'], 'too_many_attempts');
});
t('2FA : un code déjà utilisé ne peut pas servir deux fois', function () {
    $w = world(); $app = $w['app']; $code = Totp::code($w['m1']['secret'], Totp::step());
    $a = $app->auth->login('m1@club.be', PW, '8.8.8.8'); ok($app->auth->verifySecond($a['token'], $code, false, '8.8.8.8')['ok']);
    $b = $app->auth->login('m1@club.be', PW, '8.8.8.8'); eq($app->auth->verifySecond($b['token'], $code, false, '8.8.8.8')['error'], 'invalid_code');
});
t('2FA : jeton « pre » expiré après 5 minutes', function () {
    $w = world(); $app = $w['app']; $a = $app->auth->login('m1@club.be', PW, '1.0.0.1'); Clock::advance(301);
    eq($app->auth->verifySecond($a['token'], Totp::code($w['m1']['secret'], Totp::step()), false, '1.0.0.1')['error'], 'session_expired');
});
t('Codes de secours : valables une seule fois, format tolérant', function () {
    $w = world(); $app = $w['app']; $code = $w['m1']['codes'][0];
    $a = $app->auth->login('m1@club.be', PW, '1.0.0.2'); $r = $app->auth->verifySecond($a['token'], strtoupper(str_replace('-', ' ', $code)), false, '1.0.0.2');
    ok($r['ok']); eq($r['recovery_left'], 9);
    $b = $app->auth->login('m1@club.be', PW, '1.0.0.2'); eq($app->auth->verifySecond($b['token'], $code, false, '1.0.0.2')['error'], 'invalid_code');
});
t('Session : 12 h normale, 30 jours appareil de confiance', function () {
    $w = world(); $app = $w['app'];
    $s1 = loginFull($app, $w['m1']); eq($s1['ttl'], 12 * 3600); ok($app->auth->current($s1['token']) !== null);
    $s2 = loginFull($app, $w['m2'], true); eq($s2['ttl'], 30 * 86400);
    Clock::advance(12 * 3600 + 1); eq($app->auth->current($s1['token']), null, 'expirée après 12 h'); ok($app->auth->current($s2['token']) !== null, 'appareil de confiance encore valide');
    Clock::advance(30 * 86400); eq($app->auth->current($s2['token']), null);
});
t('Réinitialisation : sessions coupées, ancien mot de passe invalide, ré-activation requise', function () {
    $w = world(); $app = $w['app']; $s = loginFull($app, $w['m1']);
    throws(fn() => $app->users->reset($w['G']['user'], $w['m1']['id']), 403);
    $r = $app->users->reset($w['A'], $w['m1']['id']);
    eq($app->auth->current($s['token']), null); eq($app->auth->login('m1@club.be', PW, '1.0.0.3')['error'], 'invalid_credentials');
    $st = $app->users->activateStart($r['token']); eq($app->users->invitationInfo($r['token'])['purpose'], 'reset');
    $new = 'un tout nouveau mot de passe';
    $fin = $app->users->activateFinish($r['token'], $new, Totp::code($st['secret'], Totp::step())); eq(count($fin['recovery_codes']), 10);
    Clock::advance(31); $a = $app->auth->login('m1@club.be', $new, '1.0.0.3'); ok($a['ok']);
    eq((int)$app->db->val('SELECT member_no FROM users WHERE id = ?', [$w['m1']['id']]), $w['m1']['member_no'], 'même numéro de membre');
});
t('Désactivation : sessions coupées, partages supprimés, numéro jamais réutilisé', function () {
    $w = world(); $app = $w['app']; $s = loginFull($app, $w['m1']);
    $app->access->share($w['m1']['user'], $w['inv']['m1'], $w['m2']['id'], 'write'); $app->access->share($w['m2']['user'], $w['inv']['m2'], $w['m1']['id'], 'read');
    $app->users->disable($w['A'], $w['m1']['id']);
    eq($app->auth->current($s['token']), null); eq((int)$app->db->val('SELECT COUNT(*) FROM inventory_shares'), 0);
    eq($app->access->level(['status' => 'disabled'] + $w['m1']['user'], $w['club']), 'none');
    $n = makeUser($app, $w['A'], 'nouveau@club.be'); eq($n['member_no'], 6, 'M01 admin, M02 gestion, M03-05 membres, donc M06');
});
t('Dernier admin : ne peut être ni désactivé ni rétrogradé', function () {
    $w = world(); $app = $w['app'];
    throws(fn() => $app->users->disable($w['A'], $w['admin']['id']), 409, 'last_admin');
    throws(fn() => $app->users->setRole($w['A'], $w['admin']['id'], 'member'), 409, 'last_admin');
    $b = makeUser($app, $w['A'], 'admin2@club.be', 'admin');
    $app->users->setRole($w['A'], $w['admin']['id'], 'manager'); eq($app->db->val("SELECT role FROM users WHERE id = ?", [$w['admin']['id']]), 'manager');
    throws(fn() => $app->users->disable($b['user'], $b['id']), 409, 'last_admin');
});
t('Rôles : seul un admin les change', function () {
    $w = world(); $app = $w['app'];
    throws(fn() => $app->users->setRole($w['G']['user'], $w['m1']['id'], 'admin'), 403);
    throws(fn() => $app->users->setRole($w['m1']['user'], $w['m1']['id'], 'admin'), 403);
    $app->users->setRole($w['A'], $w['m1']['id'], 'manager'); eq($app->db->val("SELECT role FROM users WHERE id = ?", [$w['m1']['id']]), 'manager');
});
t('Annuaire de partage : sans e-mail, sans soi-même, sans comptes désactivés', function () {
    $w = world(); $app = $w['app']; $app->users->disable($w['A'], $w['m3']['id']);
    $d = $app->users->directory($w['m1']['user']);
    foreach ($d as $x) { ok(!isset($x['email'])); ok((int)$x['id'] !== (int)$w['m1']['id']); ok((int)$x['id'] !== (int)$w['m3']['id']); }
    ok(count($d) === 3, 'admin, gestion, m2');
});
t('Journal d\'audit : événements clés enregistrés, IP hachée', function () {
    $w = world(); $app = $w['app']; $app->auth->login('m1@club.be', 'faux', '10.1.1.1'); loginFull($app, $w['m1']);
    $acts = array_column($app->audit->recent(1000), 'action');
    foreach (['user.invite', 'user.activated', 'login.fail', 'login.ok'] as $a) ok(in_array($a, $acts, true), $a);
    foreach ($app->db->all('SELECT ip_hash FROM audit_log WHERE ip_hash IS NOT NULL') as $r) { eq(strlen($r['ip_hash']), 16); ok($r['ip_hash'] !== '10.1.1.1'); }
});

t('Réactivation : compte désactivé → invité, nouveau lien, ancien mot de passe/2FA inutilisables', function () {
    $w = world(); $app = $w['app']; $m = $w['m1'];
    throws(fn() => $app->users->reactivate($w['A'], (int)$m['user']['id']), 409, 'not_disabled');
    $app->users->disable($w['A'], (int)$m['user']['id']);
    throws(fn() => $app->users->reactivate($w['G'], (int)$m['user']['id']), 403);
    throws(fn() => $app->users->reactivate($m['user'], (int)$m['user']['id']), 403);
    $r = $app->users->reactivate($w['A'], (int)$m['user']['id']);
    eq($app->db->val('SELECT status FROM users WHERE id = ?', [$m['user']['id']]), 'invited');
    eq($app->auth->login('m1@club.be', PW, '3.3.3.3')['ok'], false, 'ancien mot de passe refusé');
    $st = $app->users->activateStart($r['token']);
    $app->users->activateFinish($r['token'], PW, Totp::code($st['secret'], Totp::step()));
    eq($app->db->val('SELECT status FROM users WHERE id = ?', [$m['user']['id']]), 'active');
    eq($app->db->val('SELECT member_no FROM users WHERE id = ?', [$m['user']['id']]), $m['user']['member_no'], 'même numéro de membre');
});

t('Schéma : mise à jour automatique (ensureSchema) et idempotente', function () {
    $app = freshApp(); $app->bootstrap('Club', 'a@club.be', 'Admin');
    $app->db->run("UPDATE settings SET v = '1' WHERE k = 'schema_version'");
    $app->ensureSchema(__DIR__ . '/../sql'); $app->ensureSchema(__DIR__ . '/../sql');
    eq((int)$app->db->val("SELECT v FROM settings WHERE k = 'schema_version'"), App::SCHEMA_VERSION);
});
t('Comptes : dernière activité enregistrée (au plus 1 fois par minute) et indicateur « en ligne » à 5 minutes', function () {
    $w = world(); $app = $w['app']; $app->db->run('UPDATE users SET last_seen_at = NULL');
    $lg = loginFull($app, $w['G']);
    $list = fn() => array_column($app->users->listAll($w['A']), null, 'id')[(int)$w['G']['id']];
    eq($list()['online'], false); eq($list()['seen_secs'], null);
    $app->auth->current($lg['token']); eq($list()['online'], true); $t1 = $app->db->val('SELECT last_seen_at FROM users WHERE id = ?', [$w['G']['id']]);
    Clock::advance(30); $app->auth->current($lg['token']); eq($app->db->val('SELECT last_seen_at FROM users WHERE id = ?', [$w['G']['id']]), $t1, 'pas de nouvelle écriture avant 60 s');
    Clock::advance(40); $app->auth->current($lg['token']); ok($app->db->val('SELECT last_seen_at FROM users WHERE id = ?', [$w['G']['id']]) !== $t1);
    Clock::advance(301); eq($list()['online'], false); ok($list()['seen_secs'] >= 301);
});
t('Mot de passe oublié : lien par e-mail (1 h), mot de passe changé, 2FA conservée, anciennes sessions coupées', function () {
    $w = world(); $app = $w['app']; $m = $w['m1'];
    $app->mailer->setFrom('epi-k7m2@molron.be'); $app->mailer->rememberBase('registre.test', 'https');
    ok($app->mailer->enabled());
    \Epi\Mailer::$sent = [];
    $sess = loginFull($app, $m);
    $app->users->forgot($m['email'], '5.5.5.5');
    eq(count(\Epi\Mailer::$sent), 1); $mail = \Epi\Mailer::$sent[0]; eq($mail['to'], $m['email']); eq($mail['from'], 'epi-k7m2@molron.be');
    ok(preg_match('#https://registre\.test/compte\.html\#/reinit/([A-Za-z0-9_-]+)#', $mail['text'], $mm), 'lien dans le message'); $tok = $mm[1];
    ok(strpos($mail['text'], PW) === false, 'aucun mot de passe dans le message');
    eq($app->users->resetInfo($tok)['email'], $m['email']);
    throws(fn() => $app->users->resetFinish($tok, 'court', null), 422, 'password_too_short');
    $new = 'tout autre mot de passe 77';
    $app->users->resetFinish($tok, $new, '1.1.1.1');
    throws(fn() => $app->users->resetFinish($tok, $new . 'x', null), 410);           // usage unique
    ok($app->auth->current($sess['token']) === null, 'sessions révoquées');
    $bad = $app->auth->login($m['email'], PW, '1.2.3.4'); ok(!$bad['ok'], 'ancien mot de passe refusé');
    $a = $app->auth->login($m['email'], $new, '1.2.3.4'); ok($a['ok'], 'nouveau mot de passe accepté');
    Clock::advance(31); $b = $app->auth->verifySecond($a['token'], Totp::code($m['secret'], Totp::step()), false, '1.2.3.4'); ok($b['ok'], 'la même application 2FA fonctionne encore');
});
t('Mot de passe oublié : adresse inconnue ou compte non actif = aucun message ; expiré ; non interchangeable avec l\'activation ; limites', function () {
    $w = world(); $app = $w['app']; $m = $w['m1']; $a = $w['A'];
    $app->mailer->setFrom('epi-k7m2@molron.be'); $app->mailer->rememberBase('registre.test', 'https'); \Epi\Mailer::$sent = [];
    $app->users->forgot('personne@nulle.part', '9.9.9.1'); eq(count(\Epi\Mailer::$sent), 0);
    $inv = $app->users->invite($a['user'] ?? $a, 'nouveau@club.be', 'Nouveau', 'member'); $app->users->forgot('nouveau@club.be', '9.9.9.2'); eq(count(\Epi\Mailer::$sent), 0, 'compte invité : rien');
    $app->users->disable($a['user'] ?? $a, $m['id']); $app->users->forgot($m['email'], '9.9.9.3'); eq(count(\Epi\Mailer::$sent), 0, 'compte désactivé : rien');
    // un lien « oublié » ne peut pas servir à refaire la 2FA (activation) et inversement
    $m2 = $w['m2']; $app->users->forgot($m2['email'], '9.9.9.4'); preg_match('#reinit/([A-Za-z0-9_-]+)#', \Epi\Mailer::$sent[0]['text'], $mm);
    throws(fn() => $app->users->activateStart($mm[1]), 410); throws(fn() => $app->users->invitationInfo($mm[1]), 410);
    throws(fn() => $app->users->resetInfo($inv['token']), 410, 'invitation_invalid');
    // expiration à 1 h
    Clock::advance(3601); throws(fn() => $app->users->resetInfo($mm[1]), 410);
    // limite : 3 demandes par heure et par adresse
    \Epi\Mailer::$sent = []; $m3 = $w['m3'];
    for ($i = 0; $i < 6; $i++) $app->users->forgot($m3['email'], '8.8.8.' . $i);
    ok(count(\Epi\Mailer::$sent) <= 3, 'au plus 3 messages par heure et par adresse : ' . count(\Epi\Mailer::$sent));
    // sans configuration d'envoi : rien ne part, aucune erreur
    $w2 = world(); \Epi\Mailer::$sent = []; $w2['app']->users->forgot($w2['m1']['email'], '7.7.7.7'); eq(count(\Epi\Mailer::$sent), 0);
});
t('Mot de passe oublié (API) : réponse identique, réglage et test d\'envoi réservés à l\'admin', function () {
    $w = world(); $api = new \Epi\Api($w['app']); $app = $w['app'];
    [$s1, $d1] = $api->handle('POST', '/forgot', ['email' => $w['m1']['email']], [], [], '3.3.3.3'); [$s2, $d2] = $api->handle('POST', '/forgot', ['email' => 'inconnu@x.be'], [], [], '3.3.3.4');
    eq($s1, 200); eq($s2, 200); eq($d1, $d2);
    $ses = loginFull($app, $w['admin']); $ck = [\Epi\Api::COOKIE => $ses['token']]; $hd = ['X-CSRF-Token' => $ses['csrf'], 'Host' => 'registre.test'];
    [$s] = $api->handle('POST', '/admin/mail', ['from' => 'pas une adresse'], $ck, $hd, '1.1.1.1'); eq($s, 422);
    [$s, $d] = $api->handle('POST', '/admin/mail', ['from' => 'epi-k7m2@molron.be'], $ck, $hd, '1.1.1.1'); eq($s, 200); eq($d['from'], 'epi-k7m2@molron.be');
    $api->handle('GET', '/me', [], $ck, $hd, '1.1.1.1');
    [$s, $d] = $api->handle('GET', '/admin/mail', [], $ck, $hd, '1.1.1.1'); eq($d['enabled'], true); eq($d['base_url'], 'https://registre.test');
    \Epi\Mailer::$sent = []; [$s, $d] = $api->handle('POST', '/admin/mail/test', [], $ck, $hd, '1.1.1.1'); eq($s, 200); eq(count(\Epi\Mailer::$sent), 1);
    $mem = loginFull($app, $w['m1']); [$s] = $api->handle('POST', '/admin/mail', ['from' => 'x@y.be'], [\Epi\Api::COOKIE => $mem['token']], ['X-CSRF-Token' => $mem['csrf']], '1.1.1.1'); eq($s, 403);
    [$s] = $api->handle('GET', '/admin/mail', [], [\Epi\Api::COOKIE => $mem['token']], [], '1.1.1.1'); eq($s, 403);
});
t('Invitation par e-mail : lien dans le message, numéro de membre, club, e-mail non configuré, renvoi, droits', function () {
    $w = world(); $app = $w['app']; $A = $w['A']; ok(($A['name'] ?? '') !== '', 'l’admin a un nom');
    \Epi\Mailer::$sent = [];
    // pas d'adresse d'expéditeur : le compte est créé, le lien reste utilisable, aucun message
    $r0 = $app->users->invite($A, 'x0@club.be', 'Zoé', 'member', null, true);
    eq($r0['mail'], 'not_configured'); eq(count(\Epi\Mailer::$sent), 0); ok($app->users->invitationInfo($r0['token'])['email'] === 'x0@club.be', 'lien valable malgré tout');
    $app->mailer->setFrom('epi-k7m2@molron.be'); $app->mailer->rememberBase('registre.test', 'https');
    $app->registry->saveClubConfig($A + ['role' => 'admin'], ['nom' => 'Spéléo Club Test'], null);
    // sans demande d'envoi : rien ne part
    $r1 = $app->users->invite($A, 'x1@club.be', 'Yann', 'member'); eq($r1['mail'], 'not_requested'); eq(count(\Epi\Mailer::$sent), 0);
    // avec envoi
    $r = $app->users->invite($A, 'x2@club.be', 'Dupont', 'manager', null, true, 'Xavier');
    eq($r['mail'], 'sent'); eq(count(\Epi\Mailer::$sent), 1); $m = \Epi\Mailer::$sent[0];
    eq($m['to'], 'x2@club.be'); eq($m['from'], 'epi-k7m2@molron.be');
    ok(preg_match('#https://registre\.test/compte\.html\#/invitation/([A-Za-z0-9_-]+)#', $m['text'], $mm), 'lien dans le message'); eq($mm[1], $r['token']);
    ok(strpos($m['text'], 'Bonjour Xavier') === 0, 'prénom'); ok(strpos($m['text'], 'Spéléo Club Test') !== false, 'nom du club'); ok(strpos($m['text'], $r['member']) !== false, 'numéro de membre');
    ok(strpos($m['subject'], 'Invitation') === 0, 'objet'); ok(strpos($m['text'], $A['name']) !== false, 'nom de celui qui invite');
    eq($app->users->invitationInfo($mm[1])['name'], 'DUPONT Xavier');
    // renvoi : nouveau lien, l'ancien cesse de marcher
    \Epi\Mailer::$sent = [];
    $n = $app->users->resend($A, (int)$r['user_id'], true);
    eq($n['mail'], 'sent'); ok($n['token'] !== $r['token']);
    throws(fn() => $app->users->invitationInfo($r['token']), 410, 'invitation_invalid');
    eq($app->users->invitationInfo($n['token'])['name'], 'DUPONT Xavier'); eq(count(\Epi\Mailer::$sent), 1);
    $n2 = $app->users->resend($A, (int)$r['user_id'], false); eq($n2['mail'], 'not_requested'); eq(count(\Epi\Mailer::$sent), 1);
    // compte déjà actif : refusé ; droits : admin seulement
    throws(fn() => $app->users->resend($A, (int)$w['m1']['id'], true), 409, 'not_invited');
    throws(fn() => $app->users->resend($w['m1'], (int)$r['user_id'], true), 403, 'forbidden');
    // après une réinitialisation, le message parle de réinitialisation
    \Epi\Mailer::$sent = []; $app->users->reset($A, (int)$w['m1']['id']);
    $rs = $app->users->resend($A, (int)$w['m1']['id'], true); eq($rs['mail'], 'sent');
    ok(strpos(\Epi\Mailer::$sent[0]['text'], 'réinitialisé') !== false, 'message de réinitialisation'); ok(strpos(\Epi\Mailer::$sent[0]['subject'], 'réinitialisé') !== false, 'objet de réinitialisation');
    ok((int)$app->db->val("SELECT COUNT(*) FROM audit_log WHERE action = 'user.invite_mail'") >= 2, 'journal des envois');
});

t('Profil : NOM en majuscules + prénom, modifiables par la personne ; migration d\'un nom complet', function () {
    $w = world(); $app = $w['app']; $A = $w['A'];
    eq(\Epi\Users::splitName('Jean-Marc de la Tour'), ['TOUR', 'Jean-Marc de la']); eq(\Epi\Users::splitName('Bob'), ['BOB', '']);
    eq(\Epi\Users::displayName('dupont', ' Anne '), 'DUPONT Anne');
    $r = $app->users->invite($A, 'p1@club.be', 'martin', 'member', null, false, 'Lucie');
    $u = $app->db->one('SELECT * FROM users WHERE id = ?', [$r['user_id']]);
    eq([$u['last_name'], $u['first_name'], $u['name']], ['MARTIN', 'Lucie', 'MARTIN Lucie']);
    throws(fn() => $app->users->invite($A, 'p2@club.be', 'martin', 'member', null, false, '  '), 422, 'invalid_first_name');
    $out = $app->users->updateProfile($u, 'Durand', 'Léa');
    eq($out['name'], 'DURAND Léa'); eq($app->db->val('SELECT name FROM inventories WHERE owner_user_id = ?', [$u['id']]), 'Matériel de DURAND Léa');
    throws(fn() => $app->users->updateProfile($u, '', 'Léa'), 422, 'invalid_name');
    throws(fn() => $app->users->updateProfile($u, 'Durand', ''), 422, 'invalid_first_name');
});
t('Changement d\'e-mail : lien envoyé à la nouvelle adresse, effet seulement à l\'ouverture, usage unique', function () {
    $w = world(); $app = $w['app']; $m1 = $w['m1']['user'];
    \Epi\Mailer::$sent = [];
    throws(fn() => $app->users->requestEmailChange($m1, 'neuf@club.be'), 409, 'mail_not_configured');
    $app->mailer->setFrom('epi-k7m2@molron.be'); $app->mailer->rememberBase('registre.test', 'https');
    throws(fn() => $app->users->requestEmailChange($m1, 'pas-un-mail'), 422, 'invalid_email');
    throws(fn() => $app->users->requestEmailChange($m1, $w['m2']['user']['email']), 409, 'email_taken');
    throws(fn() => $app->users->requestEmailChange($m1, strtoupper($m1['email'])), 422, 'same_email');
    $app->users->requestEmailChange($m1, 'Neuf@Club.be');
    eq(count(\Epi\Mailer::$sent), 1); $m = \Epi\Mailer::$sent[0]; eq($m['to'], 'neuf@club.be');
    ok(preg_match('#https://registre\.test/compte\.html\#/email/([A-Za-z0-9_-]+)#', $m['text'], $mm), 'lien');
    eq($app->db->val('SELECT email FROM users WHERE id = ?', [$m1['id']]), $m1['email']);   // rien n'a changé
    throws(fn() => $app->users->invitationInfo($mm[1]), 410, 'invitation_invalid');           // ce lien n'ouvre pas une invitation
    throws(fn() => $app->users->resetInfo($mm[1]), 410, 'invitation_invalid');
    \Epi\Mailer::$sent = [];
    eq($app->users->confirmEmailChange($mm[1])['email'], 'neuf@club.be');
    eq($app->db->val('SELECT email FROM users WHERE id = ?', [$m1['id']]), 'neuf@club.be');
    eq(count(\Epi\Mailer::$sent), 1); eq(\Epi\Mailer::$sent[0]['to'], $m1['email']);          // l'ancienne adresse est prévenue
    throws(fn() => $app->users->confirmEmailChange($mm[1]), 410, 'invitation_invalid');
    throws(fn() => $app->users->confirmEmailChange('inconnu'), 410, 'invitation_invalid');
});
