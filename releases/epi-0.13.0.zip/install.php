<?php
declare(strict_types=1);
// Page d'installation — à usage unique. Protégée par « install_key » (config.php) ; se verrouille dès qu'un compte existe.
$appDir = is_dir(__DIR__ . '/app/src') ? __DIR__ . '/app' : dirname(__DIR__);
require $appDir . '/src/bootstrap.php';
use Epi\{App, Db, ApiError};
date_default_timezone_set('UTC');
header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); header('X-Robots-Tag: noindex');
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function page(string $body): void { echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installation</title><style>body{font:16px system-ui;max-width:34rem;margin:2rem auto;padding:0 1rem}input{display:block;width:100%;padding:.5rem;margin:.3rem 0 1rem;box-sizing:border-box}button{padding:.6rem 1.2rem}code,pre{background:#eee;padding:.2rem .4rem;word-break:break-all;white-space:pre-wrap}.err{color:#b00}</style><h1>Installation du registre EPI</h1>' . $body; exit; }

$cfgFile = $appDir . '/config.php';
if (!is_file($cfgFile)) page('<p class="err">config.php introuvable dans le dossier « app ».</p>');
$config = require $cfgFile;
if (empty($config['install_key']) || str_starts_with((string)$config['install_key'], 'REMPLACER')) page('<p class="err">Définissez « install_key » dans config.php.</p>');
if (empty($config['app_key']) || $config['app_key'] === 'REMPLACER') page('<p class="err">Définissez « app_key » dans config.php.</p>');
try { $app = App::build(Db::connect($config['db']), $config); }
catch (Throwable $e) { error_log('[epi-install] ' . $e); page('<p class="err">Connexion à la base impossible. Vérifiez « db » dans config.php.</p>'); }
if ($app->isInstalled()) page('<p>✅ Déjà installé. Cette page est verrouillée : supprimez <code>install.php</code> du serveur.</p>');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $key = (string)($_POST['key'] ?? '');
    usleep(500000);
    if (!hash_equals((string)$config['install_key'], $key)) page('<p class="err">Clé d\'installation incorrecte.</p>');
    try {
        $app->installSchema($appDir . '/sql');
        $r = $app->bootstrap(trim((string)($_POST['club'] ?? '')) ?: 'Club', trim((string)($_POST['email'] ?? '')), trim((string)($_POST['name'] ?? '')));
    } catch (ApiError $e) { page('<p class="err">Refusé : ' . h($e->errorCode) . '</p>'); }
    catch (Throwable $e) { error_log('[epi-install] ' . $e); page('<p class="err">Erreur pendant l\'installation (voir le journal d\'erreurs du serveur).</p>'); }
    $link = rtrim((string)$config['base_url'], '/') . '/compte.html#/invitation/' . $r['token'];
    page('<p>✅ Base créée. Premier compte : <b>' . h($r['member']) . '</b>.</p><p>Ouvrez ce lien <b>une seule fois</b> (valable 7 jours) pour choisir votre mot de passe et activer la double authentification :</p><pre>' . h($link) . '</pre><p>Ensuite : supprimez <code>install.php</code> et <code>selftest.php</code> du serveur.</p>');
}
page('<form method="post"><label>Clé d\'installation (config.php)<input name="key" type="password" required autocomplete="off"></label><label>Nom du club<input name="club" required></label><label>Nom du premier administrateur<input name="name" required></label><label>E-mail du premier administrateur<input name="email" type="email" required></label><button>Installer</button></form>');
